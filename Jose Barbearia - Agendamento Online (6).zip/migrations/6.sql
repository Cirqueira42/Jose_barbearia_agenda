
CREATE TABLE gallery_photos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  url TEXT NOT NULL,
  alt TEXT NOT NULL,
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO gallery_photos (url, alt, display_order) VALUES
('https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/barbershop-interior.png', 'Interior da barbearia', 1),
('https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/barber-haircut.png', 'Corte profissional', 2),
('https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/beard-grooming.png', 'Barba profissional', 3),
('https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/barbershop-exterior.png', 'Fachada da barbearia', 4);
