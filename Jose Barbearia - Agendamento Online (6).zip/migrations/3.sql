
ALTER TABLE pomade_sales ADD COLUMN pomade_type TEXT NOT NULL DEFAULT 'cera_extra_forte';
