
CREATE TABLE settings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  key TEXT NOT NULL UNIQUE,
  value TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_settings_key ON settings(key);

INSERT INTO settings (key, value) VALUES
('business_name', 'José Barbearia'),
('barber_name', 'José Gilmario'),
('business_address', 'Av. Otávio Rangel, 477 - Vila Cecap, Guariba - SP, 14845-106'),
('instagram', '@josebarbeariaa'),
('instagram_url', 'https://www.instagram.com/josebarbeariaa/'),
('whatsapp', '5516997369740'),
('pomade_price', '17.99'),
('hours_monday_morning_start', '09:00'),
('hours_monday_morning_end', '12:00'),
('hours_monday_afternoon_start', '13:00'),
('hours_monday_afternoon_end', '19:00'),
('hours_tuesday_morning_start', '09:00'),
('hours_tuesday_morning_end', '12:00'),
('hours_tuesday_afternoon_start', '13:00'),
('hours_tuesday_afternoon_end', '18:00'),
('hours_wednesday_morning_start', '09:00'),
('hours_wednesday_morning_end', '12:00'),
('hours_wednesday_afternoon_start', '13:00'),
('hours_wednesday_afternoon_end', '18:00'),
('hours_thursday_morning_start', '09:00'),
('hours_thursday_morning_end', '12:00'),
('hours_thursday_afternoon_start', '13:00'),
('hours_thursday_afternoon_end', '19:00'),
('hours_friday_morning_start', '09:00'),
('hours_friday_morning_end', '12:00'),
('hours_friday_afternoon_start', '13:00'),
('hours_friday_afternoon_end', '19:00'),
('hours_saturday_morning_start', '08:30'),
('hours_saturday_morning_end', '12:00'),
('hours_saturday_afternoon_start', '13:00'),
('hours_saturday_afternoon_end', '19:00'),
('hours_sunday_closed', 'true');

CREATE TABLE services_config (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  price REAL NOT NULL,
  duration INTEGER NOT NULL,
  icon TEXT NOT NULL,
  image TEXT NOT NULL,
  is_active BOOLEAN DEFAULT 1,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO services_config (id, name, description, price, duration, icon, image, display_order) VALUES
('corte', 'Corte', 'Corte moderno e estiloso', 30, 30, 'Scissors', 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-haircut.png', 1),
('barba', 'Barba', 'Barba profissional e bem feita', 20, 20, 'Sparkles', 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-beard.png', 2),
('combo', 'Corte + Barba', 'Pacote completo: corte moderno + barba bem feita', 45, 50, 'Package', 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-combo.png', 3),
('corte-infantil', 'Corte Infantil', 'Corte infantil com cuidado especial', 25, 30, 'Baby', 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-kids.png', 4),
('sobrancelha', 'Sobrancelha', 'Design de sobrancelha perfeito', 10, 10, 'Eye', 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-eyebrow.png', 5),
('pezinho', 'Pezinho', 'Finalização perfeita', 10, 10, 'Sparkle', 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-fade.png', 6);

CREATE TABLE pomade_types (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  icon TEXT NOT NULL,
  is_active BOOLEAN DEFAULT 1,
  display_order INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO pomade_types (id, name, icon, display_order) VALUES
('cera_extra_forte', 'Cera Extra Forte', '💪', 1),
('cera_perolada', 'Cera Perolada', '✨', 2),
('cera_black', 'Cera Black', '🖤', 3),
('cera_matte', 'Cera Matte', '⚫', 4),
('cera_teia', 'Cera Teia', '🕸️', 5);
