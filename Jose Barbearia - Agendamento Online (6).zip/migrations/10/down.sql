
ALTER TABLE appointments DROP COLUMN payment_status;
ALTER TABLE appointments DROP COLUMN payment_method;
