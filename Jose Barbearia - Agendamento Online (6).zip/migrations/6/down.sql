
DROP TABLE gallery_photos;
