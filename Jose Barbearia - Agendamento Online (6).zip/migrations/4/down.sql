
ALTER TABLE appointments DROP COLUMN service_duration;
