
CREATE TABLE quick_action_tokens (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  appointment_id INTEGER NOT NULL,
  token TEXT NOT NULL UNIQUE,
  action TEXT NOT NULL,
  expires_at DATETIME NOT NULL,
  used_at DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_quick_action_tokens_token ON quick_action_tokens(token);
CREATE INDEX idx_quick_action_tokens_appointment ON quick_action_tokens(appointment_id);
