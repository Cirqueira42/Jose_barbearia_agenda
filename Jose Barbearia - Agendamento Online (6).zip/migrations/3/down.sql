
ALTER TABLE pomade_sales DROP COLUMN pomade_type;
