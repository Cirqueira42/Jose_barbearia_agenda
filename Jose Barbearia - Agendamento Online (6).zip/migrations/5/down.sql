
DROP INDEX idx_settings_key;
DROP TABLE pomade_types;
DROP TABLE services_config;
DROP TABLE settings;
