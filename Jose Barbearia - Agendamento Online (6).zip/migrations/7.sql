
ALTER TABLE pomade_types ADD COLUMN image TEXT;
