import { Calendar, Clock, User, Mail, Phone, Package, Check } from 'lucide-react';
import { useState } from 'react';
import type { Appointment } from '../../shared/types';

interface AppointmentCardProps {
  appointment: Appointment;
  onStatusChange: (id: number, status: string) => Promise<void>;
}

const statusConfig = {
  pending: {
    label: 'Pendente',
    color: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
    dotColor: 'bg-yellow-500',
  },
  confirmed: {
    label: 'Confirmado',
    color: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
    dotColor: 'bg-blue-500',
  },
  completed: {
    label: 'Concluído',
    color: 'bg-green-500/10 text-green-500 border-green-500/20',
    dotColor: 'bg-green-500',
  },
  cancelled: {
    label: 'Cancelado',
    color: 'bg-red-500/10 text-red-500 border-red-500/20',
    dotColor: 'bg-red-500',
  },
};

export function AppointmentCard({ appointment, onStatusChange }: AppointmentCardProps) {
  const [copied, setCopied] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const status = statusConfig[appointment.status] || statusConfig.pending;
  // Fix timezone issue by appending T00:00:00
  const date = new Date(appointment.appointment_date + 'T00:00:00');
  const formattedDate = date.toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });

  const whatsappConfirmationMessage = `Olá ${appointment.customer_name}!\n\nSeu agendamento foi confirmado com sucesso! ✅\n\n📅 Data: ${formattedDate}\n🕐 Horário: ${appointment.appointment_time}\n✂️ Serviço: ${appointment.service_name}\n\n📍 Endereço:\nAv. Otávio Rangel, 477 - Vila Cecap\nGuariba - SP, 14845-106\n\nVocê receberá um lembrete antes do seu horário.\n\nCaso precise cancelar ou reagendar, entre em contato conosco pelo Instagram @josebarbeariaa\n\nAté breve!\nJose Barbearia`;

  const whatsappThankYouMessage = `Olá ${appointment.customer_name}! 😊\n\n✨ *Obrigado por agendar com a Jose Barbearia!*\n\nSeu horário está confirmado:\n\n📅 *${formattedDate}*\n🕐 *${appointment.appointment_time}*\n✂️ *${appointment.service_name}*\n\nEstamos ansiosos para atendê-lo!\n\n📍 *Endereço:*\nAv. Otávio Rangel, 477 - Vila Cecap\nGuariba - SP, 14845-106\n\n💬 Qualquer dúvida, estamos à disposição!\n\n_Jose Barbearia - Estilo e Atitude_`;

  const whatsappCompletionMessage = `Olá ${appointment.customer_name}! 🙏\n\n✨ *Obrigado por escolher a Jose Barbearia!*\n\nFoi um prazer atendê-lo hoje!\n\n📅 Data: ${formattedDate}\n🕐 Horário: ${appointment.appointment_time}\n✂️ Serviço: ${appointment.service_name}\n\nEsperamos vê-lo novamente em breve! 💈\n\n📱 Siga-nos no Instagram: @josebarbeariaa\n\n_Jose Barbearia - Estilo e Atitude_`;

  const whatsappCancellationMessage = `Olá ${appointment.customer_name}! 👋\n\n❌ *Agendamento Cancelado*\n\nInformamos que seu agendamento foi cancelado:\n\n📅 *${formattedDate}*\n🕐 *${appointment.appointment_time}*\n✂️ *${appointment.service_name}*\n\nDeseja reagendar? Entre em contato conosco!\n\n_Jose Barbearia_`;

  const handleShareConfirmation = () => {
    // Clean phone number and format for WhatsApp
    let phone = appointment.customer_phone.replace(/\D/g, '');
    if (!phone.startsWith('55')) {
      phone = '55' + phone;
    }
    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(whatsappConfirmationMessage)}`;
    window.open(whatsappUrl, '_blank');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareThankYou = () => {
    // Clean phone number and format for WhatsApp
    let phone = appointment.customer_phone.replace(/\D/g, '');
    if (!phone.startsWith('55')) {
      phone = '55' + phone;
    }
    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(whatsappThankYouMessage)}`;
    window.open(whatsappUrl, '_blank');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareCompletion = () => {
    // Clean phone number and format for WhatsApp
    let phone = appointment.customer_phone.replace(/\D/g, '');
    if (!phone.startsWith('55')) {
      phone = '55' + phone;
    }
    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(whatsappCompletionMessage)}`;
    window.open(whatsappUrl, '_blank');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareCancellation = () => {
    // Clean phone number and format for WhatsApp
    let phone = appointment.customer_phone.replace(/\D/g, '');
    if (!phone.startsWith('55')) {
      phone = '55' + phone;
    }
    const whatsappUrl = `https://wa.me/${phone}?text=${encodeURIComponent(whatsappCancellationMessage)}`;
    window.open(whatsappUrl, '_blank');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="group relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 p-6 transition-all hover:border-amber-500/30 hover:shadow-lg hover:shadow-amber-500/5">
      <div className="mb-4 flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-amber-500/10 p-3">
            <Package className="h-5 w-5 text-amber-500" />
          </div>
          <div>
            <h3 className="font-semibold text-white">{appointment.service_name}</h3>
            <div className="mt-1 flex items-center gap-2 text-sm text-slate-400">
              <Calendar className="h-3.5 w-3.5" />
              <span>{formattedDate}</span>
              <Clock className="ml-2 h-3.5 w-3.5" />
              <span>{appointment.appointment_time}</span>
            </div>
          </div>
        </div>

        <div className={`flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium ${status.color}`}>
          <div className={`h-1.5 w-1.5 rounded-full ${status.dotColor}`} />
          {status.label}
        </div>
      </div>

      <div className="space-y-2 border-t border-slate-700/50 pt-4">
        <div className="flex items-center gap-2 text-sm text-slate-300">
          <User className="h-4 w-4 text-slate-500" />
          <span>{appointment.customer_name}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-300">
          <Mail className="h-4 w-4 text-slate-500" />
          <span>{appointment.customer_email}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-300">
          <Phone className="h-4 w-4 text-slate-500" />
          <span>{appointment.customer_phone}</span>
        </div>
      </div>

      {/* WhatsApp Share Buttons */}
      {appointment.status === 'completed' ? (
        <div className="mt-4 border-t border-slate-700/50 pt-4">
          <div className="rounded-lg bg-green-500/10 border border-green-500/30 p-3 mb-2">
            <p className="text-xs text-green-400 font-medium text-center">✅ Atendimento Concluído</p>
          </div>
          <button
            onClick={handleShareCompletion}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-green-500 to-green-600 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-green-500/25 transition-all hover:shadow-xl hover:shadow-green-500/40"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4" />
                Enviado!
              </>
            ) : (
              <>
                <Phone className="h-4 w-4" />
                🙏 Enviar Agradecimento
              </>
            )}
          </button>
        </div>
      ) : appointment.status === 'cancelled' ? (
        <div className="mt-4 border-t border-slate-700/50 pt-4">
          <button
            onClick={handleShareCancellation}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-green-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-green-700"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4" />
                Enviado!
              </>
            ) : (
              <>
                <Phone className="h-4 w-4" />
                Notificar Cancelamento via WhatsApp
              </>
            )}
          </button>
        </div>
      ) : appointment.status === 'confirmed' ? (
        <div className="mt-4 space-y-2 border-t border-slate-700/50 pt-4">
          <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-3 mb-2">
            <p className="text-xs text-amber-400 font-medium text-center">✅ Agendamento Confirmado</p>
          </div>
          <button
            onClick={handleShareThankYou}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-green-500 to-green-600 px-4 py-3 text-sm font-semibold text-white shadow-lg shadow-green-500/25 transition-all hover:shadow-xl hover:shadow-green-500/40"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4" />
                Enviado!
              </>
            ) : (
              <>
                <Phone className="h-4 w-4" />
                📲 Enviar Agradecimento
              </>
            )}
          </button>
          <button
            onClick={() => onStatusChange(appointment.id, 'cancelled')}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-red-500/10 px-4 py-2.5 text-sm font-medium text-red-500 transition-colors hover:bg-red-500/20"
          >
            Cancelar Agendamento
          </button>
        </div>
      ) : (
        <div className="mt-4 space-y-2 border-t border-slate-700/50 pt-4">
          <button
            onClick={handleShareConfirmation}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-green-600 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-green-700"
          >
            {copied ? (
              <>
                <Check className="h-4 w-4" />
                Compartilhado!
              </>
            ) : (
              <>
                <Phone className="h-4 w-4" />
                Compartilhar Confirmação
              </>
            )}
          </button>
          <button
            onClick={() => onStatusChange(appointment.id, 'cancelled')}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-red-500/10 px-4 py-2.5 text-sm font-medium text-red-500 transition-colors hover:bg-red-500/20"
          >
            Cancelar Agendamento
          </button>
        </div>
      )}

      {appointment.status !== 'completed' && appointment.status !== 'cancelled' && (
        <div className="mt-4 flex gap-2 border-t border-slate-700/50 pt-4">
          {appointment.status === 'pending' && (
            <button
              onClick={async () => {
                setIsUpdating(true);
                try {
                  await onStatusChange(appointment.id, 'confirmed');
                } finally {
                  setIsUpdating(false);
                }
              }}
              disabled={isUpdating}
              className="flex-1 rounded-lg bg-blue-500/10 px-3 py-2 text-sm font-medium text-blue-500 transition-colors hover:bg-blue-500/20 disabled:opacity-50"
            >
              {isUpdating ? 'Confirmando...' : 'Confirmar'}
            </button>
          )}
          {appointment.status === 'confirmed' && (
            <button
              onClick={async () => {
                setIsUpdating(true);
                try {
                  await onStatusChange(appointment.id, 'completed');
                } finally {
                  setIsUpdating(false);
                }
              }}
              disabled={isUpdating}
              className="flex-1 rounded-lg bg-green-500/10 px-3 py-2 text-sm font-medium text-green-500 transition-colors hover:bg-green-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {isUpdating ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-green-500 border-t-transparent" />
                  Concluindo...
                </>
              ) : (
                'Concluir'
              )}
            </button>
          )}
          <button
            onClick={async () => {
              setIsUpdating(true);
              try {
                await onStatusChange(appointment.id, 'cancelled');
              } finally {
                setIsUpdating(false);
              }
            }}
            disabled={isUpdating}
            className="flex-1 rounded-lg bg-red-500/10 px-3 py-2 text-sm font-medium text-red-500 transition-colors hover:bg-red-500/20 disabled:opacity-50"
          >
            {isUpdating ? 'Cancelando...' : 'Cancelar'}
          </button>
        </div>
      )}
    </div>
  );
}
