import { useState, useEffect } from 'react';
import { Calendar, Clock, Trash2, Plus, Loader2, AlertCircle, CheckCircle, Ban } from 'lucide-react';

interface BlockedTime {
  id: number;
  block_date: string;
  start_time: string | null;
  end_time: string | null;
  is_full_day: number;
  reason: string | null;
  created_at: string;
}

export function BlockedTimesPanel() {
  const [blockedTimes, setBlockedTimes] = useState<BlockedTime[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const [formData, setFormData] = useState({
    block_date: '',
    start_time: '',
    end_time: '',
    is_full_day: true,
    reason: '',
  });

  useEffect(() => {
    fetchBlockedTimes();
  }, []);

  const fetchBlockedTimes = async () => {
    try {
      const response = await fetch('/api/blocked-times');
      const data = await response.json();
      setBlockedTimes(data.blocked_times || []);
    } catch (err) {
      setError('Erro ao carregar bloqueios');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch('/api/blocked-times', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          block_date: formData.block_date,
          start_time: formData.is_full_day ? null : formData.start_time,
          end_time: formData.is_full_day ? null : formData.end_time,
          is_full_day: formData.is_full_day,
          reason: formData.reason || null,
        }),
      });

      if (!response.ok) {
        throw new Error('Erro ao criar bloqueio');
      }

      setSuccess('Bloqueio criado com sucesso!');
      setFormData({
        block_date: '',
        start_time: '',
        end_time: '',
        is_full_day: true,
        reason: '',
      });
      fetchBlockedTimes();

      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao criar bloqueio');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Tem certeza que deseja remover este bloqueio?')) {
      return;
    }

    try {
      const response = await fetch(`/api/blocked-times/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Erro ao deletar bloqueio');
      }

      setSuccess('Bloqueio removido com sucesso!');
      fetchBlockedTimes();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao deletar bloqueio');
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr + 'T00:00:00');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const dateOnly = new Date(date);
    dateOnly.setHours(0, 0, 0, 0);

    if (dateOnly.getTime() === today.getTime()) {
      return 'Hoje';
    } else if (dateOnly.getTime() === tomorrow.getTime()) {
      return 'Amanhã';
    } else {
      return date.toLocaleDateString('pt-BR', {
        weekday: 'long',
        day: '2-digit',
        month: 'long',
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Form */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 p-6">
        <div className="mb-6 flex items-center gap-2 text-white">
          <Ban className="h-6 w-6 text-red-400" />
          <h2 className="text-xl font-semibold">Bloquear Horários</h2>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {success && (
            <div className="flex items-center gap-3 rounded-xl bg-green-500/10 p-4 text-green-400 border border-green-500/20">
              <CheckCircle className="h-5 w-5 flex-shrink-0" />
              <p className="text-sm">{success}</p>
            </div>
          )}

          {error && (
            <div className="flex items-center gap-3 rounded-xl bg-red-500/10 p-4 text-red-400 border border-red-500/20">
              <AlertCircle className="h-5 w-5 flex-shrink-0" />
              <p className="text-sm">{error}</p>
            </div>
          )}

          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300">
              <Calendar className="h-4 w-4" />
              Data
            </label>
            <input
              type="date"
              required
              value={formData.block_date}
              onChange={(e) => setFormData({ ...formData, block_date: e.target.value })}
              className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500"
            />
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-slate-300">
              <input
                type="checkbox"
                checked={formData.is_full_day}
                onChange={(e) => setFormData({ ...formData, is_full_day: e.target.checked })}
                className="h-4 w-4 rounded border-slate-600 bg-slate-800 text-amber-500 focus:ring-2 focus:ring-amber-500"
              />
              Bloquear o dia inteiro
            </label>
          </div>

          {!formData.is_full_day && (
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300">
                  <Clock className="h-4 w-4" />
                  Horário Inicial
                </label>
                <input
                  type="time"
                  required
                  value={formData.start_time}
                  onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                  className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300">
                  <Clock className="h-4 w-4" />
                  Horário Final
                </label>
                <input
                  type="time"
                  required
                  value={formData.end_time}
                  onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                  className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500"
                />
              </div>
            </div>
          )}

          <div>
            <label className="mb-2 block text-sm font-medium text-slate-300">
              Motivo (opcional)
            </label>
            <input
              type="text"
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              placeholder="Ex: Férias, compromisso pessoal..."
              className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white placeholder-slate-500 outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full rounded-xl bg-gradient-to-r from-red-500 to-red-600 py-3 font-semibold text-white shadow-lg transition-all hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Criando...
              </>
            ) : (
              <>
                <Plus className="h-5 w-5" />
                Criar Bloqueio
              </>
            )}
          </button>
        </form>
      </div>

      {/* List of Blocked Times */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 p-6">
        <h3 className="mb-4 text-lg font-semibold text-white">Bloqueios Ativos</h3>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-amber-500" />
          </div>
        ) : blockedTimes.length === 0 ? (
          <p className="py-8 text-center text-slate-400">
            Nenhum bloqueio configurado
          </p>
        ) : (
          <div className="space-y-3">
            {blockedTimes.map((block) => (
              <div
                key={block.id}
                className="flex items-center justify-between rounded-xl bg-slate-800/50 p-4 border border-slate-700/50"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-red-400" />
                    <span className="font-medium text-white">
                      {formatDate(block.block_date)}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-2 text-sm text-slate-400">
                    {block.is_full_day ? (
                      <span className="text-red-400">Dia inteiro bloqueado</span>
                    ) : (
                      <>
                        <Clock className="h-3 w-3" />
                        <span>
                          {block.start_time} - {block.end_time}
                        </span>
                      </>
                    )}
                  </div>
                  {block.reason && (
                    <p className="mt-1 text-sm text-slate-500">
                      {block.reason}
                    </p>
                  )}
                </div>

                <button
                  onClick={() => handleDelete(block.id)}
                  className="rounded-lg p-2 text-red-400 transition-colors hover:bg-red-500/10"
                  title="Remover bloqueio"
                >
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
