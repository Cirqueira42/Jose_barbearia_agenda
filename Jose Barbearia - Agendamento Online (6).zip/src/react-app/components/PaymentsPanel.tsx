import { useState, useMemo } from 'react';
import { DollarSign, CheckCircle, Clock, AlertCircle, CreditCard } from 'lucide-react';
import type { Appointment } from '../../shared/types';

interface PaymentsPanelProps {
  appointments: Appointment[];
  onUpdatePaymentStatus: (id: number, status: string) => Promise<void>;
}

export function PaymentsPanel({ appointments, onUpdatePaymentStatus }: PaymentsPanelProps) {
  const [filter, setFilter] = useState<'all' | 'pending' | 'confirmed'>('pending');

  const paymentStats = useMemo(() => {
    const withPayment = appointments.filter(a => a.payment_method);
    const pixPending = appointments.filter(a => a.payment_method === 'pix' && a.payment_status === 'pending');
    const pixConfirmed = appointments.filter(a => a.payment_method === 'pix' && a.payment_status === 'confirmed');

    return {
      total: withPayment.length,
      pixPending: pixPending.length,
      pixConfirmed: pixConfirmed.length,
    };
  }, [appointments]);

  const filteredAppointments = useMemo(() => {
    let filtered = appointments.filter(a => a.payment_method);

    if (filter === 'pending') {
      filtered = filtered.filter(a => a.payment_status === 'pending');
    } else if (filter === 'confirmed') {
      filtered = filtered.filter(a => a.payment_status === 'confirmed');
    }

    return filtered.sort((a, b) => {
      const dateCompare = b.appointment_date.localeCompare(a.appointment_date);
      if (dateCompare !== 0) return dateCompare;
      return b.appointment_time.localeCompare(a.appointment_time);
    });
  }, [appointments, filter]);

  const getPaymentMethodLabel = (method: string | null) => {
    if (!method) return 'Não especificado';
    const methods: Record<string, string> = {
      pix: 'PIX',
      dinheiro: 'Dinheiro',
      cartao: 'Cartão',
    };
    return methods[method] || method;
  };

  const getPaymentStatusBadge = (status: string | null) => {
    if (status === 'confirmed') {
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-green-500/20 px-3 py-1 text-xs font-medium text-green-400 border border-green-500/30">
          <CheckCircle className="h-3 w-3" />
          Confirmado
        </span>
      );
    } else if (status === 'pending') {
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-yellow-500/20 px-3 py-1 text-xs font-medium text-yellow-400 border border-yellow-500/30">
          <Clock className="h-3 w-3" />
          Aguardando
        </span>
      );
    } else {
      return (
        <span className="inline-flex items-center gap-1 rounded-full bg-slate-500/20 px-3 py-1 text-xs font-medium text-slate-400 border border-slate-500/30">
          <AlertCircle className="h-3 w-3" />
          Não requerido
        </span>
      );
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-white">Caixa - Pagamentos</h2>
        <p className="mt-1 text-slate-400">Acompanhe os pagamentos dos agendamentos</p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-400">Com Pagamento</p>
              <p className="mt-1 text-3xl font-bold text-white">{paymentStats.total}</p>
            </div>
            <div className="rounded-xl bg-slate-700/30 p-3">
              <CreditCard className="h-6 w-6 text-slate-400" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-yellow-500/20 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-yellow-400">PIX Pendente</p>
              <p className="mt-1 text-3xl font-bold text-white">{paymentStats.pixPending}</p>
            </div>
            <div className="rounded-xl bg-yellow-500/10 p-3">
              <Clock className="h-6 w-6 text-yellow-500" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-green-500/20 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-400">PIX Confirmado</p>
              <p className="mt-1 text-3xl font-bold text-white">{paymentStats.pixConfirmed}</p>
            </div>
            <div className="rounded-xl bg-green-500/10 p-3">
              <CheckCircle className="h-6 w-6 text-green-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        <button
          onClick={() => setFilter('all')}
          className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
            filter === 'all'
              ? 'bg-amber-500 text-white'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          Todos
        </button>
        <button
          onClick={() => setFilter('pending')}
          className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
            filter === 'pending'
              ? 'bg-amber-500 text-white'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          Pendentes ({paymentStats.pixPending})
        </button>
        <button
          onClick={() => setFilter('confirmed')}
          className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
            filter === 'confirmed'
              ? 'bg-amber-500 text-white'
              : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
          }`}
        >
          Confirmados
        </button>
      </div>

      {/* Payments List */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 overflow-hidden">
        {filteredAppointments.length === 0 ? (
          <div className="p-12 text-center">
            <DollarSign className="mx-auto h-12 w-12 text-slate-600" />
            <p className="mt-4 text-slate-400">
              {filter === 'pending'
                ? 'Nenhum pagamento pendente'
                : 'Nenhum pagamento encontrado'}
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-800/50">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-400">
                    Data/Hora
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-400">
                    Cliente
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-400">
                    Serviço
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-400">
                    Pagamento
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-400">
                    Status
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider text-slate-400">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {filteredAppointments.map((appointment) => (
                  <tr key={appointment.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-white">{formatDate(appointment.appointment_date)}</div>
                      <div className="text-xs text-slate-400">{appointment.appointment_time}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-white">{appointment.customer_name}</div>
                      <div className="text-xs text-slate-400">{appointment.customer_phone}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-white">{appointment.service_name}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center gap-1 rounded-full px-3 py-1 text-xs font-medium ${
                        appointment.payment_method === 'pix'
                          ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                          : 'bg-slate-500/20 text-slate-400 border border-slate-500/30'
                      }`}>
                        {getPaymentMethodLabel(appointment.payment_method)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {getPaymentStatusBadge(appointment.payment_status)}
                    </td>
                    <td className="px-6 py-4">
                      {appointment.payment_method === 'pix' && appointment.payment_status === 'pending' && (
                        <button
                          onClick={() => onUpdatePaymentStatus(appointment.id, 'confirmed')}
                          className="inline-flex items-center gap-1 rounded-lg bg-green-500/20 px-3 py-1.5 text-xs font-medium text-green-400 border border-green-500/30 hover:bg-green-500/30 transition-colors"
                        >
                          <CheckCircle className="h-3 w-3" />
                          Confirmar Pagamento
                        </button>
                      )}
                      {appointment.payment_method === 'pix' && appointment.payment_status === 'confirmed' && (
                        <button
                          onClick={() => onUpdatePaymentStatus(appointment.id, 'pending')}
                          className="inline-flex items-center gap-1 rounded-lg bg-yellow-500/20 px-3 py-1.5 text-xs font-medium text-yellow-400 border border-yellow-500/30 hover:bg-yellow-500/30 transition-colors"
                        >
                          <Clock className="h-3 w-3" />
                          Marcar como Pendente
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* PIX Info Card */}
      <div className="rounded-2xl border border-green-500/30 bg-gradient-to-br from-green-900/20 via-slate-900/50 to-slate-900/50 p-6 backdrop-blur-sm">
        <div className="flex items-center gap-3 mb-4">
          <div className="rounded-xl bg-green-500 p-3">
            <DollarSign className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Dados para Recebimento PIX</h3>
            <p className="text-sm text-slate-400">Informações compartilhadas com os clientes</p>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-lg bg-slate-900/50 p-4 border border-slate-700">
            <p className="text-xs text-slate-400 mb-1">Tipo de Chave:</p>
            <p className="font-mono text-white">📱 Celular</p>
          </div>

          <div className="rounded-lg bg-slate-900/50 p-4 border border-slate-700">
            <p className="text-xs text-slate-400 mb-1">Chave PIX:</p>
            <p className="font-mono text-lg font-bold text-green-400">75 99941-2596</p>
          </div>

          <div className="rounded-lg bg-slate-900/50 p-4 border border-slate-700 sm:col-span-2">
            <p className="text-xs text-slate-400 mb-1">Nome:</p>
            <p className="font-medium text-white">Jose Gilmario dos Santos Cirqueira</p>
          </div>
        </div>
      </div>
    </div>
  );
}
