import { useState, useEffect } from 'react';
import { X, Calendar, Clock, User, Phone, Mail, Loader2, CheckCircle, AlertCircle, WifiOff } from 'lucide-react';
import { Service } from '../../data/services';
import { usePushNotifications } from '../hooks/usePushNotifications';

interface BookingModalProps {
  service: Service;
  onClose: () => void;
}

export function BookingModal({ service, onClose }: BookingModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    date: '',
    time: '',
    paymentMethod: '',
  });
  const [availableTimes, setAvailableTimes] = useState<string[]>([]);
  const [isLoadingTimes, setIsLoadingTimes] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [customerFound, setCustomerFound] = useState(false);
  const [pixConfirmed, setPixConfirmed] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const { showLocalNotification } = usePushNotifications();

  useEffect(() => {
    if (formData.date) {
      fetchAvailableTimes(formData.date);
    }
  }, [formData.date]);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const lookupCustomer = async (phone: string) => {
    // Only lookup if phone has at least 10 digits
    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setCustomerFound(false);
      return;
    }

    setIsLookingUp(true);
    try {
      const response = await fetch(`/api/customers/lookup?phone=${encodeURIComponent(phone)}`);
      const data = await response.json();

      if (data.found && data.customer) {
        setFormData(prev => ({
          ...prev,
          name: data.customer.name || prev.name,
          email: data.customer.email || prev.email,
        }));
        setCustomerFound(true);
      } else {
        setCustomerFound(false);
      }
    } catch (error) {
      console.error('Error looking up customer:', error);
      setCustomerFound(false);
    } finally {
      setIsLookingUp(false);
    }
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPhone = e.target.value;
    setFormData({ ...formData, phone: newPhone });
    
    // Auto-lookup when phone has enough digits
    const cleanPhone = newPhone.replace(/\D/g, '');
    if (cleanPhone.length >= 10) {
      lookupCustomer(newPhone);
    } else {
      setCustomerFound(false);
    }
  };

  // Reset PIX confirmation when payment method changes
  useEffect(() => {
    if (formData.paymentMethod !== 'pix_antecipado') {
      setPixConfirmed(false);
    }
  }, [formData.paymentMethod]);

  const fetchAvailableTimes = async (date: string) => {
    setIsLoadingTimes(true);
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      const response = await fetch(`/api/appointments/available-times?date=${date}&duration=${service.duration}&t=${timestamp}`, {
        headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate' }
      });
      const data = await response.json();
      setAvailableTimes(data.available_times || []);
      
      // Reset time if it's no longer available
      if (formData.time && !data.available_times.includes(formData.time)) {
        setFormData(prev => ({ ...prev, time: '' }));
      }
    } catch (error) {
      console.error('Error fetching available times:', error);
      setAvailableTimes([]);
    } finally {
      setIsLoadingTimes(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');

    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          service_id: service.id,
          service_name: service.name,
          service_duration: service.duration,
          customer_name: formData.name,
          customer_email: formData.email,
          customer_phone: formData.phone,
          appointment_date: formData.date,
          appointment_time: formData.time,
          payment_method: formData.paymentMethod || null,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Erro ao criar agendamento');
      }

      setSubmitStatus('success');
      
      // Show notification
      try {
        await showLocalNotification('Agendamento Confirmado! ✅', {
          body: `${service.name} - ${formData.date} às ${formData.time}`,
          tag: 'appointment-created',
          requireInteraction: false
        });
      } catch (error) {
        console.log('Notificação não disponível');
      }
      
      setTimeout(() => {
        onClose();
      }, 2000);
    } catch (error) {
      setSubmitStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Erro ao criar agendamento');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-md my-8 overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 to-slate-800 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 rounded-full bg-slate-800/50 p-2 text-slate-400 transition-colors hover:bg-slate-700 hover:text-white"
          disabled={isSubmitting}
        >
          <X className="h-5 w-5" />
        </button>

        <div className="bg-gradient-to-r from-amber-500 to-amber-600 p-6">
          <h2 className="text-2xl font-bold text-white">Agendar {service.name}</h2>
          <p className="mt-1 text-sm text-amber-100">{service.description}</p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          {isOffline && (
            <div className="flex items-center gap-3 rounded-xl bg-orange-500/10 p-4 text-orange-400 border border-orange-500/20">
              <WifiOff className="h-5 w-5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-semibold">Modo Offline</p>
                <p className="text-xs text-orange-300">Seu agendamento será enviado quando a internet voltar</p>
              </div>
            </div>
          )}
          
          {submitStatus === 'success' && (
            <div className="space-y-3">
              <div className="flex items-center gap-3 rounded-xl bg-green-500/10 p-4 text-green-400 border border-green-500/20">
                <CheckCircle className="h-5 w-5 flex-shrink-0" />
                <p className="text-sm">Agendamento realizado com sucesso! Em breve você receberá uma confirmação por email.</p>
              </div>
              <div className="rounded-xl bg-amber-500/10 p-4 border border-amber-500/20">
                <p className="text-xs text-amber-300 text-center">
                  ⚠️ <strong>Não recebeu o email?</strong> Verifique sua pasta de <strong>SPAM/LIXO ELETRÔNICO</strong>
                </p>
              </div>
            </div>
          )}

          {submitStatus === 'error' && (
            <div className="flex items-center gap-3 rounded-xl bg-red-500/10 p-4 text-red-400 border border-red-500/20">
              <AlertCircle className="h-5 w-5 flex-shrink-0" />
              <p className="text-sm">{errorMessage}</p>
            </div>
          )}

          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300">
              <Phone className="h-4 w-4" />
              Telefone
              {isLookingUp && <Loader2 className="h-3 w-3 animate-spin text-amber-500" />}
            </label>
            <input
              type="tel"
              required
              value={formData.phone}
              onChange={handlePhoneChange}
              disabled={isSubmitting || submitStatus === 'success'}
              className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white placeholder-slate-500 outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
              placeholder="(00) 00000-0000"
            />
            {customerFound && (
              <p className="mt-2 text-xs text-green-400 flex items-center gap-1">
                <CheckCircle className="h-3 w-3" />
                Cliente encontrado! Dados preenchidos automaticamente
              </p>
            )}
          </div>

          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300">
              <User className="h-4 w-4" />
              Nome Completo
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              disabled={isSubmitting || submitStatus === 'success'}
              className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white placeholder-slate-500 outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
              placeholder="Seu nome"
            />
          </div>

          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300">
              <Mail className="h-4 w-4" />
              Email <span className="text-xs text-slate-500">(opcional)</span>
            </label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              disabled={isSubmitting || submitStatus === 'success'}
              className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white placeholder-slate-500 outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
              placeholder="seu@email.com"
            />
          </div>

          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300">
              <Calendar className="h-4 w-4" />
              Data
            </label>
            <input
              type="date"
              required
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              disabled={isSubmitting || submitStatus === 'success'}
              className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white placeholder-slate-500 outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>

          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300">
              <Clock className="h-4 w-4" />
              Horário
              {isLoadingTimes && <Loader2 className="h-3 w-3 animate-spin text-amber-500" />}
            </label>
            <select
              required
              value={formData.time}
              onChange={(e) => setFormData({ ...formData, time: e.target.value })}
              disabled={!formData.date || isLoadingTimes || isSubmitting || submitStatus === 'success'}
              className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <option value="">
                {!formData.date 
                  ? 'Selecione uma data primeiro'
                  : isLoadingTimes
                  ? 'Carregando horários...'
                  : availableTimes.length === 0
                  ? 'Nenhum horário disponível'
                  : 'Selecione um horário'
                }
              </option>
              {availableTimes.map((time) => (
                <option key={time} value={time}>
                  {time}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="mb-2 flex items-center gap-2 text-sm font-medium text-slate-300">
              💳 Forma de Pagamento <span className="text-xs text-slate-500">(opcional)</span>
            </label>
            <select
              value={formData.paymentMethod}
              onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
              disabled={isSubmitting || submitStatus === 'success'}
              className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <option value="">Selecione a forma de pagamento</option>
              <option value="pix_antecipado">PIX (Antecipado)</option>
              <option value="pix">PIX (Pagar na hora)</option>
              <option value="dinheiro">Dinheiro (Pagar na hora)</option>
              <option value="cartao">Cartão (Pagar na hora)</option>
            </select>
          </div>

          {formData.paymentMethod === 'pix_antecipado' && (
            <div className="rounded-xl border border-green-500/30 bg-green-500/10 p-4 space-y-3">
              <div className="flex items-center gap-2">
                <div className="rounded-lg bg-green-500 p-2">
                  <CheckCircle className="h-4 w-4 text-white" />
                </div>
                <p className="font-semibold text-green-400">Dados para Pagamento PIX</p>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="rounded-lg bg-slate-900/50 p-3 border border-slate-700">
                  <p className="text-xs text-slate-400 mb-1">Tipo de Chave:</p>
                  <p className="font-mono text-white">📱 Celular</p>
                </div>
                
                <div className="rounded-lg bg-slate-900/50 p-3 border border-slate-700">
                  <p className="text-xs text-slate-400 mb-1">Chave PIX:</p>
                  <p className="font-mono text-lg font-bold text-green-400">75 99941-2596</p>
                </div>
                
                <div className="rounded-lg bg-slate-900/50 p-3 border border-slate-700">
                  <p className="text-xs text-slate-400 mb-1">Nome:</p>
                  <p className="font-medium text-white">Jose Gilmario dos Santos Cirqueira</p>
                </div>
              </div>

              <div className="rounded-lg bg-amber-500/10 p-3 border border-amber-500/30">
                <p className="text-xs text-amber-300">
                  ⚠️ Após realizar o pagamento, seu agendamento será confirmado automaticamente.
                </p>
              </div>

              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={pixConfirmed}
                  onChange={(e) => setPixConfirmed(e.target.checked)}
                  className="mt-1 h-5 w-5 rounded border-2 border-green-500 bg-slate-900/50 text-green-500 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 focus:ring-offset-slate-900 cursor-pointer"
                  required
                />
                <span className="text-sm text-slate-200">
                  <strong className="text-green-400">Confirmo que anotei os dados</strong> e farei o pagamento PIX antes do horário agendado
                </span>
              </label>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting || submitStatus === 'success' || (formData.paymentMethod === 'pix_antecipado' && !pixConfirmed)}
            className="w-full rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 py-3 font-semibold text-white shadow-lg shadow-amber-500/25 transition-all hover:shadow-xl hover:shadow-amber-500/40 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isSubmitting && <Loader2 className="h-5 w-5 animate-spin" />}
            {isSubmitting ? 'Agendando...' : submitStatus === 'success' ? 'Agendado!' : 'Confirmar Agendamento'}
          </button>
        </form>
      </div>
    </div>
  );
}
