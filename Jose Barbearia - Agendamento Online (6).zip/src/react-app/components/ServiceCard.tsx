import * as Icons from 'lucide-react';
import { Service } from '../../data/services';

interface ServiceCardProps {
  service: Service;
  onSelect: (service: Service) => void;
}

export function ServiceCard({ service, onSelect }: ServiceCardProps) {
  const IconComponent = Icons[service.icon as keyof typeof Icons] as React.ComponentType<{ className?: string }>;

  return (
    <button
      onClick={() => onSelect(service)}
      className="group relative overflow-hidden rounded-2xl text-left transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl hover:shadow-amber-500/30"
    >
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={service.image}
          alt={service.name}
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/80 to-slate-900/40" />
      </div>

      {/* Hover Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-amber-500/20 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
      
      {/* Content */}
      <div className="relative z-10 flex h-full min-h-[200px] flex-col justify-end p-6">
        <div className="mb-3 inline-flex w-fit rounded-xl bg-amber-500/20 p-3 backdrop-blur-sm">
          <IconComponent className="h-5 w-5 text-amber-400" />
        </div>
        
        <h3 className="mb-2 text-xl font-bold text-white">{service.name}</h3>
        <p className="text-sm text-slate-300">{service.description}</p>
        <div className="mt-3 flex items-baseline gap-1">
          <span className="text-2xl font-bold text-amber-400">R$ {service.price}</span>
        </div>
      </div>
      
      {/* Bottom Glow */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-amber-500/10 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
    </button>
  );
}
