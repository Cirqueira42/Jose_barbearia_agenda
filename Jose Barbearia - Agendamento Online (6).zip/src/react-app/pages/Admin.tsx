import { useState, useMemo, useEffect } from 'react';
import { Link, useNavigate } from 'react-router';
import { Calendar, Filter, Loader2, AlertCircle, ArrowLeft, BarChart3, MessageSquare, Settings, ChevronDown, Send, DollarSign, LogOut, User, Users } from 'lucide-react';
import { useAuth } from '@getmocha/users-service/react';
import { useAppointments } from '../hooks/useAppointments';
import { AppointmentCard } from '../components/AppointmentCard';
import { MessageTemplatesPanel } from '../components/MessageTemplatesPanel';
import { ShareBookingLink } from '../components/ShareBookingLink';
import { SettingsPanel } from '../components/SettingsPanel';
import { BlockedTimesPanel } from '../components/BlockedTimesPanel';
import { PaymentsPanel } from '../components/PaymentsPanel';
import { CustomersPanel } from '../components/CustomersPanel';
import type { Appointment } from '../../shared/types';

type ViewMode = 'upcoming' | 'all';

export function Admin() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'appointments' | 'payments' | 'customers' | 'messages' | 'blocked' | 'settings'>('appointments');
  const [viewMode, setViewMode] = useState<ViewMode>('upcoming');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [dateFilter, setDateFilter] = useState<string>('');
  const [expandedDates, setExpandedDates] = useState<Set<string>>(new Set());
  
  // Get all appointments for stats (no filters)
  const { appointments: allAppointments } = useAppointments({});
  
  // Get filtered appointments for display
  const { appointments, isLoading, error, updateStatus } = useAppointments({
    status: statusFilter,
    date: dateFilter,
  });

  const handleLogout = async () => {
    await logout();
    navigate('/admin/login');
  };

  const handleStatusChange = async (id: number, status: string) => {
    try {
      await updateStatus(id, status);
    } catch (err) {
      alert('Erro ao atualizar status do agendamento');
    }
  };

  const handlePaymentStatusChange = async (id: number, paymentStatus: string) => {
    try {
      const response = await fetch(`/api/appointments/${id}/payment`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ payment_status: paymentStatus }),
      });

      if (!response.ok) {
        throw new Error('Failed to update payment status');
      }

      // Refresh appointments
      window.location.reload();
    } catch (err) {
      alert('Erro ao atualizar status do pagamento');
    }
  };

  // Group appointments by date
  const groupedAppointments = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let filtered = appointments;

    // Filter by view mode only if no date filter is active
    if (viewMode === 'upcoming' && !dateFilter) {
      filtered = appointments.filter(apt => {
        const aptDate = new Date(apt.appointment_date);
        aptDate.setHours(0, 0, 0, 0);
        return aptDate >= today && apt.status !== 'cancelled' && apt.status !== 'completed';
      });
    }

    // Group by date
    const groups = filtered.reduce((acc, appointment) => {
      const date = appointment.appointment_date;
      if (!acc[date]) {
        acc[date] = [];
      }
      acc[date].push(appointment);
      return acc;
    }, {} as Record<string, Appointment[]>);

    // Sort appointments within each group by time
    Object.keys(groups).forEach(date => {
      groups[date].sort((a, b) => {
        return a.appointment_time.localeCompare(b.appointment_time);
      });
    });

    // Sort dates
    const sortedDates = Object.keys(groups).sort((a, b) => a.localeCompare(b));

    return { groups, sortedDates };
  }, [appointments, viewMode, dateFilter]);

  // Auto-expand today, tomorrow, and any date with pending appointments
  useEffect(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const todayStr = today.toISOString().split('T')[0];
    const tomorrowStr = tomorrow.toISOString().split('T')[0];

    const newExpanded = new Set<string>();
    
    // Auto-expand today and tomorrow
    if (groupedAppointments.sortedDates.includes(todayStr)) {
      newExpanded.add(todayStr);
    }
    if (groupedAppointments.sortedDates.includes(tomorrowStr)) {
      newExpanded.add(tomorrowStr);
    }

    // Auto-expand any date with pending appointments
    groupedAppointments.sortedDates.forEach(date => {
      const dateAppointments = groupedAppointments.groups[date];
      const hasPending = dateAppointments.some(apt => apt.status === 'pending');
      if (hasPending) {
        newExpanded.add(date);
      }
    });

    setExpandedDates(newExpanded);
  }, [groupedAppointments]);

  const toggleDate = (date: string) => {
    setExpandedDates(prev => {
      const newSet = new Set(prev);
      if (newSet.has(date)) {
        newSet.delete(date);
      } else {
        newSet.add(date);
      }
      return newSet;
    });
  };

  const getDateLabel = (dateStr: string) => {
    // Fix timezone issue by appending T00:00:00
    const date = new Date(dateStr + 'T00:00:00');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    if (date.getTime() === today.getTime()) {
      return 'Hoje';
    } else if (date.getTime() === tomorrow.getTime()) {
      return 'Amanhã';
    } else {
      const dayOfWeek = date.toLocaleDateString('pt-BR', { weekday: 'long' });
      const formattedDate = date.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: 'long',
      });
      return `${dayOfWeek.charAt(0).toUpperCase() + dayOfWeek.slice(1)}, ${formattedDate}`;
    }
  };

  // Stats based on ALL appointments (not filtered)
  const stats = {
    total: allAppointments.length,
    pending: allAppointments.filter(a => a.status === 'pending').length,
    confirmed: allAppointments.filter(a => a.status === 'confirmed').length,
    completed: allAppointments.filter(a => a.status === 'completed').length,
  };

  // Count filtered results for display
  const filteredCount = appointments.length;
  const hasActiveFilters = Boolean(statusFilter || dateFilter || viewMode === 'upcoming');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div>
              <Link
                to="/"
                className="mb-2 inline-flex items-center gap-2 text-sm text-slate-400 transition-colors hover:text-amber-500"
              >
                <ArrowLeft className="h-4 w-4" />
                Voltar para o site
              </Link>
              <h1 className="text-3xl font-bold text-white">Painel Administrativo</h1>
              <p className="mt-1 text-slate-400">Gerencie os agendamentos da barbearia</p>
            </div>

            <div className="flex items-center gap-4">
              {user && (
                <div className="flex items-center gap-3 rounded-xl bg-slate-800/50 px-4 py-2 border border-slate-700">
                  <User className="h-4 w-4 text-amber-500" />
                  <span className="text-sm text-slate-300">{user.email}</span>
                </div>
              )}
              
              <Link
                to="/admin/twilio-setup"
                className="rounded-xl bg-purple-500/20 px-4 py-2 text-purple-400 transition-colors hover:bg-purple-500/30 flex items-center gap-2 border border-purple-500/30"
              >
                <Settings className="h-4 w-4" />
                Configurar WhatsApp
              </Link>

              <Link
                to="/admin/test-whatsapp"
                className="rounded-xl bg-green-500/20 px-4 py-2 text-green-400 transition-colors hover:bg-green-500/30 flex items-center gap-2 border border-green-500/30"
              >
                <Send className="h-4 w-4" />
                Testar WhatsApp
              </Link>

              <button
                onClick={handleLogout}
                className="rounded-xl bg-red-500/20 px-4 py-2 text-red-400 transition-colors hover:bg-red-500/30 flex items-center gap-2 border border-red-500/30"
              >
                <LogOut className="h-4 w-4" />
                Sair
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-800">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab('appointments')}
              className={`flex items-center gap-2 border-b-2 px-4 py-4 font-medium transition-colors ${
                activeTab === 'appointments'
                  ? 'border-amber-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-300'
              }`}
            >
              <Calendar className="h-5 w-5" />
              Agendamentos
            </button>
            <button
              onClick={() => setActiveTab('payments')}
              className={`flex items-center gap-2 border-b-2 px-4 py-4 font-medium transition-colors ${
                activeTab === 'payments'
                  ? 'border-amber-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-300'
              }`}
            >
              <DollarSign className="h-5 w-5" />
              Caixa
            </button>
            <button
              onClick={() => setActiveTab('customers')}
              className={`flex items-center gap-2 border-b-2 px-4 py-4 font-medium transition-colors ${
                activeTab === 'customers'
                  ? 'border-amber-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-300'
              }`}
            >
              <Users className="h-5 w-5" />
              Clientes
            </button>
            <button
              onClick={() => setActiveTab('messages')}
              className={`flex items-center gap-2 border-b-2 px-4 py-4 font-medium transition-colors ${
                activeTab === 'messages'
                  ? 'border-amber-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-300'
              }`}
            >
              <MessageSquare className="h-5 w-5" />
              Mensagens Automáticas
            </button>
            <button
              onClick={() => setActiveTab('blocked')}
              className={`flex items-center gap-2 border-b-2 px-4 py-4 font-medium transition-colors ${
                activeTab === 'blocked'
                  ? 'border-amber-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-300'
              }`}
            >
              <Calendar className="h-5 w-5" />
              Bloqueios
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center gap-2 border-b-2 px-4 py-4 font-medium transition-colors ${
                activeTab === 'settings'
                  ? 'border-amber-500 text-white'
                  : 'border-transparent text-slate-400 hover:text-slate-300'
              }`}
            >
              <Settings className="h-5 w-5" />
              Configurações
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {activeTab === 'payments' ? (
          <PaymentsPanel appointments={allAppointments} onUpdatePaymentStatus={handlePaymentStatusChange} />
        ) : activeTab === 'customers' ? (
          <CustomersPanel appointments={allAppointments} />
        ) : activeTab === 'messages' ? (
          <MessageTemplatesPanel appointments={allAppointments} />
        ) : activeTab === 'blocked' ? (
          <BlockedTimesPanel />
        ) : activeTab === 'settings' ? (
          <SettingsPanel />
        ) : (
          <>
            {/* Share Booking Link */}
            <div className="mb-8">
              <ShareBookingLink />
            </div>

            {/* Stats - Always show total numbers */}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-400">Total</p>
                    <p className="mt-1 text-3xl font-bold text-white">{stats.total}</p>
                  </div>
                  <div className="rounded-xl bg-slate-700/30 p-3">
                    <BarChart3 className="h-6 w-6 text-slate-400" />
                  </div>
                </div>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-yellow-500/20 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-yellow-400">Pendentes</p>
                    <p className="mt-1 text-3xl font-bold text-white">{stats.pending}</p>
                  </div>
                  <div className="rounded-xl bg-yellow-500/10 p-3">
                    <Calendar className="h-6 w-6 text-yellow-500" />
                  </div>
                </div>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-blue-500/20 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-blue-400">Confirmados</p>
                    <p className="mt-1 text-3xl font-bold text-white">{stats.confirmed}</p>
                  </div>
                  <div className="rounded-xl bg-blue-500/10 p-3">
                    <Calendar className="h-6 w-6 text-blue-500" />
                  </div>
                </div>
              </div>

              <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-green-500/20 p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-400">Concluídos</p>
                    <p className="mt-1 text-3xl font-bold text-white">{stats.completed}</p>
                  </div>
                  <div className="rounded-xl bg-green-500/10 p-3">
                    <Calendar className="h-6 w-6 text-green-500" />
                  </div>
                </div>
              </div>
            </div>

            {/* View Mode Toggle */}
            <div className="mt-8 flex gap-2">
              <button
                onClick={() => setViewMode('upcoming')}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                  viewMode === 'upcoming'
                    ? 'bg-amber-500 text-white'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                Próximos
              </button>
              <button
                onClick={() => setViewMode('all')}
                className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                  viewMode === 'all'
                    ? 'bg-amber-500 text-white'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                Todos
              </button>
            </div>

            {/* Filters */}
            <div className="mt-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 p-6">
              <div className="mb-4 flex items-center gap-2 text-slate-300">
                <Filter className="h-5 w-5" />
                <h2 className="font-semibold">Filtros</h2>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-300">Status</label>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500"
                  >
                    <option value="">Todos os status</option>
                    <option value="pending">Pendentes</option>
                    <option value="confirmed">Confirmados</option>
                    <option value="completed">Concluídos</option>
                    <option value="cancelled">Cancelados</option>
                  </select>
                </div>

                <div>
                  <label className="mb-2 block text-sm font-medium text-slate-300">Data Específica</label>
                  <input
                    type="date"
                    value={dateFilter}
                    onChange={(e) => setDateFilter(e.target.value)}
                    className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500"
                  />
                </div>
              </div>

              {(statusFilter || dateFilter) && (
                <div className="mt-4 flex items-center justify-between">
                  <p className="text-sm text-slate-400">
                    Mostrando {filteredCount} de {stats.total} agendamento{stats.total !== 1 ? 's' : ''}
                  </p>
                  <button
                    onClick={() => {
                      setStatusFilter('');
                      setDateFilter('');
                    }}
                    className="text-sm text-amber-500 transition-colors hover:text-amber-400"
                  >
                    Limpar filtros
                  </button>
                </div>
              )}
            </div>

            {/* Appointments List - Grouped by Date */}
            <div className="mt-8 space-y-6">
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
                </div>
              ) : error ? (
                <div className="flex items-center gap-3 rounded-xl bg-red-500/10 p-6 text-red-400 border border-red-500/20">
                  <AlertCircle className="h-5 w-5 flex-shrink-0" />
                  <p>{error}</p>
                </div>
              ) : groupedAppointments.sortedDates.length === 0 ? (
                <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 p-12 text-center">
                  <Calendar className="mx-auto h-12 w-12 text-slate-600" />
                  <p className="mt-4 text-slate-400">
                    {hasActiveFilters
                      ? 'Nenhum agendamento encontrado com os filtros aplicados'
                      : 'Nenhum agendamento ainda'}
                  </p>
                  {hasActiveFilters && (
                    <button
                      onClick={() => {
                        setStatusFilter('');
                        setDateFilter('');
                        setViewMode('all');
                      }}
                      className="mt-4 text-sm text-amber-500 hover:text-amber-400"
                    >
                      Limpar todos os filtros
                    </button>
                  )}
                </div>
              ) : (
                <>
                  {hasActiveFilters && (
                    <div className="rounded-xl bg-blue-500/10 border border-blue-500/20 p-4 text-blue-400">
                      <p className="text-sm">
                        Mostrando {filteredCount} agendamento{filteredCount !== 1 ? 's' : ''} filtrado{filteredCount !== 1 ? 's' : ''}
                      </p>
                    </div>
                  )}
                  {groupedAppointments.sortedDates.map((date) => {
                    const dateAppointments = groupedAppointments.groups[date];
                    const isExpanded = expandedDates.has(date);
                    const pendingCount = dateAppointments.filter(a => a.status === 'pending').length;
                    const confirmedCount = dateAppointments.filter(a => a.status === 'confirmed').length;

                    return (
                      <div key={date} className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 overflow-hidden">
                        {/* Date Header */}
                        <button
                          onClick={() => toggleDate(date)}
                          className="w-full flex items-center justify-between p-6 text-left hover:bg-slate-800/50 transition-colors"
                        >
                          <div>
                            <h3 className="text-lg font-semibold text-white">{getDateLabel(date)}</h3>
                            <div className="mt-1 flex items-center gap-4 text-sm text-slate-400">
                              <span>{dateAppointments.length} {dateAppointments.length === 1 ? 'agendamento' : 'agendamentos'}</span>
                              {pendingCount > 0 && (
                                <span className="text-yellow-400">• {pendingCount} pendente{pendingCount !== 1 && 's'}</span>
                              )}
                              {confirmedCount > 0 && (
                                <span className="text-blue-400">• {confirmedCount} confirmado{confirmedCount !== 1 && 's'}</span>
                              )}
                            </div>
                          </div>
                          <ChevronDown
                            className={`h-5 w-5 text-slate-400 transition-transform ${
                              isExpanded ? 'rotate-180' : ''
                            }`}
                          />
                        </button>

                        {/* Appointments */}
                        {isExpanded && (
                          <div className="border-t border-slate-700/50 p-6">
                            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                              {dateAppointments.map((appointment) => (
                                <AppointmentCard
                                  key={appointment.id}
                                  appointment={appointment}
                                  onStatusChange={handleStatusChange}
                                />
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
