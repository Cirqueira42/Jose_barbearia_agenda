import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { Scissors, MapPin, Instagram, Settings, MessageCircle, Calendar } from 'lucide-react';
import { ServiceCard } from '../components/ServiceCard';
import { BookingModal } from '../components/BookingModal';
import { PhotoGallery } from '../components/PhotoGallery';
import { LocationMap } from '../components/LocationMap';
import { PomadesPanel } from '../components/PomadesPanel';

interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: number;
  icon: string;
  image: string;
}

interface BusinessInfo {
  business_name: string;
  barber_name: string;
  business_address: string;
  instagram: string;
  instagram_url: string;
  whatsapp: string;
}

export function Home() {
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [servicesRes, settingsRes] = await Promise.all([
        fetch('/api/services-config'),
        fetch('/api/settings'),
      ]);

      if (servicesRes.ok) {
        const data = await servicesRes.json();
        setServices(data);
      }

      if (settingsRes.ok) {
        const data = await settingsRes.json();
        setBusinessInfo(data);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    }
  };

  if (!businessInfo) {
    return null;
  }

  const whatsappMessage = `Olá! Gostaria de agendar um horário na ${businessInfo.business_name}.\n\nLink do agendamento: ${window.location.origin}`;
  const whatsappUrl = `https://wa.me/${businessInfo.whatsapp}?text=${encodeURIComponent(whatsappMessage)}`;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* WhatsApp Floating Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 left-6 z-40 flex items-center gap-2 rounded-full bg-gradient-to-r from-green-500 to-green-600 px-5 py-3 font-semibold text-white shadow-xl shadow-green-500/25 transition-all hover:shadow-2xl hover:shadow-green-500/40"
        title="Agendar pelo WhatsApp"
      >
        <MessageCircle className="h-5 w-5" />
        WhatsApp
      </a>

      {/* Admin Link */}
      <Link
        to="/admin/login"
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 px-5 py-3 font-semibold text-white shadow-xl shadow-amber-500/25 transition-all hover:shadow-2xl hover:shadow-amber-500/40"
      >
        <Settings className="h-5 w-5" />
        Admin
      </Link>

      {/* Hero Section */}
      <div className="relative overflow-hidden border-b border-slate-800 bg-gradient-to-br from-slate-900 to-slate-800">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-40" />
        
        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="mb-6 inline-flex rounded-2xl bg-amber-500/10 p-4 backdrop-blur-sm">
              <Scissors className="h-12 w-12 text-amber-500" />
            </div>
            
            <h1 className="mb-4 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 bg-clip-text text-5xl font-bold text-transparent sm:text-6xl">
              {businessInfo.business_name}
            </h1>
            
            <p className="mx-auto mb-8 max-w-2xl text-lg text-slate-400">
              Agende seu horário e venha viver a melhor experiência em barbearia
            </p>

            {/* Quick Booking Button */}
            <div className="mb-8">
              <Link
                to="/agendar"
                className="inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 px-8 py-4 text-lg font-bold text-white shadow-2xl shadow-amber-500/40 transition-all hover:scale-105 hover:shadow-3xl hover:shadow-amber-500/50"
              >
                <Calendar className="h-6 w-6" />
                Agendar Horário Online
              </Link>
              <p className="mt-3 text-sm text-slate-500">
                Acesse: {window.location.origin}/agendar
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-6 text-slate-400">
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5 text-amber-500" />
                <span className="text-sm">{businessInfo.business_address}</span>
              </div>
              
              <a
                href={businessInfo.instagram_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 rounded-full bg-slate-800/50 px-4 py-2 transition-colors hover:bg-slate-700"
              >
                <Instagram className="h-5 w-5 text-amber-500" />
                <span className="text-sm">{businessInfo.instagram}</span>
              </a>
            </div>
          </div>
        </div>

        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-500/50 to-transparent" />
      </div>

      {/* Pomades Sales Panel */}
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <PomadesPanel />
      </div>

      {/* Services Section */}
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mb-12 text-center">
          <h2 className="mb-3 text-3xl font-bold text-white">Nossos Serviços</h2>
          <p className="text-slate-400">Escolha o serviço e agende seu horário</p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {services.map((service) => (
            <ServiceCard
              key={service.id}
              service={service}
              onSelect={setSelectedService}
            />
          ))}
        </div>
      </div>

      {/* Photo Gallery Section */}
      <div className="border-t border-slate-800 bg-slate-900/30 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <h2 className="mb-3 text-3xl font-bold text-white">Nossa Barbearia</h2>
            <p className="text-slate-400">Conheça nosso espaço profissional</p>
          </div>

          <PhotoGallery />
        </div>
      </div>

      {/* Location Section */}
      <div className="border-t border-slate-800 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="mb-12 text-center">
            <h2 className="mb-3 text-3xl font-bold text-white">Nossa Localização</h2>
            <p className="text-slate-400">Visite-nos em Guariba - SP</p>
          </div>

          <div className="grid gap-8 lg:grid-cols-2">
            <div className="space-y-6">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
                <h3 className="mb-4 text-xl font-semibold text-white">Endereço</h3>
                <p className="flex items-start gap-3 text-slate-300">
                  <MapPin className="mt-1 h-5 w-5 flex-shrink-0 text-amber-500" />
                  <span>{businessInfo.business_address}</span>
                </p>
              </div>

              <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
                <h3 className="mb-4 text-xl font-semibold text-white">Como Chegar</h3>
                <p className="mb-4 text-slate-300">
                  Estamos localizados na Av. Otávio Rangel, próximo ao centro de Guariba.
                  Fácil acesso e estacionamento disponível.
                </p>
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(businessInfo.business_address)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-lg bg-amber-500 px-4 py-2 font-semibold text-white transition-all hover:bg-amber-600"
                >
                  <MapPin className="h-4 w-4" />
                  Abrir no Google Maps
                </a>
              </div>
            </div>

            <LocationMap address={businessInfo.business_address} name={businessInfo.business_name} />
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-slate-800 bg-slate-900/50 py-8">
        <div className="mx-auto max-w-7xl px-4 text-center text-sm text-slate-500">
          <p>© 2024 {businessInfo.business_name}. Todos os direitos reservados.</p>
        </div>
      </div>

      {/* Booking Modal */}
      {selectedService && (
        <BookingModal
          service={selectedService}
          onClose={() => setSelectedService(null)}
        />
      )}
    </div>
  );
}
