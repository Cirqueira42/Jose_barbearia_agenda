import { useState } from 'react';
import { Send, Loader2, CheckCircle, AlertCircle, ArrowLeft, LogOut } from 'lucide-react';
import { Link, useNavigate } from 'react-router';
import { useAuth } from '@getmocha/users-service/react';

export default function TestWhatsApp() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  
  const handleLogout = async () => {
    await logout();
    navigate('/admin/login');
  };
  const [phone, setPhone] = useState('5516997369740');
  const [message, setMessage] = useState('');
  const [isTesting, setIsTesting] = useState(false);
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
    details?: any;
  } | null>(null);

  const handleTest = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsTesting(true);
    setResult(null);

    try {
      const response = await fetch('/api/test-whatsapp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          phone,
          message: message || undefined,
        }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setResult({
          success: true,
          message: 'WhatsApp enviado com sucesso! Verifique seu telefone.',
          details: data,
        });
      } else {
        setResult({
          success: false,
          message: data.error || 'Erro ao enviar WhatsApp',
          details: data,
        });
      }
    } catch (error) {
      setResult({
        success: false,
        message: error instanceof Error ? error.message : 'Erro desconhecido',
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link
            to="/admin"
            className="inline-flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Voltar para Admin
          </Link>

          <button
            onClick={handleLogout}
            className="rounded-xl bg-red-500/20 px-4 py-2 text-red-400 transition-colors hover:bg-red-500/30 flex items-center gap-2 border border-red-500/30"
          >
            <LogOut className="h-4 w-4" />
            Sair
          </button>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-3xl shadow-2xl overflow-hidden border border-slate-700">
            <div className="bg-gradient-to-r from-green-500 to-green-600 p-6">
              <h1 className="text-3xl font-bold text-white flex items-center gap-3">
                <Send className="h-8 w-8" />
                Testar WhatsApp
              </h1>
              <p className="mt-2 text-green-100">
                Teste o envio de mensagens WhatsApp para verificar a configuração
              </p>
            </div>

            <div className="p-8">
              <form onSubmit={handleTest} className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Telefone (com código do país)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="5516997369740"
                    className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white placeholder-slate-500 outline-none ring-2 ring-slate-700 transition-all focus:ring-green-500"
                    required
                  />
                  <p className="mt-2 text-xs text-slate-400">
                    Formato: código do país + DDD + número (ex: 5516997369740)
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Mensagem (opcional)
                  </label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Digite uma mensagem personalizada ou deixe em branco para usar a mensagem padrão"
                    rows={4}
                    className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white placeholder-slate-500 outline-none ring-2 ring-slate-700 transition-all focus:ring-green-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isTesting}
                  className="w-full rounded-xl bg-gradient-to-r from-green-500 to-green-600 py-3 font-semibold text-white shadow-lg shadow-green-500/25 transition-all hover:shadow-xl hover:shadow-green-500/40 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isTesting ? (
                    <>
                      <Loader2 className="h-5 w-5 animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    <>
                      <Send className="h-5 w-5" />
                      Enviar Teste
                    </>
                  )}
                </button>
              </form>

              {result && (
                <div
                  className={`mt-6 rounded-xl border p-4 ${
                    result.success
                      ? 'bg-green-500/10 border-green-500/20 text-green-400'
                      : 'bg-red-500/10 border-red-500/20 text-red-400'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {result.success ? (
                      <CheckCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="h-5 w-5 flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <p className="font-medium">{result.message}</p>
                      {result.details && (
                        <details className="mt-3">
                          <summary className="cursor-pointer text-sm opacity-75 hover:opacity-100">
                            Ver detalhes técnicos
                          </summary>
                          <pre className="mt-2 text-xs bg-slate-900/50 p-3 rounded-lg overflow-x-auto">
                            {JSON.stringify(result.details, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-8 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                <h3 className="font-semibold text-amber-400 mb-2">
                  ⚠️ Erro Comum: Código 63007
                </h3>
                <p className="text-sm text-amber-300 mb-3">
                  Se você receber o erro "Twilio could not find a Channel with the specified From address", significa que o número WhatsApp não está configurado corretamente no Twilio.
                </p>
                <h4 className="font-semibold text-amber-400 mb-2 text-sm">
                  Como resolver:
                </h4>
                <ol className="text-sm text-amber-300 space-y-2 list-decimal list-inside">
                  <li>
                    <strong>Para teste (Sandbox):</strong>
                    <ul className="ml-6 mt-1 space-y-1 list-disc list-inside">
                      <li>Acesse o Twilio Console → Messaging → Try it out → Send a WhatsApp message</li>
                      <li>Você verá um código como "join abc-xyz"</li>
                      <li>Envie essa mensagem para o número do Sandbox (geralmente +14155238886)</li>
                      <li>Use esse número de Sandbox em TWILIO_WHATSAPP_NUMBER</li>
                      <li>Teste enviando para o número que enviou "join"</li>
                    </ul>
                  </li>
                  <li className="mt-2">
                    <strong>Para produção:</strong>
                    <ul className="ml-6 mt-1 space-y-1 list-disc list-inside">
                      <li>Você precisa de um número WhatsApp Business aprovado pela Twilio</li>
                      <li>Processo de aprovação pode levar alguns dias</li>
                      <li>Requer verificação de negócio</li>
                    </ul>
                  </li>
                </ol>
              </div>

              <div className="mt-4 p-4 bg-blue-500/10 border border-blue-500/20 rounded-xl">
                <h3 className="font-semibold text-blue-400 mb-2">
                  📋 Checklist de Configuração
                </h3>
                <ul className="text-sm text-blue-300 space-y-1">
                  <li>✓ Conta Twilio criada</li>
                  <li>✓ Secrets configuradas no Mocha (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_WHATSAPP_NUMBER)</li>
                  <li>⚠️ <strong>Sandbox ativado:</strong> Enviar "join &lt;código&gt;" para o número do Twilio</li>
                  <li>⚠️ <strong>Formato do número:</strong> Deve incluir + no início (ex: +14155238886)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
