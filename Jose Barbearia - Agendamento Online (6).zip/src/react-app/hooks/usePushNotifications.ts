import { useState, useEffect } from 'react';

export function usePushNotifications() {
  const [permission, setPermission] = useState<NotificationPermission>('default');
  const [isSupported, setIsSupported] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);

  useEffect(() => {
    // Check if notifications are supported
    const supported = 'Notification' in window && 'serviceWorker' in navigator;
    setIsSupported(supported);

    if (supported) {
      setPermission(Notification.permission);
      checkSubscription();
    }
  }, []);

  const checkSubscription = async () => {
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      setIsSubscribed(!!subscription);
    } catch (error) {
      console.error('Erro ao verificar inscrição:', error);
    }
  };

  const requestPermission = async () => {
    if (!isSupported) {
      alert('Notificações não são suportadas neste navegador');
      return false;
    }

    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      
      if (result === 'granted') {
        console.log('✅ Permissão de notificação concedida');
        return true;
      } else {
        console.log('❌ Permissão de notificação negada');
        return false;
      }
    } catch (error) {
      console.error('Erro ao solicitar permissão:', error);
      return false;
    }
  };

  const subscribe = async () => {
    if (permission !== 'granted') {
      const granted = await requestPermission();
      if (!granted) return;
    }

    try {
      const registration = await navigator.serviceWorker.ready;
      
      // For demo purposes, we'll use a simple subscription without VAPID
      // In production, you would need to implement VAPID keys
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: null // Would need VAPID public key in production
      });

      console.log('✅ Inscrito para notificações push');
      setIsSubscribed(true);
      
      // In production, you would send this subscription to your server
      // await fetch('/api/push/subscribe', {
      //   method: 'POST',
      //   body: JSON.stringify(subscription)
      // });
      
      return subscription;
    } catch (error) {
      console.error('Erro ao se inscrever:', error);
      // Fallback to local notifications only
      setIsSubscribed(true); // Mark as "subscribed" for local notifications
    }
  };

  const unsubscribe = async () => {
    try {
      const registration = await navigator.serviceWorker.ready;
      const subscription = await registration.pushManager.getSubscription();
      
      if (subscription) {
        await subscription.unsubscribe();
        console.log('✅ Desinscrito das notificações push');
      }
      
      setIsSubscribed(false);
    } catch (error) {
      console.error('Erro ao desinscrever:', error);
    }
  };

  const showLocalNotification = async (title: string, options?: NotificationOptions) => {
    if (permission !== 'granted') {
      console.warn('Permissão de notificação não concedida');
      return;
    }

    try {
      const registration = await navigator.serviceWorker.ready;
      await registration.showNotification(title, {
        icon: 'https://019bf529-b591-752d-993e-177e1485a68e.mochausercontent.com/icon-192.png',
        badge: 'https://019bf529-b591-752d-993e-177e1485a68e.mochausercontent.com/icon-192.png',
        ...options
      });
    } catch (error) {
      console.error('Erro ao mostrar notificação:', error);
    }
  };

  return {
    permission,
    isSupported,
    isSubscribed,
    requestPermission,
    subscribe,
    unsubscribe,
    showLocalNotification
  };
}
