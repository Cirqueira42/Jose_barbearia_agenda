import { useState, useEffect } from 'react';

interface PendingAppointment {
  timestamp: number;
  synced: boolean;
  service_id: string;
  service_name: string;
  customer_name: string;
  appointment_date: string;
  appointment_time: string;
}

export function useOfflineSync() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [pendingCount, setPendingCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      console.log('🌐 Conexão restaurada!');
      setIsOnline(true);
      triggerSync();
    };

    const handleOffline = () => {
      console.log('📴 Sem conexão');
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Check pending appointments on mount
    checkPendingAppointments();

    // Periodic check
    const interval = setInterval(checkPendingAppointments, 5000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, []);

  const checkPendingAppointments = async () => {
    try {
      const db = await openDB();
      const tx = db.transaction('pending', 'readonly');
      const store = tx.objectStore('pending');
      const request = store.getAll();
      
      const all = await new Promise<PendingAppointment[]>((resolve, reject) => {
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
      
      const pending = all.filter((a: PendingAppointment) => !a.synced);
      setPendingCount(pending.length);
    } catch (error) {
      // IndexedDB might not be available
      setPendingCount(0);
    }
  };

  const triggerSync = async () => {
    if (isSyncing) return;
    
    setIsSyncing(true);
    
    try {
      // Try to register background sync
      if ('serviceWorker' in navigator) {
        const registration = await navigator.serviceWorker.ready;
        
        // Check if sync is supported
        if ('sync' in registration) {
          await (registration as any).sync.register('sync-appointments');
          console.log('🔄 Background sync registrado');
        } else {
          // Fallback: trigger sync via message
          if (navigator.serviceWorker.controller) {
            navigator.serviceWorker.controller.postMessage({
              type: 'SYNC_NOW'
            });
          }
        }
      }
      
      // Wait a bit then check again
      setTimeout(checkPendingAppointments, 2000);
    } catch (error) {
      console.error('Erro ao sincronizar:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  return {
    isOnline,
    pendingCount,
    isSyncing,
    triggerSync,
    checkPendingAppointments
  };
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('jose-barbearia-offline', 1);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('pending')) {
        db.createObjectStore('pending', { keyPath: 'timestamp' });
      }
    };
  });
}
