import { sendWhatsAppConfirmation, sendWhatsAppCancellationToBarber } from './whatsapp';

export async function handleTwilioWebhook(
  body: FormData,
  env: Env
): Promise<string> {
  try {
    console.log('📩 Twilio webhook received');

    // Get message details from Twilio webhook
    const from = body.get('From')?.toString() || '';
    const messageBody = body.get('Body')?.toString() || '';
    const messageSid = body.get('MessageSid')?.toString() || '';

    console.log('Message from:', from);
    console.log('Message body:', messageBody);
    console.log('Message SID:', messageSid);

    // Extract phone number (remove "whatsapp:" prefix)
    const phoneNumber = from.replace('whatsapp:', '').replace('+', '');

    // Get barber WhatsApp from settings
    const barberWhatsAppSetting = await env.DB.prepare(
      "SELECT value FROM settings WHERE key = 'whatsapp'"
    ).first<{ value: string }>();
    const barberWhatsApp = barberWhatsAppSetting?.value?.replace(/\D/g, '');

    console.log('Barber WhatsApp:', barberWhatsApp);
    console.log('Sender phone:', phoneNumber);

    // Check if message is from the barber
    if (barberWhatsApp && phoneNumber.includes(barberWhatsApp)) {
      console.log('✅ Message is from barber, processing...');

      // Check if message contains confirmation keywords
      const confirmationKeywords = [
        'confirmar',
        'confirmado',
        'confirmo',
        'ok',
        'sim',
        'pode ser',
        'beleza',
        'certo',
        'aceito'
      ];

      const messageBodyLower = messageBody.toLowerCase();
      const isConfirmation = confirmationKeywords.some(keyword => 
        messageBodyLower.includes(keyword)
      );

      if (isConfirmation) {
        console.log('🎯 Confirmation detected, looking for pending appointments...');

        // Get the most recent pending appointment
        const appointment = await env.DB.prepare(
          `SELECT * FROM appointments 
           WHERE status = 'pending' 
           ORDER BY created_at DESC 
           LIMIT 1`
        ).first();

        if (appointment) {
          console.log('📋 Found pending appointment:', appointment.id);

          // Update appointment status to confirmed
          await env.DB.prepare(
            "UPDATE appointments SET status = 'confirmed', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
          ).bind(appointment.id).run();

          console.log('✅ Appointment confirmed in database');

          // Send confirmation to customer
          await sendWhatsAppConfirmation(
            env.TWILIO_ACCOUNT_SID,
            env.TWILIO_AUTH_TOKEN,
            env.TWILIO_WHATSAPP_NUMBER,
            {
              customer_name: appointment.customer_name as string,
              customer_phone: appointment.customer_phone as string,
              service_name: appointment.service_name as string,
              appointment_date: appointment.appointment_date as string,
              appointment_time: appointment.appointment_time as string
            }
          );

          console.log('✅ Confirmation sent to customer');

          // Respond to barber
          return `✅ Agendamento confirmado! Notificação enviada para ${appointment.customer_name}.`;
        } else {
          console.log('⚠️ No pending appointments found');
          return '⚠️ Não há agendamentos pendentes para confirmar.';
        }
      } else {
        console.log('ℹ️ Message does not contain confirmation keywords');
        return ''; // Don't respond to non-confirmation messages
      }
    } else {
      console.log('ℹ️ Message is from customer, processing...');
      
      // Check if message contains cancellation keywords
      const cancellationKeywords = [
        'cancelar',
        'cancela',
        'desmarcar',
        'desmarca',
        'não vou',
        'nao vou',
        'não posso',
        'nao posso',
        'desistir',
        'desisto'
      ];

      const messageBodyLower = messageBody.toLowerCase();
      const isCancellation = cancellationKeywords.some(keyword => 
        messageBodyLower.includes(keyword)
      );

      if (isCancellation) {
        console.log('🚫 Cancellation request detected from customer');

        // Find the customer's most recent confirmed or pending appointment
        const appointment = await env.DB.prepare(
          `SELECT * FROM appointments 
           WHERE customer_phone LIKE ? 
           AND (status = 'confirmed' OR status = 'pending')
           AND appointment_date >= date('now')
           ORDER BY appointment_date ASC, appointment_time ASC 
           LIMIT 1`
        ).bind(`%${phoneNumber.slice(-9)}%`).first();

        if (appointment) {
          console.log('📋 Found appointment to cancel:', appointment.id);

          // Update appointment status to cancelled
          await env.DB.prepare(
            "UPDATE appointments SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
          ).bind(appointment.id).run();

          console.log('✅ Appointment cancelled in database');

          // Notify barber about cancellation
          if (barberWhatsApp) {
            try {
              const baseUrl = 'https://e4id45fo46lti.mocha.app'; // Your published app URL

              await sendWhatsAppCancellationToBarber(
                env.TWILIO_ACCOUNT_SID,
                env.TWILIO_AUTH_TOKEN,
                env.TWILIO_WHATSAPP_NUMBER,
                barberWhatsApp,
                {
                  id: appointment.id as number,
                  customer_name: appointment.customer_name as string,
                  customer_phone: appointment.customer_phone as string,
                  service_name: appointment.service_name as string,
                  appointment_date: appointment.appointment_date as string,
                  appointment_time: appointment.appointment_time as string
                },
                baseUrl
              );
              console.log('✅ Barber notified about cancellation');
            } catch (error) {
              console.error('❌ Failed to notify barber:', error);
            }
          }

          // Confirm cancellation to customer
          const formattedDate = new Date(appointment.appointment_date as string).toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: 'long',
            year: 'numeric'
          });

          return `✅ Seu agendamento foi cancelado com sucesso.

📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}
✂️ *Serviço:* ${appointment.service_name}

Para reagendar, faça um novo agendamento através do nosso site.

Esperamos vê-lo em breve! 💈`;
        } else {
          console.log('⚠️ No upcoming appointments found for this customer');
          return '⚠️ Não encontramos agendamentos futuros para este telefone.';
        }
      }
      
      // For other customer messages, don't respond
      return '';
    }
  } catch (error) {
    console.error('❌ Error in Twilio webhook:', error);
    return '❌ Erro ao processar mensagem.';
  }
}
