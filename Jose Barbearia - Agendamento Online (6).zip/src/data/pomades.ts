export interface Pomade {
  id: string;
  name: string;
  price: number;
  icon: string;
  image?: string;
}

export const pomades: Pomade[] = [
  {
    id: 'cera_extra_forte',
    name: 'Cera Extra Forte',
    price: 17.99,
    icon: '💪',
    image: 'https://019bf0a2-5b36-7617-85bc-4d94795f6dfa.mochausercontent.com/pomade-extra-strong.png',
  },
  {
    id: 'cera_forte',
    name: 'Cera Forte',
    price: 17.99,
    icon: '🔥',
    image: 'https://019bf0a2-5b36-7617-85bc-4d94795f6dfa.mochausercontent.com/pomade-strong.png',
  },
  {
    id: 'cera_media',
    name: 'Cera Média',
    price: 17.99,
    icon: '✨',
    image: 'https://019bf0a2-5b36-7617-85bc-4d94795f6dfa.mochausercontent.com/pomade-medium.png',
  },
  {
    id: 'gel_efeito_molhado',
    name: 'Gel Efeito Molhado',
    price: 17.99,
    icon: '💧',
    image: 'https://019bf0a2-5b36-7617-85bc-4d94795f6dfa.mochausercontent.com/pomade-wet-gel.png',
  },
  {
    id: 'pomada_brilho',
    name: 'Pomada com Brilho',
    price: 17.99,
    icon: '⭐',
    image: 'https://019bf0a2-5b36-7617-85bc-4d94795f6dfa.mochausercontent.com/pomade-shine.png',
  },
];

export const barbershopPhotos = {
  interior: 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/barbershop-interior.png',
  facade: 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/barbershop-facade.png',
};
