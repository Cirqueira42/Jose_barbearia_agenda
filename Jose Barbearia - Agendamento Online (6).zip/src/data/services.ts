export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: number; // Duration in minutes
  icon: string;
  image: string;
}

export const services: Service[] = [
  {
    id: 'corte',
    name: 'Corte',
    description: 'Corte moderno e estiloso',
    price: 30,
    duration: 30,
    icon: 'Scissors',
    image: 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-haircut.png',
  },
  {
    id: 'barba',
    name: 'Barba',
    description: 'Barba profissional e bem feita',
    price: 20,
    duration: 20,
    icon: 'Sparkles',
    image: 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-beard.png',
  },
  {
    id: 'combo',
    name: 'Corte + Barba',
    description: 'Pacote completo: corte moderno + barba bem feita',
    price: 45,
    duration: 50,
    icon: 'Package',
    image: 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-combo.png',
  },
  {
    id: 'corte-infantil',
    name: 'Corte Infantil',
    description: 'Corte infantil com cuidado especial',
    price: 25,
    duration: 30,
    icon: 'Baby',
    image: 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-kids.png',
  },

  {
    id: 'sobrancelha',
    name: 'Sobrancelha',
    description: 'Design de sobrancelha perfeito',
    price: 10,
    duration: 10,
    icon: 'Eye',
    image: 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-eyebrow.png',
  },
  {
    id: 'pezinho',
    name: 'Pezinho',
    description: 'Finalização perfeita',
    price: 10,
    duration: 10,
    icon: 'Sparkle',
    image: 'https://019be89d-c6df-7b16-b1fa-c4c983cb1166.mochausercontent.com/service-fade.png',
  },
];

export const businessInfo = {
  name: 'José Barbearia',
  barber: 'José Gilmario',
  address: 'Av. Otávio Rangel, 477 - Vila Cecap, Guariba - SP, 14845-106',
  instagram: '@josebarbeariaa',
  instagramUrl: 'https://www.instagram.com/josebarbeariaa/',
  whatsapp: '16997369740',
};
