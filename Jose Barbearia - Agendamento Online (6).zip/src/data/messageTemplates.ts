export interface MessageTemplate {
  id: string;
  name: string;
  subject: string;
  category: 'welcome' | 'reminder' | 'confirmation' | 'thankyou' | 'followup' | 'promotional';
  message: string;
  variables: string[];
}

export const messageTemplates: MessageTemplate[] = [
  {
    id: 'welcome',
    name: 'Boas-vindas',
    subject: 'Bem-vindo à Jose Barbearia! 🎉',
    category: 'welcome',
    message: `Olá {{customer_name}}!

Seja muito bem-vindo à Jose Barbearia! 🎊

Ficamos muito felizes em tê-lo conosco. Nossa missão é proporcionar a melhor experiência em cuidados masculinos, com profissionalismo e atenção aos detalhes.

📍 Estamos localizados na Av. Otávio Rangel, 477 - Vila Cecap, Guariba - SP

⏰ Agende seu horário através do nosso site e venha viver a melhor experiência em barbearia!

Siga-nos no Instagram @josebarbeariaa para ver nossos trabalhos e novidades.

Até breve!
Jose Barbearia`,
    variables: ['customer_name'],
  },
  {
    id: 'reminder-24h',
    name: 'Lembrete 24h antes',
    subject: 'Lembrete: Seu agendamento é amanhã! ⏰',
    category: 'reminder',
    message: `Olá {{customer_name}}!

Este é um lembrete sobre seu agendamento amanhã:

📅 Data: {{appointment_date}}
🕐 Horário: {{appointment_time}}
✂️ Serviço: {{service_name}}

📍 Endereço:
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

❌ Precisa cancelar?
{{cancel_url}}

Estamos te esperando! 🙌

Jose Barbearia`,
    variables: ['customer_name', 'appointment_date', 'appointment_time', 'service_name', 'cancel_url'],
  },
  {
    id: 'reminder-45min',
    name: 'Lembrete 45 minutos antes',
    subject: '⏰ Seu horário é em 45 minutos! - Jose Barbearia',
    category: 'reminder',
    message: `Oi {{customer_name}}!

🔔 Seu horário é em 45 minutos! Não se atrase! 😊

🕐 Horário: {{appointment_time}}
✂️ Serviço: {{service_name}}

📍 Endereço:
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

⏰ Por favor, chegue com 10 minutos de antecedência para garantir que seja atendido no horário agendado.

❌ Precisa cancelar?
{{cancel_url}}

Estamos te esperando!
Jose Barbearia`,
    variables: ['customer_name', 'appointment_time', 'service_name', 'cancel_url'],
  },
  {
    id: 'reminder-2h',
    name: 'Lembrete 2h antes',
    subject: 'Lembrete: Seu horário é daqui a 2 horas! ⏰',
    category: 'reminder',
    message: `Oi {{customer_name}}!

Seu horário é daqui a 2 horas! Não se esqueça! 😊

🕐 Horário: {{appointment_time}}
✂️ Serviço: {{service_name}}

📍 Endereço:
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

Chegue com alguns minutos de antecedência. Estamos te esperando!

❌ Precisa cancelar?
{{cancel_url}}

Jose Barbearia`,
    variables: ['customer_name', 'appointment_time', 'service_name', 'cancel_url'],
  },
  {
    id: 'confirmation',
    name: 'Confirmação de Agendamento',
    subject: '✅ Agendamento Confirmado - Jose Barbearia',
    category: 'confirmation',
    message: `Olá {{customer_name}}!

Seu agendamento foi confirmado com sucesso! ✅

📅 Data: {{appointment_date}}
🕐 Horário: {{appointment_time}}
✂️ Serviço: {{service_name}}

📍 Endereço:
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

Você receberá um lembrete antes do seu horário.

Caso precise cancelar ou reagendar, entre em contato conosco pelo Instagram @josebarbeariaa

Até breve!
Jose Barbearia`,
    variables: ['customer_name', 'appointment_date', 'appointment_time', 'service_name'],
  },
  {
    id: 'thankyou',
    name: 'Agradecimento pós-atendimento',
    subject: 'Obrigado pela visita! 💈',
    category: 'thankyou',
    message: `Olá {{customer_name}}!

Muito obrigado por escolher a Jose Barbearia! 🙏

Esperamos que tenha gostado do nosso atendimento e do resultado final. Sua satisfação é nossa maior recompensa!

📸 Que tal compartilhar uma foto do resultado nas redes sociais? Não esqueça de nos marcar @josebarbeariaa

⭐ Sua opinião é muito importante! Deixe seu feedback e ajude outros clientes a conhecerem nosso trabalho.

🔄 Agende seu próximo horário para manter o visual sempre em dia!

Até a próxima!
Jose Barbearia`,
    variables: ['customer_name'],
  },
  {
    id: 'followup-week',
    name: 'Follow-up após 1 semana',
    subject: 'Como está o seu corte? 💇‍♂️',
    category: 'followup',
    message: `Olá {{customer_name}}!

Já faz uma semana desde seu último atendimento conosco. Como está o seu corte? Esperamos que esteja tudo perfeito! 😊

✨ Dica profissional: Para manter o estilo sempre impecável, recomendamos agendar seu próximo corte a cada 3-4 semanas.

📅 Que tal já garantir seu próximo horário? Acesse nosso site e escolha o melhor dia e hora para você!

Se tiver qualquer dúvida ou sugestão, estamos sempre à disposição pelo Instagram @josebarbeariaa

Abraço!
Jose Barbearia`,
    variables: ['customer_name'],
  },
  {
    id: 'promotional',
    name: 'Mensagem Promocional',
    subject: '🎁 Oferta Especial Jose Barbearia!',
    category: 'promotional',
    message: `Olá {{customer_name}}!

Temos uma oferta especial para você! 🎊

🔥 [Descrição da promoção]

📅 Válido até: [Data]

⚡ Não perca! Agende agora através do nosso site e garanta essa oportunidade.

📍 Av. Otávio Rangel, 477 - Vila Cecap, Guariba - SP
📱 @josebarbeariaa

Te esperamos!
Jose Barbearia`,
    variables: ['customer_name'],
  },
  {
    id: 'no-show',
    name: 'Cliente não compareceu',
    subject: 'Sentimos sua falta hoje 😔',
    category: 'followup',
    message: `Olá {{customer_name}},

Percebemos que você não pode comparecer ao seu agendamento de hoje às {{appointment_time}}.

Esperamos que esteja tudo bem! 🙏

Caso tenha tido algum imprevisto, fique à vontade para reagendar através do nosso site. Estamos sempre prontos para atendê-lo.

Se precisar de ajuda com o agendamento, entre em contato pelo Instagram @josebarbeariaa

Até breve!
Jose Barbearia`,
    variables: ['customer_name', 'appointment_time'],
  },
  {
    id: 'birthday',
    name: 'Feliz Aniversário',
    subject: '🎂 Feliz Aniversário da Jose Barbearia!',
    category: 'promotional',
    message: `Parabéns, {{customer_name}}! 🎉🎂

A equipe da Jose Barbearia deseja um feliz aniversário! Que este novo ano seja repleto de saúde, sucesso e muito estilo! ✨

🎁 Como presente, estamos oferecendo [desconto/brinde especial] para você usar em sua próxima visita!

Válido durante todo o mês do seu aniversário.

📅 Agende já pelo nosso site e venha comemorar com a gente!

Abraço e felicidades!
Jose Barbearia`,
    variables: ['customer_name'],
  },
];
