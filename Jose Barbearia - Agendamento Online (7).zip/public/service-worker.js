// Service Worker for Jose Barbearia PWA - Enhanced with offline support
const CACHE_NAME = 'jose-barbearia-v2';
const OFFLINE_CACHE = 'jose-barbearia-offline-v1';
const PENDING_SYNC = 'pending-appointments';

// Core app shell that MUST work offline
const urlsToCache = [
  '/',
  '/index.html',
  '/manifest.json',
  'https://019bf529-b591-752d-993e-177e1485a68e.mochausercontent.com/icon-192.png',
  'https://019bf529-b591-752d-993e-177e1485a68e.mochausercontent.com/icon-512.png'
];

// Install event - cache resources
self.addEventListener('install', (event) => {
  console.log('[SW] Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Cache opened');
        return cache.addAll(urlsToCache);
      })
      .then(() => {
        console.log('[SW] Skip waiting');
        return self.skipWaiting();
      })
  );
});

// Activate event - clean up old caches and claim clients
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating...');
  event.waitUntil(
    caches.keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== CACHE_NAME && cacheName !== OFFLINE_CACHE) {
              console.log('[SW] Deleting old cache:', cacheName);
              return caches.delete(cacheName);
            }
          })
        );
      })
      .then(() => {
        console.log('[SW] Claiming clients');
        return self.clients.claim();
      })
  );
});

// Fetch event - Network first for API, Cache first for assets
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // API requests - Network first, with offline fallback
  if (url.pathname.startsWith('/api/')) {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          // Cache successful API responses for offline access
          if (response.ok && event.request.method === 'GET') {
            const responseToCache = response.clone();
            caches.open(OFFLINE_CACHE).then((cache) => {
              cache.put(event.request, responseToCache);
            });
          }
          return response;
        })
        .catch(async () => {
          // Try to get from offline cache
          const cached = await caches.match(event.request);
          if (cached) {
            console.log('[SW] Serving API from offline cache:', url.pathname);
            return cached;
          }
          
          // Special handling for appointment creation when offline
          if (event.request.method === 'POST' && url.pathname === '/api/appointments') {
            return handleOfflineAppointment(event.request);
          }
          
          throw new Error('Network error and no cache available');
        })
    );
    return;
  }
  
  // Static assets - Cache first, network fallback
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) {
          return response;
        }
        
        return fetch(event.request)
          .then((response) => {
            // Don't cache non-successful responses
            if (!response || response.status !== 200 || response.type === 'error') {
              return response;
            }
            
            // Cache the fetched resource
            const responseToCache = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, responseToCache);
            });
            
            return response;
          });
      })
  );
});

// Handle appointment creation when offline
async function handleOfflineAppointment(request) {
  const body = await request.json();
  
  // Store in IndexedDB for later sync
  const db = await openDB();
  const tx = db.transaction('pending', 'readwrite');
  const store = tx.objectStore('pending');
  
  await store.add({
    ...body,
    timestamp: Date.now(),
    synced: false
  });
  
  // Return success response
  return new Response(
    JSON.stringify({
      id: Date.now(),
      ...body,
      status: 'pending_sync',
      message: 'Agendamento salvo! Será enviado quando a internet voltar.'
    }),
    {
      status: 201,
      headers: { 'Content-Type': 'application/json' }
    }
  );
}

// IndexedDB helpers
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('jose-barbearia-offline', 1);
    
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains('pending')) {
        db.createObjectStore('pending', { keyPath: 'timestamp' });
      }
    };
  });
}

// Background sync - sync pending appointments when online
self.addEventListener('sync', (event) => {
  console.log('[SW] Background sync triggered:', event.tag);
  
  if (event.tag === 'sync-appointments') {
    event.waitUntil(syncPendingAppointments());
  }
});

async function syncPendingAppointments() {
  console.log('[SW] Syncing pending appointments...');
  
  const db = await openDB();
  const tx = db.transaction('pending', 'readonly');
  const store = tx.objectStore('pending');
  const pending = await store.getAll();
  
  console.log('[SW] Found', pending.length, 'pending appointments');
  
  for (const appointment of pending) {
    if (appointment.synced) continue;
    
    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(appointment)
      });
      
      if (response.ok) {
        // Mark as synced
        const txWrite = db.transaction('pending', 'readwrite');
        const storeWrite = txWrite.objectStore('pending');
        await storeWrite.delete(appointment.timestamp);
        
        console.log('[SW] Synced appointment:', appointment.timestamp);
        
        // Show notification
        self.registration.showNotification('Agendamento Confirmado! ✅', {
          body: `${appointment.service_name} - ${appointment.appointment_date} às ${appointment.appointment_time}`,
          icon: 'https://019bf529-b591-752d-993e-177e1485a68e.mochausercontent.com/icon-192.png',
          badge: 'https://019bf529-b591-752d-993e-177e1485a68e.mochausercontent.com/icon-192.png',
          tag: 'appointment-synced',
          requireInteraction: false
        });
      }
    } catch (error) {
      console.error('[SW] Failed to sync appointment:', error);
    }
  }
}

// Push notifications
self.addEventListener('push', (event) => {
  console.log('[SW] Push notification received');
  
  const data = event.data ? event.data.json() : {};
  
  const title = data.title || 'Jose Barbearia';
  const options = {
    body: data.body || 'Nova notificação',
    icon: 'https://019bf529-b591-752d-993e-177e1485a68e.mochausercontent.com/icon-192.png',
    badge: 'https://019bf529-b591-752d-993e-177e1485a68e.mochausercontent.com/icon-192.png',
    data: data,
    tag: data.tag || 'notification',
    requireInteraction: data.requireInteraction || false,
    actions: data.actions || []
  };
  
  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

// Notification click handler
self.addEventListener('notificationclick', (event) => {
  console.log('[SW] Notification clicked:', event.notification.tag);
  
  event.notification.close();
  
  // Open the app or focus existing window
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        // If already open, focus it
        for (const client of clientList) {
          if (client.url.includes('/') && 'focus' in client) {
            return client.focus();
          }
        }
        // Otherwise open new window
        if (clients.openWindow) {
          return clients.openWindow('/');
        }
      })
  );
});

// Message handler for communication with app
self.addEventListener('message', (event) => {
  console.log('[SW] Message received:', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'SYNC_NOW') {
    syncPendingAppointments();
  }
});
