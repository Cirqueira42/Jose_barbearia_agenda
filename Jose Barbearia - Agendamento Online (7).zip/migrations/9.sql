
CREATE TABLE blocked_times (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  block_date DATE NOT NULL,
  start_time TEXT,
  end_time TEXT,
  is_full_day BOOLEAN DEFAULT 0,
  reason TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_blocked_times_date ON blocked_times(block_date);
