
DROP INDEX idx_customers_phone;
DROP TABLE customers;
