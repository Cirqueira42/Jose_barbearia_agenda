
DROP INDEX idx_appointments_status;
DROP INDEX idx_appointments_email;
DROP INDEX idx_appointments_date;
DROP TABLE appointments;
