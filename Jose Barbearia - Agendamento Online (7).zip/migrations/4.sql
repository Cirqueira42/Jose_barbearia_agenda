
ALTER TABLE appointments ADD COLUMN service_duration INTEGER DEFAULT 30;
