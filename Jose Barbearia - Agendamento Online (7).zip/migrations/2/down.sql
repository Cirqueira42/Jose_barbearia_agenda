
DROP INDEX idx_pomade_sales_date;
DROP TABLE pomade_sales;
