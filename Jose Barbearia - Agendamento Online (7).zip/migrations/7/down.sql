
ALTER TABLE pomade_types DROP COLUMN image;
