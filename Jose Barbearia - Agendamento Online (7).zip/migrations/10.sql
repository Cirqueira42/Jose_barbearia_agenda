
ALTER TABLE appointments ADD COLUMN payment_method TEXT;
ALTER TABLE appointments ADD COLUMN payment_status TEXT DEFAULT 'pending';
