
DROP INDEX idx_blocked_times_date;
DROP TABLE blocked_times;
