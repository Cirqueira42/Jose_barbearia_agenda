
DROP INDEX idx_quick_action_tokens_appointment;
DROP INDEX idx_quick_action_tokens_token;
DROP TABLE quick_action_tokens;
