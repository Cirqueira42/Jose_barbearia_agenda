import { Resend } from 'resend';

export async function sendConfirmationEmail(
  apiKey: string,
  appointment: {
    id?: number;
    customer_name: string;
    customer_email: string;
    customer_phone?: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  },
  barberEmail?: string
) {
  if (!apiKey) {
    console.warn('RESEND_API_KEY not configured, skipping email');
    return;
  }

  const resend = new Resend(apiKey);

  console.log('📤 INÍCIO: sendConfirmationEmail chamada');
  console.log('📧 Email do cliente:', appointment.customer_email);
  console.log('🔑 API Key está definida:', !!apiKey);

  try {
    const formattedDate = new Date(appointment.appointment_date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    // Email for customer - with WhatsApp share button
    const whatsappShareText = encodeURIComponent(`✅ *AGENDAMENTO CONFIRMADO*\n\n✂️ *Serviço:* ${appointment.service_name}\n📅 *Data:* ${formattedDate}\n🕐 *Horário:* ${appointment.appointment_time}\n\n📍 *Local:*\nJose Barbearia\nAv. Otávio Rangel, 477 - Vila Cecap\nGuariba - SP, 14845-106\n\n📞 WhatsApp: (16) 99736-9740\n📱 Instagram: @josebarbeariaa\n\n🗺️ Ver no mapa:\nhttps://maps.google.com/?q=Av.+Otávio+Rangel,+477+-+Vila+Cecap,+Guariba+-+SP`);
    
    const customerEmailHTML = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #f59e0b;">Jose Barbearia</h2>
        
        <h3>Olá, ${appointment.customer_name}!</h3>
        
        <p>Seu agendamento foi confirmado com sucesso.</p>
        
        <div style="background-color: #1e293b; color: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Serviço:</strong> ${appointment.service_name}</p>
          <p style="margin: 5px 0;"><strong>Data:</strong> ${formattedDate}</p>
          <p style="margin: 5px 0;"><strong>Horário:</strong> ${appointment.appointment_time}</p>
        </div>
        
        <p><strong>Endereço:</strong><br>
        Av. Otávio Rangel, 477 - Vila Cecap<br>
        Guariba - SP, 14845-106</p>
        
        <div style="text-align: center; margin: 20px 0;">
          <a href="https://www.google.com/maps/search/?api=1&query=Av.+Ot%C3%A1vio+Rangel%2C+477+-+Vila+Cecap%2C+Guariba+-+SP%2C+14845-106" 
             target="_blank"
             style="display: inline-block; background-color: #3b82f6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold;">
            📍 Ver Localização no Mapa
          </a>
        </div>
        
        <div style="background-color: #dcfce7; border: 2px solid #22c55e; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
          <p style="margin: 0 0 15px 0; color: #166534; font-weight: bold;">
            📱 COMPARTILHAR CONFIRMAÇÃO NO WHATSAPP
          </p>
          <a href="https://wa.me/?text=${whatsappShareText}" 
             target="_blank"
             style="display: inline-block; background-color: #25d366; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold;">
            💬 Compartilhar via WhatsApp
          </a>
          <p style="margin: 15px 0 0 0; color: #166534; font-size: 12px;">
            Clique para compartilhar os detalhes do seu agendamento
          </p>
        </div>
        
        <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 10px 0; color: #334155;">
            <strong>📞 WhatsApp:</strong> (16) 99736-9740
          </p>
          <p style="margin: 10px 0; color: #334155;">
            <strong>📱 Instagram:</strong> @josebarbeariaa
          </p>
        </div>
        
        <div style="text-align: center; margin: 30px 0;">
          <a href="https://e4id45fo46lti.mocha.app/api/appointments/${appointment.id || ''}/cancel" 
             style="display: inline-block; background-color: #dc2626; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold;">
            Cancelar Agendamento
          </a>
        </div>
        
        <div style="background-color: #fef3c7; border: 2px solid #fbbf24; padding: 15px; border-radius: 8px; margin: 20px 0; text-align: center;">
          <p style="margin: 0; color: #92400e; font-weight: bold;">
            ⚠️ NÃO RECEBEU ESTE EMAIL?
          </p>
          <p style="margin: 5px 0 0 0; color: #92400e; font-size: 14px;">
            Verifique sua pasta de <strong>SPAM/LIXO ELETRÔNICO</strong>
          </p>
        </div>
        
        <p style="color: #64748b; font-size: 12px; text-align: center;">
          Caso precise reagendar, entre em contato pelo WhatsApp ou Instagram
        </p>
        
        <p style="margin-top: 30px;">Até breve!</p>
      </div>
    `;

    // Email for barber - with WhatsApp button
    const barberEmailHTML = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #f59e0b;">Jose Barbearia</h2>
        
        <h3>Novo Agendamento</h3>
        
        <p><strong>Cliente:</strong> ${appointment.customer_name}</p>
        
        <div style="background-color: #1e293b; color: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Serviço:</strong> ${appointment.service_name}</p>
          <p style="margin: 5px 0;"><strong>Data:</strong> ${formattedDate}</p>
          <p style="margin: 5px 0;"><strong>Horário:</strong> ${appointment.appointment_time}</p>
        </div>
        
        <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0; color: #334155;"><strong>Email:</strong> ${appointment.customer_email}</p>
          <p style="margin: 5px 0; color: #334155;"><strong>Telefone:</strong> ${appointment.customer_phone || 'Não informado'}</p>
        </div>
        
        ${appointment.customer_phone ? `
        <div style="background-color: #dcfce7; border: 2px solid #22c55e; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
          <p style="margin: 0 0 15px 0; color: #166534; font-weight: bold;">
            📱 NOTIFICAR CLIENTE PELO WHATSAPP
          </p>
          <a href="https://wa.me/55${appointment.customer_phone.replace(/\D/g, '')}?text=${encodeURIComponent(`Olá ${appointment.customer_name}! 👋\n\nSeu agendamento foi *CONFIRMADO* com sucesso! ✅\n\n📅 *Data:* ${new Date(appointment.appointment_date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}*\n🕐 *Horário:* ${appointment.appointment_time}*\n✂️ *Serviço:* ${appointment.service_name}*\n\n📍 *Local:*\nAv. Otávio Rangel, 477 - Vila Cecap\nGuariba - SP, 14845-106\n\n🗺️ Ver no mapa:\nhttps://maps.google.com/?q=Av.+Otávio+Rangel,+477+-+Vila+Cecap,+Guariba+-+SP\n\n_Se precisar cancelar, clique aqui:_\nhttps://e4id45fo46lti.mocha.app/api/appointments/${appointment.id || ''}/cancel\n\nNos vemos em breve! 💈\n\n_José Barbearia_`)}" 
             target="_blank"
             style="display: inline-block; background-color: #25d366; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold;">
            🚀 Enviar Lembrete via WhatsApp
          </a>
          <p style="margin: 15px 0 0 0; color: #166534; font-size: 12px;">
            Clique para enviar um lembrete rápido ao cliente
          </p>
        </div>
        ` : ''}
        
        <p style="margin-top: 30px;">Sistema de Agendamentos - Jose Barbearia</p>
      </div>
    `;

    // Send email to customer ONLY if they provided an email
    if (appointment.customer_email && appointment.customer_email.trim() !== '') {
      const customerResult = await resend.emails.send({
        from: 'Jose Barbearia <onboarding@resend.dev>',
        to: appointment.customer_email,
        subject: `Confirmação de Agendamento - Jose Barbearia`,
        html: customerEmailHTML
      });

      console.log('✅ Email enviado ao cliente:', appointment.customer_email);
      console.log('📨 ID do email do cliente:', customerResult.data?.id || 'N/A');
    } else {
      console.log('ℹ️ Cliente não forneceu email - pulando email ao cliente');
    }

    // ALWAYS send email to barber if configured (even if customer has no email)
    if (barberEmail) {
      // Only skip if barber email is the same as customer email
      if (appointment.customer_email && barberEmail.toLowerCase() === appointment.customer_email.toLowerCase()) {
        console.log('ℹ️ Email do barbeiro é o mesmo do cliente - pulando email duplicado ao barbeiro');
      } else {
        const barberResult = await resend.emails.send({
          from: 'Jose Barbearia <onboarding@resend.dev>',
          to: barberEmail,
          subject: `Novo Agendamento - ${appointment.customer_name}`,
          html: barberEmailHTML
        });

        console.log('✅ Email enviado ao barbeiro:', barberEmail);
        console.log('📨 ID do email do barbeiro:', barberResult.data?.id || 'N/A');
      }
    } else {
      console.warn('⚠️ Email do barbeiro não configurado - não foi possível notificar');
    }

  } catch (error) {
    console.error('❌ ERRO ao enviar email:', error);
    if (error instanceof Error) {
      console.error('📝 Mensagem do erro:', error.message);
      console.error('🔧 Stack trace:', error.stack);
    }
  }
}

export async function sendReminderEmail(
  apiKey: string,
  appointment: {
    customer_name: string;
    customer_email: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  },
  barberEmail?: string
) {
  if (!apiKey) {
    console.warn('RESEND_API_KEY not configured, skipping email');
    return;
  }

  const resend = new Resend(apiKey);

  try {
    const formattedDate = new Date(appointment.appointment_date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    // Build recipient list - only include customer if they have email
    const recipients: string[] = [];
    if (appointment.customer_email && appointment.customer_email.trim() !== '') {
      recipients.push(appointment.customer_email);
    }
    if (barberEmail) {
      recipients.push(barberEmail);
    }

    // Skip if no recipients
    if (recipients.length === 0) {
      console.log('⚠️ No recipients for reminder email');
      return;
    }

    await resend.emails.send({
      from: 'Jose Barbearia <onboarding@resend.dev>', // Update this with your verified domain
      to: recipients,
      subject: `Lembrete: Seu agendamento é amanhã - Jose Barbearia`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #f59e0b;">Jose Barbearia</h2>
          
          <h3>Olá, ${appointment.customer_name}!</h3>
          
          <p>Este é um lembrete sobre seu agendamento <strong>amanhã</strong>.</p>
          
          <div style="background-color: #1e293b; color: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 5px 0;"><strong>Serviço:</strong> ${appointment.service_name}</p>
            <p style="margin: 5px 0;"><strong>Data:</strong> ${formattedDate}</p>
            <p style="margin: 5px 0;"><strong>Horário:</strong> ${appointment.appointment_time}</p>
          </div>
          
          <p><strong>Endereço:</strong><br>
          Av. Otávio Rangel, 477 - Vila Cecap<br>
          Guariba - SP, 14845-106</p>
          
          <p style="background-color: #fef3c7; padding: 15px; border-left: 4px solid #f59e0b; margin: 20px 0;">
            ⏰ Não se esqueça! Estamos te esperando.
          </p>
          
          <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 10px 0; color: #334155;">
              <strong>📞 WhatsApp:</strong> (16) 99736-9740
            </p>
            <p style="margin: 10px 0; color: #334155;">
              <strong>📱 Instagram:</strong> @josebarbeariaa
            </p>
          </div>
          
          <div style="background-color: #fef3c7; border: 2px solid #fbbf24; padding: 15px; border-radius: 8px; margin: 20px 0; text-align: center;">
            <p style="margin: 0; color: #92400e; font-weight: bold;">
              ⚠️ NÃO RECEBEU ESTE EMAIL?
            </p>
            <p style="margin: 5px 0 0 0; color: #92400e; font-size: 14px;">
              Verifique sua pasta de <strong>SPAM/LIXO ELETRÔNICO</strong>
            </p>
          </div>
          
          <p style="color: #64748b; font-size: 12px; text-align: center;">
            Entre em contato pelo WhatsApp ou Instagram caso precise de alguma alteração
          </p>
          
          <p style="margin-top: 30px;">Até logo!</p>
        </div>
      `
    });

    console.log('Reminder email sent to:', recipients.join(', '));
  } catch (error) {
    console.error('Error sending reminder email:', error);
  }
}

export async function send45MinuteReminderEmail(
  apiKey: string,
  appointment: {
    customer_name: string;
    customer_email: string;
    customer_phone?: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  },
  barberEmail?: string
) {
  if (!apiKey) {
    console.warn('RESEND_API_KEY not configured, skipping email');
    return;
  }

  const resend = new Resend(apiKey);

  try {
    const formattedDate = new Date(appointment.appointment_date + 'T00:00:00').toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    // ALWAYS send to customer if they have email
    if (appointment.customer_email && appointment.customer_email.trim() !== '') {
      try {
        await resend.emails.send({
          from: 'Jose Barbearia <onboarding@resend.dev>',
          to: appointment.customer_email,
          subject: `⏰ Seu horário é em 45 minutos! - Jose Barbearia`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #f59e0b;">Jose Barbearia</h2>
              
              <h3>Olá, ${appointment.customer_name}!</h3>
              
              <p style="font-size: 18px; font-weight: bold; color: #f59e0b;">
                🔔 Seu horário é em 45 minutos!
              </p>
              
              <div style="background-color: #1e293b; color: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 5px 0;"><strong>Serviço:</strong> ${appointment.service_name}</p>
                <p style="margin: 5px 0;"><strong>Data:</strong> ${formattedDate}</p>
                <p style="margin: 5px 0;"><strong>Horário:</strong> ${appointment.appointment_time}</p>
              </div>
              
              <p><strong>Endereço:</strong><br>
              Av. Otávio Rangel, 477 - Vila Cecap<br>
              Guariba - SP, 14845-106</p>
              
              <div style="background-color: #fef3c7; padding: 15px; border-left: 4px solid #f59e0b; margin: 20px 0; border-radius: 4px;">
                <p style="margin: 0; color: #92400e;">
                  ⏰ <strong>Não se atrase!</strong> Por favor, chegue com 10 minutos de antecedência.
                </p>
              </div>
              
              <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 10px 0; color: #334155;">
                  <strong>📞 WhatsApp:</strong> (16) 99736-9740
                </p>
                <p style="margin: 10px 0; color: #334155;">
                  <strong>📱 Instagram:</strong> @josebarbeariaa
                </p>
              </div>
              
              <p style="margin-top: 30px;">Até já! 😊</p>
            </div>
          `
        });
        console.log('✅ 45-min reminder sent to customer:', appointment.customer_email);
      } catch (error) {
        console.error('❌ Failed to send 45-min reminder to customer:', error);
      }
    }

    // ALWAYS send to barber (with customer info for sharing)
    if (!barberEmail) {
      console.log('⚠️ No barber email configured for 45-min reminder');
      return;
    }

    // Send to barber with option to share
    const whatsappShareText = encodeURIComponent(`Olá ${appointment.customer_name}! 👋\n\nSeu horário é daqui a 45 minutos! ⏰\n\n🕐 *${appointment.appointment_time}*\n✂️ *${appointment.service_name}*\n\nNos vemos em breve na Jose Barbearia!\n\n📍 *Localização:*\nAv. Otávio Rangel, 477 - Vila Cecap\nGuariba - SP\n\n🗺️ Ver no mapa:\nhttps://maps.google.com/?q=Av.+Otávio+Rangel,+477+-+Vila+Cecap,+Guariba+-+SP`);

    await resend.emails.send({
      from: 'Jose Barbearia <onboarding@resend.dev>',
      to: barberEmail,
      subject: `⏰ Agendamento em 45 min - ${appointment.customer_name}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #f59e0b;">Jose Barbearia</h2>
          
          <h3>⏰ Agendamento em 45 minutos!</h3>
          
          <div style="background-color: #fef3c7; border: 2px solid #f59e0b; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
            <p style="margin: 0; color: #92400e; font-weight: bold; font-size: 18px;">
              🔔 Próximo cliente chegando em breve!
            </p>
          </div>
          
          <p><strong>Cliente:</strong> ${appointment.customer_name}</p>
          
          <div style="background-color: #1e293b; color: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 5px 0;"><strong>Serviço:</strong> ${appointment.service_name}</p>
            <p style="margin: 5px 0;"><strong>Data:</strong> ${formattedDate}</p>
            <p style="margin: 5px 0;"><strong>Horário:</strong> ${appointment.appointment_time}</p>
          </div>
          
          <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 5px 0; color: #334155;"><strong>Telefone:</strong> ${appointment.customer_phone || 'Não informado'}</p>
            <p style="margin: 5px 0; color: #334155;"><strong>Email:</strong> ${appointment.customer_email || 'Não informado'}</p>
          </div>
          
          ${appointment.customer_phone ? `
          <div style="background-color: #dcfce7; border: 2px solid #22c55e; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
            <p style="margin: 0 0 15px 0; color: #166534; font-weight: bold;">
              📱 ENVIAR LEMBRETE PARA O CLIENTE
            </p>
            <a href="https://wa.me/55${appointment.customer_phone.replace(/\D/g, '')}?text=${whatsappShareText}" 
               target="_blank"
               style="display: inline-block; background-color: #25d366; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold;">
              🚀 Enviar Lembrete via WhatsApp
            </a>
            <p style="margin: 15px 0 0 0; color: #166534; font-size: 12px;">
              ${appointment.customer_email ? 'O cliente já recebeu email, mas você pode enviar WhatsApp também' : 'Cliente não tem email - compartilhe via WhatsApp'}
            </p>
          </div>
          ` : `
          <div style="background-color: #fee2e2; border: 2px solid #ef4444; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0; color: #991b1b; font-size: 14px;">
              ⚠️ Cliente não forneceu telefone para contato
            </p>
          </div>
          `}
          
          <div style="background-color: #dbeafe; border-left: 4px solid #3b82f6; padding: 15px; margin: 20px 0; border-radius: 4px;">
            <p style="margin: 0; color: #1e3a8a;">
              💡 <strong>Dica:</strong> ${appointment.customer_email ? 'Cliente já foi notificado por email' : 'Cliente não tem email - use WhatsApp para avisar'}
            </p>
          </div>
          
          <p style="margin-top: 30px;">Sistema de Agendamentos - Jose Barbearia</p>
        </div>
      `
    });

    console.log('✅ 45-minute reminder email sent to barber:', barberEmail);
  } catch (error) {
    console.error('Error sending 45-minute reminder email:', error);
  }
}

export async function sendBarberReminderEmail(
  apiKey: string,
  appointment: {
    id?: number;
    customer_name: string;
    customer_phone: string;
    customer_email?: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  },
  barberEmail: string
) {
  if (!apiKey) {
    console.warn('RESEND_API_KEY not configured, skipping email');
    return;
  }

  const resend = new Resend(apiKey);

  try {
    const formattedDate = new Date(appointment.appointment_date + 'T00:00:00').toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    const emailHTML = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #f59e0b;">Jose Barbearia</h2>
        
        <h3>⏰ Agendamento em 45 minutos!</h3>
        
        <div style="background-color: #fef3c7; border: 2px solid #f59e0b; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
          <p style="margin: 0; color: #92400e; font-weight: bold; font-size: 18px;">
            🔔 Próximo cliente chegando em breve!
          </p>
        </div>
        
        <p><strong>Cliente:</strong> ${appointment.customer_name}</p>
        
        <div style="background-color: #1e293b; color: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Serviço:</strong> ${appointment.service_name}</p>
          <p style="margin: 5px 0;"><strong>Data:</strong> ${formattedDate}</p>
          <p style="margin: 5px 0;"><strong>Horário:</strong> ${appointment.appointment_time}</p>
        </div>
        
        <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0; color: #334155;"><strong>Telefone:</strong> ${appointment.customer_phone || 'Não informado'}</p>
          <p style="margin: 5px 0; color: #334155;"><strong>Email:</strong> ${appointment.customer_email || 'Não informado'}</p>
        </div>
        
        ${appointment.customer_phone ? `
        <div style="background-color: #dcfce7; border: 2px solid #22c55e; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
          <p style="margin: 0 0 15px 0; color: #166534; font-weight: bold;">
            📱 ENVIAR LEMBRETE PARA O CLIENTE
          </p>
          <a href="https://wa.me/55${appointment.customer_phone.replace(/\D/g, '')}?text=${encodeURIComponent(`Olá ${appointment.customer_name}! 👋\n\nSeu horário é daqui a 45 minutos! ⏰\n\n🕐 *${appointment.appointment_time}*\n✂️ *${appointment.service_name}*\n\nNos vemos em breve na Jose Barbearia!\n\n📍 *Localização:*\nAv. Otávio Rangel, 477 - Vila Cecap\nGuariba - SP\n\n🗺️ Ver no mapa:\nhttps://maps.google.com/?q=Av.+Otávio+Rangel,+477+-+Vila+Cecap,+Guariba+-+SP`)}" 
             target="_blank"
             style="display: inline-block; background-color: #25d366; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold;">
            🚀 Enviar Lembrete via WhatsApp
          </a>
          <p style="margin: 15px 0 0 0; color: #166534; font-size: 12px;">
            Clique para lembrar o cliente que o horário está chegando
          </p>
        </div>
        ` : ''}
        
        <div style="background-color: #dbeafe; border-left: 4px solid #3b82f6; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0; color: #1e3a8a;">
            💡 <strong>Dica:</strong> Use o botão acima para enviar um lembrete rápido ao cliente pelo WhatsApp
          </p>
        </div>
        
        <p style="margin-top: 30px;">Sistema de Agendamentos - Jose Barbearia</p>
      </div>
    `;

    await resend.emails.send({
      from: 'Jose Barbearia <onboarding@resend.dev>',
      to: barberEmail,
      subject: `⏰ Agendamento em 45 min - ${appointment.customer_name}`,
      html: emailHTML
    });

    console.log('✅ Barber reminder email sent to:', barberEmail);
  } catch (error) {
    console.error('❌ Error sending barber reminder email:', error);
    if (error instanceof Error) {
      console.error('Error message:', error.message);
    }
  }
}

export async function sendCompletionEmailToBarber(
  apiKey: string,
  appointment: {
    id?: number;
    customer_name: string;
    customer_phone: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  },
  barberEmail: string
) {
  if (!apiKey) {
    console.warn('RESEND_API_KEY not configured, skipping email');
    return;
  }

  const resend = new Resend(apiKey);

  try {
    const formattedDate = new Date(appointment.appointment_date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    // WhatsApp thank you message for customer
    const whatsappThankYouText = encodeURIComponent(`Olá ${appointment.customer_name}!

Muito obrigado por escolher a Jose Barbearia! 🙏

Esperamos que tenha gostado do nosso atendimento e do resultado final. Sua satisfação é nossa maior recompensa!

📸 Que tal compartilhar uma foto do resultado nas redes sociais? Não esqueça de nos marcar @josebarbeariaa

⭐ Sua opinião é muito importante! Deixe seu feedback e ajude outros clientes a conhecerem nosso trabalho.

🔄 Agende seu próximo horário para manter o visual sempre em dia!

Até a próxima!
Jose Barbearia`);

    const emailHTML = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #f59e0b;">Jose Barbearia</h2>
        
        <h3>✅ Atendimento Concluído</h3>
        
        <div style="background-color: #dcfce7; border: 2px solid #22c55e; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
          <p style="margin: 0; color: #166534; font-weight: bold; font-size: 18px;">
            🎉 Serviço finalizado com sucesso!
          </p>
        </div>
        
        <p><strong>Cliente:</strong> ${appointment.customer_name}</p>
        
        <div style="background-color: #1e293b; color: white; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0;"><strong>Serviço:</strong> ${appointment.service_name}</p>
          <p style="margin: 5px 0;"><strong>Data:</strong> ${formattedDate}</p>
          <p style="margin: 5px 0;"><strong>Horário:</strong> ${appointment.appointment_time}</p>
        </div>
        
        <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p style="margin: 5px 0; color: #334155;"><strong>Telefone:</strong> ${appointment.customer_phone}</p>
        </div>
        
        ${appointment.customer_phone ? `
        <div style="background-color: #dcfce7; border: 2px solid #22c55e; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
          <p style="margin: 0 0 15px 0; color: #166534; font-weight: bold; font-size: 16px;">
            🙏 ENVIAR AGRADECIMENTO AO CLIENTE
          </p>
          <p style="margin: 0 0 15px 0; color: #166534; font-size: 14px;">
            Clique no botão abaixo para enviar uma mensagem de agradecimento via WhatsApp
          </p>
          <a href="https://wa.me/55${appointment.customer_phone.replace(/\D/g, '')}?text=${whatsappThankYouText}" 
             target="_blank"
             style="display: inline-block; background-color: #25d366; color: white; padding: 14px 35px; text-decoration: none; border-radius: 8px; font-weight: bold; font-size: 16px;">
            🙏 Enviar Agradecimento
          </a>
          <p style="margin: 15px 0 0 0; color: #166534; font-size: 12px;">
            A mensagem será pré-preenchida e pronta para enviar
          </p>
        </div>
        ` : ''}
        
        <div style="background-color: #dbeafe; border-left: 4px solid #3b82f6; padding: 15px; margin: 20px 0; border-radius: 4px;">
          <p style="margin: 0; color: #1e3a8a;">
            💡 <strong>Dica:</strong> Agradecer os clientes aumenta a fidelização e melhora sua reputação!
          </p>
        </div>
        
        <p style="margin-top: 30px;">Sistema de Agendamentos - Jose Barbearia</p>
      </div>
    `;

    await resend.emails.send({
      from: 'Jose Barbearia <onboarding@resend.dev>',
      to: barberEmail,
      subject: `✅ Atendimento Concluído - ${appointment.customer_name}`,
      html: emailHTML
    });

    console.log('✅ Completion email sent to barber:', barberEmail);
  } catch (error) {
    console.error('❌ Error sending completion email to barber:', error);
    if (error instanceof Error) {
      console.error('Error message:', error.message);
    }
  }
}

export async function sendCancellationEmail(
  apiKey: string,
  appointment: {
    customer_name: string;
    customer_email: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  },
  barberEmail?: string
) {
  if (!apiKey) {
    console.warn('RESEND_API_KEY not configured, skipping email');
    return;
  }

  const resend = new Resend(apiKey);

  try {
    const formattedDate = new Date(appointment.appointment_date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    const whatsappCancelText = encodeURIComponent(`❌ *AGENDAMENTO CANCELADO*\n\n✂️ *Serviço:* ${appointment.service_name}\n📅 *Data:* ${formattedDate}\n🕐 *Horário:* ${appointment.appointment_time}\n\n📍 *Local:*\nJose Barbearia\nAv. Otávio Rangel, 477 - Vila Cecap\nGuariba - SP, 14845-106\n\n💡 Para reagendar:\n📞 WhatsApp: (16) 99736-9740\n📱 Instagram: @josebarbeariaa\n🌐 Site: https://josebarbearia.app.br/agendar`);

    // Build recipient list - only include customer if they have email
    const recipients: string[] = [];
    if (appointment.customer_email && appointment.customer_email.trim() !== '') {
      recipients.push(appointment.customer_email);
    }
    if (barberEmail) {
      recipients.push(barberEmail);
    }

    // Skip if no recipients
    if (recipients.length === 0) {
      console.log('⚠️ No recipients for cancellation email');
      return;
    }

    await resend.emails.send({
      from: 'Jose Barbearia <onboarding@resend.dev>',
      to: recipients,
      subject: `Agendamento Cancelado - Jose Barbearia`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #f59e0b;">Jose Barbearia</h2>
          
          <h3>Olá, ${appointment.customer_name}!</h3>
          
          <div style="background-color: #fee2e2; border: 2px solid #ef4444; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
            <p style="margin: 0; color: #991b1b; font-weight: bold; font-size: 18px;">
              ❌ Agendamento Cancelado
            </p>
          </div>
          
          <p>Seu agendamento foi cancelado com sucesso.</p>
          
          <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 5px 0; color: #334155;"><strong>Serviço:</strong> ${appointment.service_name}</p>
            <p style="margin: 5px 0; color: #334155;"><strong>Data:</strong> ${formattedDate}</p>
            <p style="margin: 5px 0; color: #334155;"><strong>Horário:</strong> ${appointment.appointment_time}</p>
          </div>
          
          <div style="background-color: #fff3cd; border: 2px solid #ffc107; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center;">
            <p style="margin: 0 0 15px 0; color: #856404; font-weight: bold;">
              📱 COMPARTILHAR CANCELAMENTO NO WHATSAPP
            </p>
            <a href="https://wa.me/?text=${whatsappCancelText}" 
               target="_blank"
               style="display: inline-block; background-color: #25d366; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold;">
              💬 Compartilhar via WhatsApp
            </a>
            <p style="margin: 15px 0 0 0; color: #856404; font-size: 12px;">
              Clique para avisar alguém sobre o cancelamento
            </p>
          </div>
          
          <div style="background-color: #dbeafe; border-left: 4px solid #3b82f6; padding: 15px; margin: 20px 0; border-radius: 4px;">
            <p style="margin: 0; color: #1e3a8a;">
              <strong>Deseja reagendar?</strong><br>
              Entre em contato conosco ou faça um novo agendamento através do nosso site.
            </p>
          </div>
          
          <p><strong>Endereço:</strong><br>
          Av. Otávio Rangel, 477 - Vila Cecap<br>
          Guariba - SP, 14845-106</p>
          
          <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 10px 0; color: #334155;">
              <strong>📞 WhatsApp:</strong> (16) 99736-9740
            </p>
            <p style="margin: 10px 0; color: #334155;">
              <strong>📱 Instagram:</strong> @josebarbeariaa
            </p>
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="https://josebarbearia.app.br/agendar" 
               style="display: inline-block; background-color: #f59e0b; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold;">
              Agendar Novo Horário
            </a>
          </div>
          
          <div style="background-color: #fef3c7; border: 2px solid #fbbf24; padding: 15px; border-radius: 8px; margin: 20px 0; text-align: center;">
            <p style="margin: 0; color: #92400e; font-weight: bold;">
              ⚠️ NÃO RECEBEU ESTE EMAIL?
            </p>
            <p style="margin: 5px 0 0 0; color: #92400e; font-size: 14px;">
              Verifique sua pasta de <strong>SPAM/LIXO ELETRÔNICO</strong>
            </p>
          </div>
          
          <p style="color: #64748b; font-size: 12px; text-align: center;">
            Esperamos vê-lo em breve na Jose Barbearia!
          </p>
          
          <p style="margin-top: 30px;">Até logo! 👋</p>
        </div>
      `
    });

    console.log('Cancellation email sent to:', recipients.join(', '));
  } catch (error) {
    console.error('Error sending cancellation email:', error);
  }
}
