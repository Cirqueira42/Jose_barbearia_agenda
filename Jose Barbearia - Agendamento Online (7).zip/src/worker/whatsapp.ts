export async function sendWhatsAppNotificationToBarber(
  accountSid: string,
  authToken: string,
  fromNumber: string,
  barberPhone: string,
  appointment: {
    id: number;
    customer_name: string;
    customer_phone: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  }
) {
  console.log('🔔 sendWhatsAppNotificationToBarber called');
  console.log('📞 Barber phone:', barberPhone);

  if (!accountSid || !authToken || !fromNumber || !barberPhone) {
    console.warn('❌ Missing credentials or barber phone, skipping notification');
    return;
  }

  try {
    // Format the date in Portuguese - fix timezone issue
    const formattedDate = new Date(appointment.appointment_date + 'T00:00:00').toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    // Ensure phone number is in E.164 format
    let toNumber = barberPhone.replace(/\D/g, '');
    if (!toNumber.startsWith('55')) {
      toNumber = '55' + toNumber;
    }
    toNumber = '+' + toNumber;

    // Format phone for WhatsApp link (ensure it has country code)
    let phoneForLink = appointment.customer_phone.replace(/\D/g, '');
    if (!phoneForLink.startsWith('55')) {
      phoneForLink = '55' + phoneForLink;
    }

    // Create WhatsApp links that open chat with pre-filled confirmation messages
    const confirmMessage = `Olá ${appointment.customer_name}! 👋

Seu agendamento foi *CONFIRMADO* com sucesso! ✅

📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}
✂️ *Serviço:* ${appointment.service_name}

📍 *Local:*
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

🗺️ Ver no mapa: https://maps.google.com/?q=Av.+Otávio+Rangel,+477+-+Vila+Cecap,+Guariba+-+SP

_Se precisar cancelar, clique aqui:_
https://e4id45fo46lti.mocha.app/api/appointments/${appointment.id}/cancel

Nos vemos em breve! 💈

_José Barbearia_`;

    const cancelMessage = `Olá ${appointment.customer_name},

Infelizmente precisei cancelar seu agendamento:

📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}
✂️ *Serviço:* ${appointment.service_name}

Se quiser remarcar, é só me avisar! 😊

_José Barbearia_`;

    const confirmWhatsAppLink = `https://wa.me/${phoneForLink}?text=${encodeURIComponent(confirmMessage)}`;
    const cancelWhatsAppLink = `https://wa.me/${phoneForLink}?text=${encodeURIComponent(cancelMessage)}`;

    const message = `🔔 *NOVO AGENDAMENTO!*

👤 *Cliente:* ${appointment.customer_name}
📱 *Telefone:* ${appointment.customer_phone}
✂️ *Serviço:* ${appointment.service_name}
📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}

*Clique para enviar confirmação ou cancelamento:*

✅ Confirmar: ${confirmWhatsAppLink}

❌ Cancelar: ${cancelWhatsAppLink}

_José Barbearia - Sistema de Agendamentos_`;

    const auth = btoa(`${accountSid}:${authToken}`);
    
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: `whatsapp:${fromNumber}`,
          To: `whatsapp:${toNumber}`,
          Body: message,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('Twilio API error:', error);
      throw new Error(`Twilio API error: ${response.status}`);
    }

    const result = await response.json() as { sid: string };
    console.log('✅ WhatsApp notification sent to barber:', toNumber, 'SID:', result.sid);
  } catch (error) {
    console.error('Error sending WhatsApp notification to barber:', error);
  }
}

export async function sendWhatsAppConfirmation(
  accountSid: string,
  authToken: string,
  fromNumber: string,
  appointment: {
    id?: number;
    customer_name: string;
    customer_phone: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  },
  baseUrl?: string
) {
  console.log('🎯 sendWhatsAppConfirmation called for:', appointment.customer_name);
  console.log('📞 Phone:', appointment.customer_phone);
  console.log('🔑 Credentials check:', {
    hasSid: !!accountSid,
    hasToken: !!authToken,
    hasFromNumber: !!fromNumber,
    fromNumber: fromNumber,
    sidLength: accountSid?.length || 0,
    tokenLength: authToken?.length || 0
  });

  if (!accountSid || !authToken || !fromNumber) {
    console.warn('❌ Twilio WhatsApp credentials not configured, skipping WhatsApp');
    console.warn('Missing:', {
      accountSid: !accountSid,
      authToken: !authToken,
      fromNumber: !fromNumber
    });
    return;
  }

  try {
    // Format the date in Portuguese - fix timezone issue
    const formattedDate = new Date(appointment.appointment_date + 'T00:00:00').toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    // Ensure phone number is in E.164 format (starts with +)
    let toNumber = appointment.customer_phone.replace(/\D/g, '');
    if (!toNumber.startsWith('55')) {
      toNumber = '55' + toNumber; // Add Brazil country code
    }
    toNumber = '+' + toNumber;

    // Prepare the message with optional cancel link
    let message = `✅ *Agendamento Confirmado - José Barbearia*

Olá, *${appointment.customer_name}*!

Seu agendamento foi confirmado com sucesso:

📌 *Serviço:* ${appointment.service_name}
📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}

📍 *Local:*
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

Nos vemos em breve! 💈`;

    // Add cancel link if available
    if (baseUrl && appointment.id) {
      const cancelLink = `${baseUrl}/api/appointments/${appointment.id}/cancel`;
      message += `\n\n_Se precisar cancelar, clique aqui:_\n${cancelLink}`;
    } else {
      message += `\n\n_Caso precise cancelar ou reagendar, responda esta mensagem._`;
    }

    // Send via Twilio WhatsApp API
    const auth = btoa(`${accountSid}:${authToken}`);
    
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: `whatsapp:${fromNumber}`,
          To: `whatsapp:${toNumber}`,
          Body: message,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('Twilio API error:', error);
      throw new Error(`Twilio API error: ${response.status}`);
    }

    const result = await response.json() as { sid: string };
    console.log('WhatsApp confirmation sent to:', toNumber, 'SID:', result.sid);
  } catch (error) {
    console.error('Error sending WhatsApp confirmation:', error);
  }
}

export async function sendWhatsAppReminder(
  accountSid: string,
  authToken: string,
  fromNumber: string,
  appointment: {
    customer_name: string;
    customer_phone: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  }
) {
  if (!accountSid || !authToken || !fromNumber) {
    console.warn('Twilio WhatsApp credentials not configured, skipping WhatsApp');
    return;
  }

  try {
    // Fix timezone issue
    const formattedDate = new Date(appointment.appointment_date + 'T00:00:00').toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    let toNumber = appointment.customer_phone.replace(/\D/g, '');
    if (!toNumber.startsWith('55')) {
      toNumber = '55' + toNumber;
    }
    toNumber = '+' + toNumber;

    const message = `⏰ *Lembrete - José Barbearia*

Olá, *${appointment.customer_name}*!

Seu horário é *AMANHÃ*:

📌 *Serviço:* ${appointment.service_name}
📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}

📍 *Local:*
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

Te esperamos! 💈`;

    const auth = btoa(`${accountSid}:${authToken}`);
    
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: `whatsapp:${fromNumber}`,
          To: `whatsapp:${toNumber}`,
          Body: message,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('Twilio API error:', error);
      throw new Error(`Twilio API error: ${response.status}`);
    }

    const result = await response.json() as { sid: string };
    console.log('WhatsApp reminder sent to:', toNumber, 'SID:', result.sid);
  } catch (error) {
    console.error('Error sending WhatsApp reminder:', error);
  }
}

export async function sendWhatsAppThankYou(
  accountSid: string,
  authToken: string,
  fromNumber: string,
  appointment: {
    customer_name: string;
    customer_phone: string;
    service_name: string;
  }
) {
  console.log('🎯 sendWhatsAppThankYou called for:', appointment.customer_name);
  console.log('📞 Phone:', appointment.customer_phone);
  console.log('🔑 Credentials configured:', {
    hasSid: !!accountSid,
    hasToken: !!authToken,
    hasFromNumber: !!fromNumber,
    fromNumber: fromNumber
  });

  if (!accountSid || !authToken || !fromNumber) {
    console.warn('❌ Twilio WhatsApp credentials not configured, skipping WhatsApp');
    return;
  }

  try {
    let toNumber = appointment.customer_phone.replace(/\D/g, '');
    console.log('📱 Phone after removing non-digits:', toNumber);
    
    if (!toNumber.startsWith('55')) {
      toNumber = '55' + toNumber;
      console.log('📱 Added Brazil country code:', toNumber);
    }
    toNumber = '+' + toNumber;
    console.log('📱 Final formatted number:', toNumber);

    const message = `🙏 *Obrigado - José Barbearia*

Olá, *${appointment.customer_name}*!

Muito obrigado por visitar a José Barbearia! 💈

Foi um prazer atendê-lo hoje com o serviço de *${appointment.service_name}*.

Esperamos vê-lo novamente em breve!

⭐ Se gostou do atendimento, compartilhe com seus amigos!

📍 *José Barbearia*
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106`;

    const auth = btoa(`${accountSid}:${authToken}`);
    
    console.log('📤 Sending WhatsApp message...');
    console.log('From:', `whatsapp:${fromNumber}`);
    console.log('To:', `whatsapp:${toNumber}`);
    
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: `whatsapp:${fromNumber}`,
          To: `whatsapp:${toNumber}`,
          Body: message,
        }),
      }
    );

    console.log('📨 Twilio response status:', response.status);

    if (!response.ok) {
      const error = await response.text();
      console.error('❌ Twilio API error:', error);
      throw new Error(`Twilio API error: ${response.status}`);
    }

    const result = await response.json() as { sid: string };
    console.log('✅ WhatsApp thank you sent successfully!');
    console.log('To:', toNumber, 'SID:', result.sid);
  } catch (error) {
    console.error('❌ Error sending WhatsApp thank you:', error);
    if (error instanceof Error) {
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
    }
  }
}

export async function sendWhatsAppCancellation(
  accountSid: string,
  authToken: string,
  fromNumber: string,
  appointment: {
    customer_name: string;
    customer_phone: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  }
) {
  console.log('🎯 sendWhatsAppCancellation called for:', appointment.customer_name);
  console.log('📞 Phone:', appointment.customer_phone);

  if (!accountSid || !authToken || !fromNumber) {
    console.warn('❌ Twilio WhatsApp credentials not configured, skipping WhatsApp');
    return;
  }

  try {
    // Format the date in Portuguese - fix timezone issue
    const formattedDate = new Date(appointment.appointment_date + 'T00:00:00').toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    // Ensure phone number is in E.164 format
    let toNumber = appointment.customer_phone.replace(/\D/g, '');
    if (!toNumber.startsWith('55')) {
      toNumber = '55' + toNumber;
    }
    toNumber = '+' + toNumber;

    const message = `❌ *Agendamento Cancelado - José Barbearia*

Olá, *${appointment.customer_name}*!

Seu agendamento foi cancelado:

📌 *Serviço:* ${appointment.service_name}
📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}

Se você não solicitou este cancelamento ou deseja reagendar, entre em contato conosco.

📍 *José Barbearia*
Av. Otávio Rangel, 477 - Vila Cecap
Guariba - SP, 14845-106

Esperamos vê-lo em breve! 💈`;

    const auth = btoa(`${accountSid}:${authToken}`);
    
    console.log('📤 Sending WhatsApp cancellation...');
    
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: `whatsapp:${fromNumber}`,
          To: `whatsapp:${toNumber}`,
          Body: message,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('❌ Twilio API error:', error);
      throw new Error(`Twilio API error: ${response.status}`);
    }

    const result = await response.json() as { sid: string };
    console.log('✅ WhatsApp cancellation sent successfully!');
    console.log('To:', toNumber, 'SID:', result.sid);
  } catch (error) {
    console.error('❌ Error sending WhatsApp cancellation:', error);
    if (error instanceof Error) {
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
    }
  }
}

export async function sendBarberWhatsAppReminder(
  accountSid: string,
  authToken: string,
  fromNumber: string,
  barberPhone: string,
  appointment: {
    id?: number;
    customer_name: string;
    customer_phone: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  }
) {
  console.log('⏰ sendBarberWhatsAppReminder called');
  console.log('📞 Barber phone:', barberPhone);

  if (!accountSid || !authToken || !fromNumber || !barberPhone) {
    console.warn('❌ Missing credentials or barber phone, skipping notification');
    return;
  }

  try {
    // Format the date in Portuguese - fix timezone issue
    const formattedDate = new Date(appointment.appointment_date + 'T00:00:00').toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    // Ensure phone number is in E.164 format
    let toNumber = barberPhone.replace(/\D/g, '');
    if (!toNumber.startsWith('55')) {
      toNumber = '55' + toNumber;
    }
    toNumber = '+' + toNumber;

    // Format phone for WhatsApp link
    let phoneForLink = appointment.customer_phone.replace(/\D/g, '');
    if (!phoneForLink.startsWith('55')) {
      phoneForLink = '55' + phoneForLink;
    }
    const phoneLink = `https://wa.me/${phoneForLink}`;

    const message = `⏰ *AGENDAMENTO EM 45 MINUTOS!*

🔔 Próximo cliente chegando em breve:

👤 *Cliente:* ${appointment.customer_name}
📱 *Telefone:* ${phoneLink}
✂️ *Serviço:* ${appointment.service_name}
📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}

💡 *Dica:* Clique no número do cliente para enviar um lembrete via WhatsApp!

_José Barbearia - Sistema de Agendamentos_`;

    const auth = btoa(`${accountSid}:${authToken}`);
    
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: `whatsapp:${fromNumber}`,
          To: `whatsapp:${toNumber}`,
          Body: message,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('Twilio API error:', error);
      throw new Error(`Twilio API error: ${response.status}`);
    }

    const result = await response.json() as { sid: string };
    console.log('✅ Barber WhatsApp reminder sent:', toNumber, 'SID:', result.sid);
  } catch (error) {
    console.error('Error sending barber WhatsApp reminder:', error);
  }
}

export async function sendWhatsAppCancellationToBarber(
  accountSid: string,
  authToken: string,
  fromNumber: string,
  barberPhone: string,
  appointment: {
    id: number;
    customer_name: string;
    customer_phone: string;
    service_name: string;
    appointment_date: string;
    appointment_time: string;
  },
  baseUrl: string
) {
  console.log('🔔 sendWhatsAppCancellationToBarber called');
  console.log('📞 Barber phone:', barberPhone);

  if (!accountSid || !authToken || !fromNumber || !barberPhone) {
    console.warn('❌ Missing credentials or barber phone, skipping notification');
    return;
  }

  console.log('Using base URL:', baseUrl);

  try {
    // Format the date in Portuguese - fix timezone issue
    const formattedDate = new Date(appointment.appointment_date + 'T00:00:00').toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });

    // Ensure phone number is in E.164 format
    let toNumber = barberPhone.replace(/\D/g, '');
    if (!toNumber.startsWith('55')) {
      toNumber = '55' + toNumber;
    }
    toNumber = '+' + toNumber;

    // Format phone for WhatsApp link (ensure it has country code)
    let phoneForLink = appointment.customer_phone.replace(/\D/g, '');
    if (!phoneForLink.startsWith('55')) {
      phoneForLink = '55' + phoneForLink;
    }
    const phoneLink = `https://wa.me/${phoneForLink}`;

    const message = `❌ *AGENDAMENTO CANCELADO*

👤 *Cliente:* ${appointment.customer_name}
📱 *Telefone:* ${phoneLink}
✂️ *Serviço:* ${appointment.service_name}
📅 *Data:* ${formattedDate}
🕐 *Horário:* ${appointment.appointment_time}

ℹ️ O cliente cancelou este agendamento.

_José Barbearia - Sistema de Agendamentos_`;

    const auth = btoa(`${accountSid}:${authToken}`);
    
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: `whatsapp:${fromNumber}`,
          To: `whatsapp:${toNumber}`,
          Body: message,
        }),
      }
    );

    if (!response.ok) {
      const error = await response.text();
      console.error('Twilio API error:', error);
      throw new Error(`Twilio API error: ${response.status}`);
    }

    const result = await response.json() as { sid: string };
    console.log('✅ WhatsApp cancellation notification sent to barber:', toNumber, 'SID:', result.sid);
  } catch (error) {
    console.error('Error sending WhatsApp cancellation notification to barber:', error);
  }
}
