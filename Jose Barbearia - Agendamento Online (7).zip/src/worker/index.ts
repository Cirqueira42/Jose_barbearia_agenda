import { Hono } from "hono";
import { cors } from "hono/cors";
import { z } from "zod";
import type { Appointment } from "../shared/types";
import { sendConfirmationEmail, sendReminderEmail, send45MinuteReminderEmail, sendCancellationEmail, sendCompletionEmailToBarber } from "./email";
import { sendWhatsAppThankYou, sendWhatsAppConfirmation, sendWhatsAppNotificationToBarber, sendWhatsAppCancellation, sendWhatsAppCancellationToBarber, sendBarberWhatsAppReminder } from "./whatsapp";
import { handleTwilioWebhook } from "./twilio-webhook";
import {
  getOAuthRedirectUrl,
  exchangeCodeForSessionToken,
  deleteSession,
  getCurrentUser,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";

const app = new Hono<{ Bindings: Env }>();

app.use("/*", cors({
  origin: (origin) => origin,
  allowMethods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type'],
  credentials: true,
}));

// Authentication endpoints
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (!sessionToken) {
    return c.json({ user: null }, 200);
  }

  const user = await getCurrentUser(sessionToken, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ user }, 200);
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Validation schema
const createAppointmentSchema = z.object({
  service_id: z.string().min(1),
  service_name: z.string().min(1),
  service_duration: z.number().int().positive(),
  customer_name: z.string().min(1),
  customer_email: z.string().email().optional().or(z.literal('')),
  customer_phone: z.string().min(1),
  appointment_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  appointment_time: z.string().regex(/^\d{2}:\d{2}$/),
  payment_method: z.string().optional().nullable(),
});

// Customer lookup endpoint
app.get("/api/customers/lookup", async (c) => {
  try {
    const phone = c.req.query("phone");

    if (!phone) {
      return c.json({ error: "Telefone é obrigatório" }, 400);
    }

    // Clean phone number (remove formatting)
    const cleanPhone = phone.replace(/\D/g, '');

    const customer = await c.env.DB.prepare(
      "SELECT * FROM customers WHERE phone LIKE ?"
    )
      .bind(`%${cleanPhone}%`)
      .first();

    if (customer) {
      return c.json({ found: true, customer });
    } else {
      return c.json({ found: false });
    }
  } catch (error) {
    console.error("Error looking up customer:", error);
    return c.json({ error: "Erro ao buscar cliente" }, 500);
  }
});

// Create appointment
app.post("/api/appointments", async (c) => {
  try {
    const body = await c.req.json();
    const data = createAppointmentSchema.parse(body);

    // Check if the time slot is available
    const existing = await c.env.DB.prepare(
      `SELECT id FROM appointments 
       WHERE appointment_date = ? 
       AND appointment_time = ? 
       AND status != 'cancelled'`
    )
      .bind(data.appointment_date, data.appointment_time)
      .first();

    if (existing) {
      return c.json(
        { error: "Este horário já está reservado. Por favor, escolha outro horário." },
        409
      );
    }

    // Clean phone number for customer lookup
    const cleanPhone = data.customer_phone.replace(/\D/g, '');

    // Check if customer exists, if not create them
    const existingCustomer = await c.env.DB.prepare(
      "SELECT * FROM customers WHERE phone LIKE ?"
    )
      .bind(`%${cleanPhone}%`)
      .first();

    if (existingCustomer) {
      // Update existing customer info (in case name/email changed)
      await c.env.DB.prepare(
        `UPDATE customers 
         SET name = ?, email = ?, total_appointments = total_appointments + 1, updated_at = CURRENT_TIMESTAMP 
         WHERE id = ?`
      )
        .bind(data.customer_name, data.customer_email || '', existingCustomer.id)
        .run();
    } else {
      // Create new customer
      await c.env.DB.prepare(
        `INSERT INTO customers (name, phone, email, total_appointments) 
         VALUES (?, ?, ?, 1)`
      )
        .bind(data.customer_name, data.customer_phone, data.customer_email || '')
        .run();
    }

    // Set initial payment status based on payment method
    const initialPaymentStatus = data.payment_method === 'pix' ? 'pending' : 'not_required';

    const result = await c.env.DB.prepare(
      `INSERT INTO appointments 
       (service_id, service_name, service_duration, customer_name, customer_email, customer_phone, appointment_date, appointment_time, status, payment_method, payment_status) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)`
    )
      .bind(
        data.service_id,
        data.service_name,
        data.service_duration,
        data.customer_name,
        data.customer_email,
        data.customer_phone,
        data.appointment_date,
        data.appointment_time,
        data.payment_method || null,
        initialPaymentStatus
      )
      .run();

    const appointment = await c.env.DB.prepare(
      "SELECT * FROM appointments WHERE id = ?"
    )
      .bind(result.meta.last_row_id)
      .first<Appointment>();

    // Get barber email from settings
    const barberEmailSetting = await c.env.DB.prepare(
      "SELECT value FROM settings WHERE key = 'barber_email'"
    ).first<{ value: string }>();
    const barberEmail = barberEmailSetting?.value;

    // ALWAYS send notification email - to customer if they provided email, to barber regardless
    if (appointment) {
      try {
        await sendConfirmationEmail(c.env.RESEND_API_KEY, {
          id: appointment.id,
          customer_name: appointment.customer_name,
          customer_email: appointment.customer_email || '', // Empty string if no customer email
          customer_phone: appointment.customer_phone,
          service_name: appointment.service_name,
          appointment_date: appointment.appointment_date,
          appointment_time: appointment.appointment_time
        }, barberEmail);
      } catch (error) {
        console.error('Failed to send confirmation email:', error);
        // Don't fail the appointment creation if email fails
      }
    }

    // Get the base URL
    const requestUrl = new URL(c.req.url);
    const baseUrl = requestUrl.hostname.includes('mocha.app') 
      ? requestUrl.origin 
      : 'https://e4id45fo46lti.mocha.app';

    // Send WhatsApp confirmation to customer
    if (appointment) {
      console.log('📱 Attempting to send WhatsApp confirmation to customer...');
      try {
        await sendWhatsAppConfirmation(
          c.env.TWILIO_ACCOUNT_SID,
          c.env.TWILIO_AUTH_TOKEN,
          c.env.TWILIO_WHATSAPP_NUMBER,
          {
            id: appointment.id,
            customer_name: appointment.customer_name,
            customer_phone: appointment.customer_phone,
            service_name: appointment.service_name,
            appointment_date: appointment.appointment_date,
            appointment_time: appointment.appointment_time
          },
          baseUrl
        );
        console.log('✅ WhatsApp confirmation sent to customer');
      } catch (error) {
        console.error('❌ Failed to send WhatsApp confirmation to customer:', error);
        if (error instanceof Error) {
          console.error('Error details:', error.message, error.stack);
        }
        // Don't fail the appointment creation if WhatsApp fails
      }
    }

    // Send WhatsApp notification to barber
    const barberWhatsAppSetting = await c.env.DB.prepare(
      "SELECT value FROM settings WHERE key = 'whatsapp'"
    ).first<{ value: string }>();
    const barberWhatsApp = barberWhatsAppSetting?.value;

    if (appointment && barberWhatsApp) {
      console.log('📱 Attempting to send WhatsApp notification to barber...');
      console.log('Barber WhatsApp from DB:', barberWhatsApp);
      try {
        await sendWhatsAppNotificationToBarber(
          c.env.TWILIO_ACCOUNT_SID,
          c.env.TWILIO_AUTH_TOKEN,
          c.env.TWILIO_WHATSAPP_NUMBER,
          barberWhatsApp,
          {
            id: appointment.id,
            customer_name: appointment.customer_name,
            customer_phone: appointment.customer_phone,
            service_name: appointment.service_name,
            appointment_date: appointment.appointment_date,
            appointment_time: appointment.appointment_time
          }
        );
        console.log('✅ WhatsApp notification sent to barber');
      } catch (error) {
        console.error('❌ Failed to send WhatsApp notification to barber:', error);
        if (error instanceof Error) {
          console.error('Error details:', error.message, error.stack);
        }
        // Don't fail the appointment creation if WhatsApp fails
      }
    } else {
      console.warn('⚠️ Skipping barber notification - missing appointment or barber WhatsApp');
      console.log('Has appointment:', !!appointment);
      console.log('Has barber WhatsApp:', !!barberWhatsApp);
    }

    return c.json(appointment, 201);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return c.json({ error: "Dados inválidos", details: error.errors }, 400);
    }
    console.error("Error creating appointment:", error);
    return c.json({ error: "Erro ao criar agendamento" }, 500);
  }
});

// Send WhatsApp confirmation - simple endpoint for barber to use
app.post("/api/appointments/:id/send-confirmation", async (c) => {
  try {
    const id = c.req.param("id");

    // Get appointment
    const appointment = await c.env.DB.prepare(
      "SELECT * FROM appointments WHERE id = ?"
    ).bind(id).first<Appointment>();

    if (!appointment) {
      return c.json({ error: "Agendamento não encontrado" }, 404);
    }

    // Get the base URL
    const requestUrl = new URL(c.req.url);
    const baseUrl = requestUrl.hostname.includes('mocha.app') 
      ? requestUrl.origin 
      : 'https://e4id45fo46lti.mocha.app';

    // Send WhatsApp confirmation
    await sendWhatsAppConfirmation(
      c.env.TWILIO_ACCOUNT_SID,
      c.env.TWILIO_AUTH_TOKEN,
      c.env.TWILIO_WHATSAPP_NUMBER,
      {
        id: appointment.id,
        customer_name: appointment.customer_name,
        customer_phone: appointment.customer_phone,
        service_name: appointment.service_name,
        appointment_date: appointment.appointment_date,
        appointment_time: appointment.appointment_time
      },
      baseUrl
    );

    return c.json({ 
      success: true, 
      message: "Confirmação enviada via WhatsApp com sucesso!"
    });
  } catch (error) {
    console.error("Error sending WhatsApp confirmation:", error);
    return c.json({ 
      error: "Erro ao enviar confirmação",
      details: error instanceof Error ? error.message : "Erro desconhecido"
    }, 500);
  }
});

// Blocked times endpoints
app.get("/api/blocked-times", async (c) => {
  try {
    const result = await c.env.DB.prepare(
      "SELECT * FROM blocked_times WHERE block_date >= date('now') ORDER BY block_date ASC, start_time ASC"
    ).all();

    return c.json({ blocked_times: result.results });
  } catch (error) {
    console.error("Error fetching blocked times:", error);
    return c.json({ error: "Erro ao buscar bloqueios" }, 500);
  }
});

app.post("/api/blocked-times", async (c) => {
  try {
    const data = await c.req.json();

    await c.env.DB.prepare(
      `INSERT INTO blocked_times (block_date, start_time, end_time, is_full_day, reason)
       VALUES (?, ?, ?, ?, ?)`
    ).bind(
      data.block_date,
      data.start_time || null,
      data.end_time || null,
      data.is_full_day ? 1 : 0,
      data.reason || null
    ).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error creating blocked time:", error);
    return c.json({ error: "Erro ao criar bloqueio" }, 500);
  }
});

app.delete("/api/blocked-times/:id", async (c) => {
  try {
    const id = c.req.param("id");

    await c.env.DB.prepare(
      "DELETE FROM blocked_times WHERE id = ?"
    ).bind(id).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting blocked time:", error);
    return c.json({ error: "Erro ao deletar bloqueio" }, 500);
  }
});

// Get available time slots for a date
app.get("/api/appointments/available-times", async (c) => {
  const date = c.req.query("date");
  const serviceDuration = parseInt(c.req.query("duration") || "0");

  if (!date) {
    return c.json({ error: "Data é obrigatória" }, 400);
  }

  // Add cache control headers to ensure fresh data
  c.header('Cache-Control', 'no-cache, no-store, must-revalidate');
  c.header('Pragma', 'no-cache');
  c.header('Expires', '0');

  // Check if the entire day is blocked
  const fullDayBlock = await c.env.DB.prepare(
    `SELECT id FROM blocked_times 
     WHERE block_date = ? 
     AND is_full_day = 1`
  )
    .bind(date)
    .first();

  if (fullDayBlock) {
    return c.json({ available_times: [] });
  }

  // Get partial blocks for this date
  const blockedTimes = await c.env.DB.prepare(
    `SELECT start_time, end_time FROM blocked_times 
     WHERE block_date = ? 
     AND is_full_day = 0`
  )
    .bind(date)
    .all<{ start_time: string; end_time: string }>();

  const bookedAppointments = await c.env.DB.prepare(
    `SELECT appointment_time, service_duration FROM appointments 
     WHERE appointment_date = ? 
     AND status != 'cancelled'`
  )
    .bind(date)
    .all<{ appointment_time: string; service_duration: number }>();

  // Determine day of week (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
  const dateObj = new Date(date + 'T00:00:00');
  const dayOfWeek = dateObj.getDay();
  
  const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const dayName = dayNames[dayOfWeek];

  // Get business hours from settings
  const settings = await c.env.DB.prepare(
    `SELECT key, value FROM settings WHERE key LIKE 'hours_${dayName}_%'`
  ).all<{ key: string; value: string }>();

  const settingsMap: Record<string, string> = {};
  settings.results.forEach(row => {
    settingsMap[row.key] = row.value;
  });

  // Check if closed
  if (settingsMap[`hours_${dayName}_closed`] === 'true') {
    return c.json({ available_times: [] });
  }

  // Get hours or default to full day (8:00-20:00) if not set
  const morningStartStr = settingsMap[`hours_${dayName}_morning_start`] || '08:00';
  const morningEndStr = settingsMap[`hours_${dayName}_morning_end`] || '12:00';
  const afternoonStartStr = settingsMap[`hours_${dayName}_afternoon_start`] || '13:00';
  const afternoonEndStr = settingsMap[`hours_${dayName}_afternoon_end`] || '20:00';

  // Convert time strings to minutes
  const timeToMinutes = (time: string) => {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  };

  const morningStart = timeToMinutes(morningStartStr);
  const morningEnd = timeToMinutes(morningEndStr);
  const afternoonStart = timeToMinutes(afternoonStartStr);
  const afternoonEnd = timeToMinutes(afternoonEndStr);

  // Generate time slots in 10-minute intervals
  const allTimes: string[] = [];

  // Morning slots
  for (let time = morningStart; time < morningEnd; time += 10) {
    const hours = Math.floor(time / 60);
    const minutes = time % 60;
    allTimes.push(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`);
  }

  // Afternoon slots
  for (let time = afternoonStart; time < afternoonEnd; time += 10) {
    const hours = Math.floor(time / 60);
    const minutes = time % 60;
    allTimes.push(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`);
  }

  // Filter out booked times, blocked times, and times that overlap with existing appointments
  // Add 10 minute buffer after each appointment
  let available = allTimes.filter(time => {
    const [hours, minutes] = time.split(':').map(Number);
    const timeMinutes = hours * 60 + minutes;

    // Check if this time slot overlaps with any existing appointment (including 10-min buffer)
    for (const appointment of bookedAppointments.results) {
      const [apptHours, apptMinutes] = appointment.appointment_time.split(':').map(Number);
      const apptStartMinutes = apptHours * 60 + apptMinutes;
      const apptEndMinutes = apptStartMinutes + appointment.service_duration + 10; // Add 10 min buffer

      // Check if the current time falls within an existing appointment's duration + buffer
      if (timeMinutes >= apptStartMinutes && timeMinutes < apptEndMinutes) {
        return false;
      }

      // NEW: If we know the service duration, check if there's enough time to complete it
      // before the next appointment starts
      if (serviceDuration > 0) {
        const newServiceEndMinutes = timeMinutes + serviceDuration + 10; // Include 10 min buffer
        
        // Check if this new service would overlap with the existing appointment
        if (timeMinutes < apptStartMinutes && newServiceEndMinutes > apptStartMinutes) {
          return false;
        }
      }
    }

    // Check if this time slot falls within any blocked time range
    for (const block of blockedTimes.results) {
      const [blkStartHours, blkStartMins] = block.start_time.split(':').map(Number);
      const [blkEndHours, blkEndMins] = block.end_time.split(':').map(Number);
      const blkStartMinutes = blkStartHours * 60 + blkStartMins;
      const blkEndMinutes = blkEndHours * 60 + blkEndMins;

      // Check if the current time falls within the blocked range
      if (timeMinutes >= blkStartMinutes && timeMinutes < blkEndMinutes) {
        return false;
      }

      // NEW: If we know the service duration, check if there's enough time to complete it
      // before the blocked time starts
      if (serviceDuration > 0) {
        const newServiceEndMinutes = timeMinutes + serviceDuration + 10; // Include 10 min buffer
        
        // Check if this new service would overlap with the blocked time
        if (timeMinutes < blkStartMinutes && newServiceEndMinutes > blkStartMinutes) {
          return false;
        }
      }
    }

    return true;
  });

  // Filter out times less than 10 minutes from now if the date is today
  // Convert current UTC time to Brazil time (UTC-3)
  const nowUTC = new Date();
  const nowBrazil = new Date(nowUTC.getTime() - 3 * 60 * 60 * 1000);
  const today = nowBrazil.toISOString().split('T')[0];
  
  if (date === today) {
    const currentMinutes = nowBrazil.getHours() * 60 + nowBrazil.getMinutes() + 10; // Add 10 minute buffer

    available = available.filter(time => {
      const [hours, minutes] = time.split(':').map(Number);
      const timeMinutes = hours * 60 + minutes;
      return timeMinutes >= currentMinutes;
    });
  }

  return c.json({ available_times: available });
});

// Twilio webhook endpoint for incoming messages
app.post("/api/twilio/webhook", async (c) => {
  try {
    console.log('📨 Twilio webhook endpoint hit');
    
    const formData = await c.req.formData();
    const response = await handleTwilioWebhook(formData, c.env);

    // Return TwiML response
    const twiml = response 
      ? `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>${response}</Message>
</Response>`
      : `<?xml version="1.0" encoding="UTF-8"?>
<Response></Response>`;

    return c.text(twiml, 200, {
      'Content-Type': 'text/xml'
    });
  } catch (error) {
    console.error('❌ Error in Twilio webhook:', error);
    return c.text(
      `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>Erro ao processar mensagem.</Message>
</Response>`,
      500,
      {
        'Content-Type': 'text/xml'
      }
    );
  }
});

// Test WhatsApp notification endpoint
app.post("/api/test-whatsapp", async (c) => {
  try {
    const body = await c.req.json();
    const { phone, message } = body;

    if (!phone) {
      return c.json({ error: "Telefone é obrigatório" }, 400);
    }

    console.log('🧪 Testing WhatsApp with:', { phone, message });
    console.log('🔑 Credentials:', {
      hasSid: !!c.env.TWILIO_ACCOUNT_SID,
      hasToken: !!c.env.TWILIO_AUTH_TOKEN,
      hasFromNumber: !!c.env.TWILIO_WHATSAPP_NUMBER,
      fromNumber: c.env.TWILIO_WHATSAPP_NUMBER,
      sidLength: c.env.TWILIO_ACCOUNT_SID?.length || 0
    });

    // Ensure phone number is in E.164 format
    let toNumber = phone.replace(/\D/g, '');
    if (!toNumber.startsWith('55')) {
      toNumber = '55' + toNumber;
    }
    toNumber = '+' + toNumber;

    const testMessage = message || `🧪 *Teste de WhatsApp - José Barbearia*

Este é um teste do sistema de notificações WhatsApp.

Se você recebeu esta mensagem, o sistema está funcionando corretamente! ✅

_José Barbearia - Sistema de Agendamentos_`;

    const auth = btoa(`${c.env.TWILIO_ACCOUNT_SID}:${c.env.TWILIO_AUTH_TOKEN}`);
    
    console.log('📤 Sending test WhatsApp...');
    console.log('From:', `whatsapp:${c.env.TWILIO_WHATSAPP_NUMBER}`);
    console.log('To:', `whatsapp:${toNumber}`);

    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${c.env.TWILIO_ACCOUNT_SID}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: `whatsapp:${c.env.TWILIO_WHATSAPP_NUMBER}`,
          To: `whatsapp:${toNumber}`,
          Body: testMessage,
        }),
      }
    );

    console.log('📨 Twilio response status:', response.status);

    if (!response.ok) {
      const error = await response.text();
      console.error('❌ Twilio API error:', error);
      return c.json({ 
        success: false, 
        error: `Twilio API error: ${response.status}`,
        details: error,
        to: toNumber,
        from: c.env.TWILIO_WHATSAPP_NUMBER
      }, 500);
    }

    const result = await response.json() as { sid: string; status: string };
    console.log('✅ Test WhatsApp sent successfully!');
    console.log('SID:', result.sid, 'Status:', result.status);

    return c.json({
      success: true,
      message: 'Mensagem de teste enviada com sucesso!',
      sid: result.sid,
      status: result.status,
      to: toNumber,
      from: c.env.TWILIO_WHATSAPP_NUMBER
    });
  } catch (error) {
    console.error('❌ Error in test WhatsApp:', error);
    return c.json({ 
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido',
      details: error instanceof Error ? error.stack : undefined
    }, 500);
  }
});

// Get all appointments (for admin)
app.get("/api/appointments", async (c) => {
  const status = c.req.query("status");
  const date = c.req.query("date");

  // Add cache control headers to ensure fresh data
  c.header('Cache-Control', 'no-cache, no-store, must-revalidate');
  c.header('Pragma', 'no-cache');
  c.header('Expires', '0');

  let query = "SELECT * FROM appointments WHERE 1=1";
  const params: string[] = [];

  if (status) {
    query += " AND status = ?";
    params.push(status);
  }

  if (date) {
    query += " AND appointment_date = ?";
    params.push(date);
  }

  query += " ORDER BY appointment_date ASC, appointment_time ASC";

  const stmt = c.env.DB.prepare(query);
  const result = await (params.length > 0 
    ? stmt.bind(...params) 
    : stmt
  ).all<Appointment>();

  return c.json(result.results);
});

// Update payment status
app.patch("/api/appointments/:id/payment", async (c) => {
  const id = c.req.param("id");
  const { payment_status } = await c.req.json();

  if (!["pending", "confirmed"].includes(payment_status)) {
    return c.json({ error: "Status de pagamento inválido" }, 400);
  }

  await c.env.DB.prepare(
    "UPDATE appointments SET payment_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(payment_status, id)
    .run();

  const updatedAppointment = await c.env.DB.prepare(
    "SELECT * FROM appointments WHERE id = ?"
  )
    .bind(id)
    .first<Appointment>();

  return c.json(updatedAppointment);
});

// Update appointment status
app.patch("/api/appointments/:id", async (c) => {
  const id = c.req.param("id");
  const { status } = await c.req.json();

  if (!["pending", "confirmed", "completed", "cancelled"].includes(status)) {
    return c.json({ error: "Status inválido" }, 400);
  }

  // Get appointment details before updating
  const appointment = await c.env.DB.prepare(
    "SELECT * FROM appointments WHERE id = ?"
  )
    .bind(id)
    .first<Appointment>();

  if (!appointment) {
    return c.json({ error: "Agendamento não encontrado" }, 404);
  }

  // Update the status
  await c.env.DB.prepare(
    "UPDATE appointments SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  )
    .bind(status, id)
    .run();

  // Get updated appointment
  const updatedAppointment = await c.env.DB.prepare(
    "SELECT * FROM appointments WHERE id = ?"
  )
    .bind(id)
    .first<Appointment>();

  if (!updatedAppointment) {
    return c.json({ error: "Agendamento não encontrado" }, 404);
  }

  // Get barber email from settings
  const barberEmailSetting = await c.env.DB.prepare(
    "SELECT value FROM settings WHERE key = 'barber_email'"
  ).first<{ value: string }>();
  const barberEmail = barberEmailSetting?.value;

  // Send notifications based on status change
  if (status === 'confirmed') {
    // Check if appointment is in the past - don't notify if it is
    const appointmentDate = new Date(updatedAppointment.appointment_date + 'T00:00:00');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const isPastAppointment = appointmentDate < today;

    if (isPastAppointment) {
      console.log('⏸️ Skipping notifications - appointment is in the past');
    } else {
      // Send confirmation email - to customer if they have email, to barber always
      try {
        await sendConfirmationEmail(c.env.RESEND_API_KEY, {
          id: updatedAppointment.id,
          customer_name: updatedAppointment.customer_name,
          customer_email: updatedAppointment.customer_email || '',
          customer_phone: updatedAppointment.customer_phone,
          service_name: updatedAppointment.service_name,
          appointment_date: updatedAppointment.appointment_date,
          appointment_time: updatedAppointment.appointment_time
        }, barberEmail);
        console.log('✅ Confirmation email sent (admin action)');
      } catch (error) {
        console.error('❌ Failed to send confirmation email (admin action):', error);
      }
      // Get the base URL
      const requestUrl = new URL(c.req.url);
      const baseUrl = requestUrl.hostname.includes('mocha.app') 
        ? requestUrl.origin 
        : 'https://e4id45fo46lti.mocha.app';

      // Send confirmation WhatsApp to customer
      await sendWhatsAppConfirmation(
        c.env.TWILIO_ACCOUNT_SID,
        c.env.TWILIO_AUTH_TOKEN,
        c.env.TWILIO_WHATSAPP_NUMBER,
        {
          id: updatedAppointment.id,
          customer_name: updatedAppointment.customer_name,
          customer_phone: updatedAppointment.customer_phone,
          service_name: updatedAppointment.service_name,
          appointment_date: updatedAppointment.appointment_date,
          appointment_time: updatedAppointment.appointment_time
        },
        baseUrl
      );
    }
  } else if (status === 'completed') {
    // Send thank you WhatsApp when completed
    await sendWhatsAppThankYou(
      c.env.TWILIO_ACCOUNT_SID,
      c.env.TWILIO_AUTH_TOKEN,
      c.env.TWILIO_WHATSAPP_NUMBER,
      {
        customer_name: updatedAppointment.customer_name,
        customer_phone: updatedAppointment.customer_phone,
        service_name: updatedAppointment.service_name
      }
    );

    // Send completion email to barber with WhatsApp link
    if (barberEmail) {
      try {
        await sendCompletionEmailToBarber(
          c.env.RESEND_API_KEY,
          {
            id: updatedAppointment.id,
            customer_name: updatedAppointment.customer_name,
            customer_phone: updatedAppointment.customer_phone,
            service_name: updatedAppointment.service_name,
            appointment_date: updatedAppointment.appointment_date,
            appointment_time: updatedAppointment.appointment_time
          },
          barberEmail
        );
        console.log('✅ Completion email sent to barber');
      } catch (error) {
        console.error('❌ Failed to send completion email to barber:', error);
      }
    }
  } else if (status === 'cancelled') {
    // Send cancellation email - to customer if they have email, to barber always
    try {
      await sendCancellationEmail(
        c.env.RESEND_API_KEY,
        {
          customer_name: updatedAppointment.customer_name,
          customer_email: updatedAppointment.customer_email || '',
          service_name: updatedAppointment.service_name,
          appointment_date: updatedAppointment.appointment_date,
          appointment_time: updatedAppointment.appointment_time
        },
        barberEmail
      );
      console.log('✅ Cancellation email sent');
    } catch (error) {
      console.error('❌ Failed to send cancellation email:', error);
      // Don't fail the cancellation if email fails
    }

    // Send cancellation WhatsApp to customer
    try {
      await sendWhatsAppCancellation(
        c.env.TWILIO_ACCOUNT_SID,
        c.env.TWILIO_AUTH_TOKEN,
        c.env.TWILIO_WHATSAPP_NUMBER,
        {
          customer_name: updatedAppointment.customer_name,
          customer_phone: updatedAppointment.customer_phone,
          service_name: updatedAppointment.service_name,
          appointment_date: updatedAppointment.appointment_date,
          appointment_time: updatedAppointment.appointment_time
        }
      );
      console.log('✅ Cancellation WhatsApp sent to customer');
    } catch (error) {
      console.error('❌ Failed to send cancellation WhatsApp to customer:', error);
      // Don't fail the cancellation if WhatsApp fails
    }

    // Send cancellation notification to barber
    const barberWhatsAppSetting = await c.env.DB.prepare(
      "SELECT value FROM settings WHERE key = 'whatsapp'"
    ).first<{ value: string }>();
    const barberWhatsApp = barberWhatsAppSetting?.value;

    if (barberWhatsApp) {
      try {
        // Get the base URL - use published URL in production, or request URL in dev
        const requestUrl = new URL(c.req.url);
        const baseUrl = requestUrl.hostname.includes('mocha.app') 
          ? requestUrl.origin 
          : 'https://e4id45fo46lti.mocha.app';

        await sendWhatsAppCancellationToBarber(
          c.env.TWILIO_ACCOUNT_SID,
          c.env.TWILIO_AUTH_TOKEN,
          c.env.TWILIO_WHATSAPP_NUMBER,
          barberWhatsApp,
          {
            id: updatedAppointment.id,
            customer_name: updatedAppointment.customer_name,
            customer_phone: updatedAppointment.customer_phone,
            service_name: updatedAppointment.service_name,
            appointment_date: updatedAppointment.appointment_date,
            appointment_time: updatedAppointment.appointment_time
          },
          baseUrl
        );
        console.log('✅ Cancellation notification sent to barber');
      } catch (error) {
        console.error('❌ Failed to send cancellation notification to barber:', error);
        // Don't fail the cancellation if WhatsApp fails
      }
    }
  }

  return c.json(updatedAppointment);
});

// Send reminders for tomorrow's appointments
app.post("/api/appointments/send-reminders", async (c) => {
  try {
    // Get tomorrow's date
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowDate = tomorrow.toISOString().split('T')[0];

    // Get all confirmed appointments for tomorrow
    const appointments = await c.env.DB.prepare(
      `SELECT * FROM appointments 
       WHERE appointment_date = ? 
       AND status = 'confirmed'
       ORDER BY appointment_time ASC`
    )
      .bind(tomorrowDate)
      .all<Appointment>();

    let sent = 0;
    let failed = 0;

    // Get barber email from settings
    const barberEmailSetting = await c.env.DB.prepare(
      "SELECT value FROM settings WHERE key = 'barber_email'"
    ).first<{ value: string }>();
    const barberEmail = barberEmailSetting?.value;

    // Send reminder for each appointment
    for (const appointment of appointments.results) {
      try {
        await sendReminderEmail(c.env.RESEND_API_KEY, {
          customer_name: appointment.customer_name,
          customer_email: appointment.customer_email,
          service_name: appointment.service_name,
          appointment_date: appointment.appointment_date,
          appointment_time: appointment.appointment_time
        }, barberEmail);
        sent++;
      } catch (error) {
        console.error(`Failed to send reminder to ${appointment.customer_email}:`, error);
        failed++;
      }
    }

    return c.json({
      message: "Lembretes enviados",
      date: tomorrowDate,
      total: appointments.results.length,
      sent,
      failed
    });
  } catch (error) {
    console.error("Error sending reminders:", error);
    return c.json({ error: "Erro ao enviar lembretes" }, 500);
  }
});

// Pomade sales endpoints (protected)
app.get("/api/pomades/stats", async (c) => {
  try {
    const today = new Date().toISOString().split('T')[0];

    // Total sales count
    const totalSalesResult = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM pomade_sales"
    ).first<{ count: number }>();

    // Total revenue
    const revenueResult = await c.env.DB.prepare(
      "SELECT SUM(total_price) as revenue FROM pomade_sales"
    ).first<{ revenue: number }>();

    // Total units sold
    const unitsResult = await c.env.DB.prepare(
      "SELECT SUM(quantity) as units FROM pomade_sales"
    ).first<{ units: number }>();

    // Today's sales count
    const todaySalesResult = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM pomade_sales WHERE sale_date = ?"
    ).bind(today).first<{ count: number }>();

    return c.json({
      total_sales: totalSalesResult?.count || 0,
      total_revenue: revenueResult?.revenue || 0,
      units_sold: unitsResult?.units || 0,
      today_sales: todaySalesResult?.count || 0
    });
  } catch (error) {
    console.error("Error fetching pomade stats:", error);
    return c.json({ error: "Erro ao buscar estatísticas" }, 500);
  }
});

app.get("/api/pomades/sales", async (c) => {
  try {
    const limit = parseInt(c.req.query("limit") || "10");

    const result = await c.env.DB.prepare(
      `SELECT * FROM pomade_sales 
       ORDER BY created_at DESC 
       LIMIT ?`
    ).bind(limit).all();

    return c.json({ sales: result.results });
  } catch (error) {
    console.error("Error fetching pomade sales:", error);
    return c.json({ error: "Erro ao buscar vendas" }, 500);
  }
});

app.post("/api/pomades/sales", async (c) => {
  try {
    const data = await c.req.json();

    const result = await c.env.DB.prepare(
      `INSERT INTO pomade_sales 
       (customer_name, customer_phone, pomade_type, quantity, total_price, payment_method, sale_date)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      data.customer_name,
      data.customer_phone || null,
      data.pomade_type,
      data.quantity,
      data.total_price,
      data.payment_method,
      data.sale_date
    ).run();

    return c.json({
      success: true,
      id: result.meta.last_row_id
    });
  } catch (error) {
    console.error("Error creating pomade sale:", error);
    return c.json({ error: "Erro ao registrar venda" }, 500);
  }
});

// Settings endpoints (public read, protected write)
app.get("/api/settings", async (c) => {
  try {
    const result = await c.env.DB.prepare(
      "SELECT key, value FROM settings"
    ).all<{ key: string; value: string }>();

    const settings: Record<string, string> = {};
    result.results.forEach(row => {
      settings[row.key] = row.value;
    });

    // Add cache control headers to ensure fresh data
    c.header('Cache-Control', 'no-cache, no-store, must-revalidate');
    c.header('Pragma', 'no-cache');
    c.header('Expires', '0');

    return c.json(settings);
  } catch (error) {
    console.error("Error fetching settings:", error);
    return c.json({ error: "Erro ao buscar configurações" }, 500);
  }
});

app.patch("/api/settings", async (c) => {
  try {
    const updates = await c.req.json();

    for (const [key, value] of Object.entries(updates)) {
      await c.env.DB.prepare(
        `INSERT INTO settings (key, value) VALUES (?, ?)
         ON CONFLICT(key) DO UPDATE SET value = ?, updated_at = CURRENT_TIMESTAMP`
      ).bind(key, value, value).run();
    }

    return c.json({ success: true });
  } catch (error) {
    console.error("Error updating settings:", error);
    return c.json({ error: "Erro ao atualizar configurações" }, 500);
  }
});

// Services configuration endpoints (public read, protected write)
app.get("/api/services-config", async (c) => {
  try {
    const result = await c.env.DB.prepare(
      "SELECT * FROM services_config WHERE is_active = 1 ORDER BY display_order ASC"
    ).all();

    // Add cache control headers to ensure fresh data
    c.header('Cache-Control', 'no-cache, no-store, must-revalidate');
    c.header('Pragma', 'no-cache');
    c.header('Expires', '0');

    return c.json(result.results);
  } catch (error) {
    console.error("Error fetching services:", error);
    return c.json({ error: "Erro ao buscar serviços" }, 500);
  }
});

app.post("/api/services-config", async (c) => {
  try {
    const data = await c.req.json();

    await c.env.DB.prepare(
      `INSERT INTO services_config (id, name, description, price, duration, icon, image, display_order)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      data.id,
      data.name,
      data.description,
      data.price,
      data.duration,
      data.icon,
      data.image,
      data.display_order || 0
    ).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error creating service:", error);
    return c.json({ error: "Erro ao criar serviço" }, 500);
  }
});

app.patch("/api/services-config/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const data = await c.req.json();

    await c.env.DB.prepare(
      `UPDATE services_config 
       SET name = ?, description = ?, price = ?, duration = ?, icon = ?, image = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(
      data.name,
      data.description,
      data.price,
      data.duration,
      data.icon,
      data.image,
      id
    ).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error updating service:", error);
    return c.json({ error: "Erro ao atualizar serviço" }, 500);
  }
});

app.delete("/api/services-config/:id", async (c) => {
  try {
    const id = c.req.param("id");

    await c.env.DB.prepare(
      "UPDATE services_config SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    ).bind(id).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting service:", error);
    return c.json({ error: "Erro ao deletar serviço" }, 500);
  }
});

// Gallery photos endpoints (public read, protected write)
app.get("/api/gallery-photos", async (c) => {
  try {
    const result = await c.env.DB.prepare(
      "SELECT * FROM gallery_photos WHERE is_active = 1 ORDER BY display_order ASC"
    ).all();

    return c.json(result.results);
  } catch (error) {
    console.error("Error fetching gallery photos:", error);
    return c.json({ error: "Erro ao buscar fotos" }, 500);
  }
});

app.post("/api/gallery-photos", async (c) => {
  try {
    const data = await c.req.json();

    await c.env.DB.prepare(
      `INSERT INTO gallery_photos (url, alt, display_order)
       VALUES (?, ?, ?)`
    ).bind(
      data.url,
      data.alt,
      data.display_order || 0
    ).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error creating gallery photo:", error);
    return c.json({ error: "Erro ao adicionar foto" }, 500);
  }
});

app.patch("/api/gallery-photos/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const data = await c.req.json();

    await c.env.DB.prepare(
      `UPDATE gallery_photos 
       SET url = ?, alt = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(data.url, data.alt, id).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error updating gallery photo:", error);
    return c.json({ error: "Erro ao atualizar foto" }, 500);
  }
});

app.delete("/api/gallery-photos/:id", async (c) => {
  try {
    const id = c.req.param("id");

    await c.env.DB.prepare(
      "UPDATE gallery_photos SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    ).bind(id).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting gallery photo:", error);
    return c.json({ error: "Erro ao deletar foto" }, 500);
  }
});

// Pomade types endpoints (public read, protected write)
app.get("/api/pomade-types", async (c) => {
  try {
    const result = await c.env.DB.prepare(
      "SELECT * FROM pomade_types WHERE is_active = 1 ORDER BY display_order ASC"
    ).all();

    // Add cache control headers to ensure fresh data
    c.header('Cache-Control', 'no-cache, no-store, must-revalidate');
    c.header('Pragma', 'no-cache');
    c.header('Expires', '0');

    return c.json(result.results);
  } catch (error) {
    console.error("Error fetching pomade types:", error);
    return c.json({ error: "Erro ao buscar tipos de pomada" }, 500);
  }
});

app.post("/api/pomade-types", async (c) => {
  try {
    const data = await c.req.json();

    await c.env.DB.prepare(
      `INSERT INTO pomade_types (id, name, icon, display_order)
       VALUES (?, ?, ?, ?)`
    ).bind(
      data.id,
      data.name,
      data.icon,
      data.display_order || 0
    ).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error creating pomade type:", error);
    return c.json({ error: "Erro ao criar tipo de pomada" }, 500);
  }
});

app.patch("/api/pomade-types/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const data = await c.req.json();

    await c.env.DB.prepare(
      `UPDATE pomade_types 
       SET name = ?, icon = ?, image = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(data.name, data.icon, data.image || null, id).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error updating pomade type:", error);
    return c.json({ error: "Erro ao atualizar tipo de pomada" }, 500);
  }
});

app.delete("/api/pomade-types/:id", async (c) => {
  try {
    const id = c.req.param("id");

    await c.env.DB.prepare(
      "UPDATE pomade_types SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    ).bind(id).run();

    return c.json({ success: true });
  } catch (error) {
    console.error("Error deleting pomade type:", error);
    return c.json({ error: "Erro ao deletar tipo de pomada" }, 500);
  }
});

// Send 45-minute reminders for upcoming appointments
app.post("/api/appointments/send-45min-reminders", async (c) => {
  try {
    // Convert to Brazil time (UTC-3)
    const nowUTC = new Date();
    const now = new Date(nowUTC.getTime() - 3 * 60 * 60 * 1000);
    const in45Minutes = new Date(now.getTime() + 45 * 60 * 1000);
    
    const todayDate = now.toISOString().split('T')[0];

    // Get appointments starting in approximately 45 minutes (within a 5-minute window)
    const startTime = new Date(in45Minutes.getTime() - 2.5 * 60 * 1000);
    const endTime = new Date(in45Minutes.getTime() + 2.5 * 60 * 1000);
    
    const startHour = startTime.getHours();
    const startMinute = startTime.getMinutes();
    const startTimeStr = `${startHour.toString().padStart(2, '0')}:${startMinute.toString().padStart(2, '0')}`;
    
    const endHour = endTime.getHours();
    const endMinute = endTime.getMinutes();
    const endTimeStr = `${endHour.toString().padStart(2, '0')}:${endMinute.toString().padStart(2, '0')}`;

    const appointments = await c.env.DB.prepare(
      `SELECT * FROM appointments 
       WHERE appointment_date = ? 
       AND appointment_time >= ? 
       AND appointment_time <= ?
       AND status = 'confirmed'
       ORDER BY appointment_time ASC`
    )
      .bind(todayDate, startTimeStr, endTimeStr)
      .all<Appointment>();

    let sent = 0;
    let failed = 0;

    // Get barber email and phone from settings
    const barberEmailSetting = await c.env.DB.prepare(
      "SELECT value FROM settings WHERE key = 'barber_email'"
    ).first<{ value: string }>();
    const barberEmail = barberEmailSetting?.value;

    const barberWhatsAppSetting = await c.env.DB.prepare(
      "SELECT value FROM settings WHERE key = 'whatsapp'"
    ).first<{ value: string }>();
    const barberWhatsApp = barberWhatsAppSetting?.value;

    for (const appointment of appointments.results) {
      try {
        // ALWAYS send 45-minute reminder - to customer AND barber
        await send45MinuteReminderEmail(c.env.RESEND_API_KEY, {
          customer_name: appointment.customer_name,
          customer_email: appointment.customer_email,
          customer_phone: appointment.customer_phone,
          service_name: appointment.service_name,
          appointment_date: appointment.appointment_date,
          appointment_time: appointment.appointment_time
        }, barberEmail);

        // Send notification to barber via WhatsApp
        if (barberWhatsApp) {
          try {
            await sendBarberWhatsAppReminder(
              c.env.TWILIO_ACCOUNT_SID,
              c.env.TWILIO_AUTH_TOKEN,
              c.env.TWILIO_WHATSAPP_NUMBER,
              barberWhatsApp,
              {
                id: appointment.id,
                customer_name: appointment.customer_name,
                customer_phone: appointment.customer_phone,
                service_name: appointment.service_name,
                appointment_date: appointment.appointment_date,
                appointment_time: appointment.appointment_time
              }
            );
            console.log('✅ Barber reminder WhatsApp sent');
          } catch (error) {
            console.error('Failed to send barber reminder WhatsApp:', error);
          }
        }

        sent++;
      } catch (error) {
        console.error(`Failed to send 45-min reminder to ${appointment.customer_email}:`, error);
        failed++;
      }
    }

    return c.json({
      message: "Lembretes de 45 minutos enviados",
      window: `${startTimeStr} - ${endTimeStr}`,
      total: appointments.results.length,
      sent,
      failed
    });
  } catch (error) {
    console.error("Error sending 45-minute reminders:", error);
    return c.json({ error: "Erro ao enviar lembretes" }, 500);
  }
});

// Quick action endpoints (confirm via link) - simplified without tokens
app.get("/api/appointments/:id/confirm", async (c) => {
  try {
    const id = c.req.param("id");

    // Get appointment
    const appointment = await c.env.DB.prepare(
      "SELECT * FROM appointments WHERE id = ?"
    ).bind(id).first<Appointment>();

    if (!appointment) {
      return c.html(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Erro</title>
          <style>
            body { font-family: system-ui; text-align: center; padding: 40px; background: #f5f5f5; }
            .box { background: white; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .icon { font-size: 48px; margin-bottom: 16px; }
            h1 { color: #333; font-size: 24px; margin: 0 0 12px; }
            p { color: #666; margin: 0; }
          </style>
        </head>
        <body>
          <div class="box">
            <div class="icon">❌</div>
            <h1>Agendamento não encontrado</h1>
            <p>José Barbearia</p>
          </div>
        </body>
        </html>
      `, 404);
    }

    if (appointment.status === 'confirmed') {
      return c.html(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Já Confirmado</title>
          <style>
            body { font-family: system-ui; text-align: center; padding: 40px; background: #f5f5f5; }
            .box { background: white; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .icon { font-size: 48px; margin-bottom: 16px; }
            h1 { color: #333; font-size: 24px; margin: 0 0 12px; }
            p { color: #666; margin: 0; }
          </style>
        </head>
        <body>
          <div class="box">
            <div class="icon">✅</div>
            <h1>Este agendamento já está confirmado</h1>
            <p>José Barbearia</p>
          </div>
        </body>
        </html>
      `);
    }

    if (appointment.status === 'cancelled') {
      return c.html(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Cancelado</title>
          <style>
            body { font-family: system-ui; text-align: center; padding: 40px; background: #f5f5f5; }
            .box { background: white; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .icon { font-size: 48px; margin-bottom: 16px; }
            h1 { color: #333; font-size: 24px; margin: 0 0 12px; }
            p { color: #666; margin: 0; }
          </style>
        </head>
        <body>
          <div class="box">
            <div class="icon">❌</div>
            <h1>Este agendamento foi cancelado</h1>
            <p>José Barbearia</p>
          </div>
        </body>
        </html>
      `, 400);
    }

    // Update appointment to confirmed
    await c.env.DB.prepare(
      "UPDATE appointments SET status = 'confirmed', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    ).bind(id).run();

    // Get the base URL
    const requestUrl = new URL(c.req.url);
    const baseUrl = requestUrl.hostname.includes('mocha.app') 
      ? requestUrl.origin 
      : 'https://e4id45fo46lti.mocha.app';

    // Send confirmation to customer
    try {
      await sendWhatsAppConfirmation(
        c.env.TWILIO_ACCOUNT_SID,
        c.env.TWILIO_AUTH_TOKEN,
        c.env.TWILIO_WHATSAPP_NUMBER,
        {
          id: appointment.id,
          customer_name: appointment.customer_name,
          customer_phone: appointment.customer_phone,
          service_name: appointment.service_name,
          appointment_date: appointment.appointment_date,
          appointment_time: appointment.appointment_time
        },
        baseUrl
      );
    } catch (error) {
      console.error('Failed to send confirmation to customer:', error);
    }

    return c.html(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Confirmado!</title>
        <style>
          body { font-family: system-ui; text-align: center; padding: 40px; background: #f5f5f5; }
          .box { background: white; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .icon { font-size: 48px; margin-bottom: 16px; }
          h1 { color: #333; font-size: 24px; margin: 0 0 12px; }
          p { color: #666; margin: 0 0 8px; }
          .success { background: #dcfce7; padding: 12px; border-radius: 8px; margin-top: 16px; }
          .success p { color: #166534; margin: 0; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="box">
          <div class="icon">✅</div>
          <h1>Agendamento Confirmado!</h1>
          <p>Confirmação enviada para ${appointment.customer_name}</p>
          <div class="success">
            <p>✓ Cliente notificado via WhatsApp</p>
          </div>
          <p style="margin-top: 24px; font-size: 14px;">José Barbearia</p>
        </div>
      </body>
      </html>
    `);
  } catch (error) {
    console.error("Error in quick confirm:", error);
    return c.html(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Erro</title>
        <style>
          body { font-family: system-ui; text-align: center; padding: 40px; background: #f5f5f5; }
          .box { background: white; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .icon { font-size: 48px; margin-bottom: 16px; }
          h1 { color: #333; font-size: 24px; margin: 0 0 12px; }
          p { color: #666; margin: 0; }
        </style>
      </head>
      <body>
        <div class="box">
          <div class="icon">❌</div>
          <h1>Erro ao confirmar agendamento</h1>
          <p>José Barbearia</p>
        </div>
      </body>
      </html>
    `, 500);
  }
});

app.get("/api/appointments/:id/cancel", async (c) => {
  try {
    const id = c.req.param("id");

    // Get appointment
    const appointment = await c.env.DB.prepare(
      "SELECT * FROM appointments WHERE id = ?"
    ).bind(id).first<Appointment>();

    if (!appointment) {
      return c.html(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Erro</title>
          <style>
            body { font-family: system-ui; text-align: center; padding: 40px; background: #f5f5f5; }
            .box { background: white; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .icon { font-size: 48px; margin-bottom: 16px; }
            h1 { color: #333; font-size: 24px; margin: 0 0 12px; }
            p { color: #666; margin: 0; }
          </style>
        </head>
        <body>
          <div class="box">
            <div class="icon">❌</div>
            <h1>Agendamento não encontrado</h1>
            <p>José Barbearia</p>
          </div>
        </body>
        </html>
      `, 404);
    }

    if (appointment.status === 'cancelled') {
      return c.html(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Já Cancelado</title>
          <style>
            body { font-family: system-ui; text-align: center; padding: 40px; background: #f5f5f5; }
            .box { background: white; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .icon { font-size: 48px; margin-bottom: 16px; }
            h1 { color: #333; font-size: 24px; margin: 0 0 12px; }
            p { color: #666; margin: 0; }
          </style>
        </head>
        <body>
          <div class="box">
            <div class="icon">❌</div>
            <h1>Este agendamento já está cancelado</h1>
            <p>José Barbearia</p>
          </div>
        </body>
        </html>
      `);
    }

    // Update appointment to cancelled
    await c.env.DB.prepare(
      "UPDATE appointments SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP WHERE id = ?"
    ).bind(id).run();

    // Send cancellation to customer
    try {
      await sendWhatsAppCancellation(
        c.env.TWILIO_ACCOUNT_SID,
        c.env.TWILIO_AUTH_TOKEN,
        c.env.TWILIO_WHATSAPP_NUMBER,
        {
          customer_name: appointment.customer_name,
          customer_phone: appointment.customer_phone,
          service_name: appointment.service_name,
          appointment_date: appointment.appointment_date,
          appointment_time: appointment.appointment_time
        }
      );
    } catch (error) {
      console.error('Failed to send cancellation to customer:', error);
    }

    return c.html(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cancelado!</title>
        <style>
          body { font-family: system-ui; text-align: center; padding: 40px; background: #f5f5f5; }
          .box { background: white; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .icon { font-size: 48px; margin-bottom: 16px; }
          h1 { color: #333; font-size: 24px; margin: 0 0 12px; }
          p { color: #666; margin: 0 0 8px; }
          .info { background: #fee2e2; padding: 12px; border-radius: 8px; margin-top: 16px; }
          .info p { color: #991b1b; margin: 0; font-size: 14px; }
        </style>
      </head>
      <body>
        <div class="box">
          <div class="icon">❌</div>
          <h1>Agendamento Cancelado</h1>
          <p>Notificação enviada para ${appointment.customer_name}</p>
          <div class="info">
            <p>✓ Cliente notificado via WhatsApp</p>
          </div>
          <p style="margin-top: 24px; font-size: 14px;">José Barbearia</p>
        </div>
      </body>
      </html>
    `);
  } catch (error) {
    console.error("Error in quick cancel:", error);
    return c.html(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Erro</title>
        <style>
          body { font-family: system-ui; text-align: center; padding: 40px; background: #f5f5f5; }
          .box { background: white; padding: 30px; border-radius: 12px; max-width: 400px; margin: 0 auto; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
          .icon { font-size: 48px; margin-bottom: 16px; }
          h1 { color: #333; font-size: 24px; margin: 0 0 12px; }
          p { color: #666; margin: 0; }
        </style>
      </head>
      <body>
        <div class="box">
          <div class="icon">❌</div>
          <h1>Erro ao cancelar agendamento</h1>
          <p>José Barbearia</p>
        </div>
      </body>
      </html>
    `, 500);
  }
});

// Endpoint to keep WhatsApp Sandbox active (can be called by external cron)
app.get('/api/keep-alive', async (c) => {
  try {
    console.log('🤖 Keep-alive ping triggered at:', new Date().toISOString());
    
    // Get barber WhatsApp from settings
    const db = c.env.DB;
    const barberWhatsAppSetting = await db.prepare(
      "SELECT value FROM settings WHERE key = 'whatsapp'"
    ).first<{ value: string }>();
    
    const barberWhatsApp = barberWhatsAppSetting?.value;
    
    if (!barberWhatsApp) {
      console.warn('⚠️ No barber WhatsApp found, skipping auto-ping');
      return c.json({ success: false, error: 'No WhatsApp configured' }, 400);
    }
    
    // Ensure phone number is in E.164 format
    let toNumber = barberWhatsApp.replace(/\D/g, '');
    if (!toNumber.startsWith('55')) {
      toNumber = '55' + toNumber;
    }
    toNumber = '+' + toNumber;
    
    const message = `🤖 *Sistema Ativo - José Barbearia*

Esta é uma mensagem automática para manter o sistema WhatsApp ativo.

✅ Tudo funcionando perfeitamente!

_Mensagem enviada automaticamente a cada 2 dias_`;
    
    const auth = btoa(`${c.env.TWILIO_ACCOUNT_SID}:${c.env.TWILIO_AUTH_TOKEN}`);
    
    const response = await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${c.env.TWILIO_ACCOUNT_SID}/Messages.json`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          From: `whatsapp:${c.env.TWILIO_WHATSAPP_NUMBER}`,
          To: `whatsapp:${toNumber}`,
          Body: message,
        }),
      }
    );
    
    if (!response.ok) {
      const error = await response.text();
      console.error('❌ Auto-ping failed:', error);
      return c.json({ success: false, error }, 500);
    }
    
    const result = await response.json() as { sid: string };
    console.log('✅ Auto-ping sent successfully! SID:', result.sid);
    return c.json({ success: true, sid: result.sid });
  } catch (error) {
    console.error('❌ Error in keep-alive ping:', error);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Serve React app for all non-API routes (SPA fallback)
app.get('*', async (c) => {
  // This will be handled by Vite/Cloudflare to serve the React app
  return c.notFound();
});

export default app;
