export interface Appointment {
  id: number;
  service_id: string;
  service_name: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  appointment_date: string;
  appointment_time: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  payment_method: string | null;
  payment_status: string | null;
  created_at: string;
  updated_at: string;
}

export interface CreateAppointmentRequest {
  service_id: string;
  service_name: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  appointment_date: string;
  appointment_time: string;
}
