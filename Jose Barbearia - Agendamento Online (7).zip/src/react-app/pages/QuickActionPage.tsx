import { useEffect, useState } from 'react';
import { useParams } from 'react-router';
import { CheckCircle, XCircle, Loader2 } from 'lucide-react';

export default function QuickActionPage() {
  const { id, action } = useParams<{ id: string; action: string }>();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [message, setMessage] = useState('');

  useEffect(() => {
    const performAction = async () => {
      try {
        const response = await fetch(`/api/appointments/${id}/${action}`, {
          method: 'GET',
          credentials: 'include',
        });

        const data = await response.json();

        if (response.ok) {
          setStatus('success');
          setMessage(data.message);
        } else {
          setStatus('error');
          setMessage(data.error || 'Erro ao processar ação');
        }
      } catch (error) {
        setStatus('error');
        setMessage('Erro ao conectar com o servidor');
      }
    };

    performAction();
  }, [id, action]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
        {status === 'loading' && (
          <>
            <Loader2 className="w-16 h-16 text-amber-600 mx-auto mb-4 animate-spin" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">
              Processando...
            </h1>
            <p className="text-gray-600">
              Aguarde um momento
            </p>
          </>
        )}

        {status === 'success' && (
          <>
            <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">
              {action === 'confirm' ? '✅ Agendamento Confirmado!' : '❌ Agendamento Cancelado'}
            </h1>
            <p className="text-gray-600 whitespace-pre-line">
              {message}
            </p>
            <div className="mt-4 p-4 bg-green-50 rounded-lg">
              <p className="text-sm text-green-800">
                {action === 'confirm' 
                  ? '✓ O cliente foi notificado automaticamente via WhatsApp'
                  : '✓ O cliente foi notificado sobre o cancelamento via WhatsApp'
                }
              </p>
            </div>
          </>
        )}

        {status === 'error' && (
          <>
            <XCircle className="w-16 h-16 text-red-600 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-800 mb-2">
              Erro
            </h1>
            <p className="text-gray-600">
              {message}
            </p>
          </>
        )}

        <div className="mt-6 pt-6 border-t border-gray-200">
          <p className="text-sm text-gray-500">
            José Barbearia
          </p>
        </div>
      </div>
    </div>
  );
}
