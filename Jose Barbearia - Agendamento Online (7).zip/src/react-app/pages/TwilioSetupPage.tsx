import { ArrowRight, Check, ExternalLink } from 'lucide-react';

export default function TwilioSetupPage() {
  const webhookUrl = `${window.location.origin}/api/webhooks/whatsapp`;

  const copyWebhookUrl = () => {
    navigator.clipboard.writeText(webhookUrl);
    alert('URL copiada! Cole no campo "When a message comes in" do Twilio');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Configuração do WhatsApp Twilio
          </h1>
          <p className="text-lg text-gray-600">
            Siga este guia passo a passo para conectar seu WhatsApp
          </p>
        </div>

        {/* Step 1 */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
              1
            </div>
            <h2 className="text-2xl font-bold text-gray-900">
              Acesse o Console do Twilio
            </h2>
          </div>
          <div className="ml-16">
            <p className="text-gray-700 mb-4">
              Abra o console do Twilio e vá para a seção de WhatsApp:
            </p>
            <a
              href="https://console.twilio.com/us1/develop/sms/try-it-out/whatsapp-learn"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-purple-600 text-white px-6 py-3 rounded-lg hover:bg-purple-700 transition-colors"
            >
              Abrir Console Twilio
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Step 2 */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
              2
            </div>
            <h2 className="text-2xl font-bold text-gray-900">
              Configure o Sandbox
            </h2>
          </div>
          <div className="ml-16 space-y-4">
            <div className="flex items-start gap-3">
              <Check className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
              <p className="text-gray-700">
                No seu WhatsApp, envie uma mensagem com o código fornecido para o número do Twilio (geralmente algo como "join [código]")
              </p>
            </div>
            <div className="flex items-start gap-3">
              <Check className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
              <p className="text-gray-700">
                Aguarde a confirmação de que você foi adicionado ao sandbox
              </p>
            </div>
          </div>
        </div>

        {/* Step 3 */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
              3
            </div>
            <h2 className="text-2xl font-bold text-gray-900">
              Configure o Webhook
            </h2>
          </div>
          <div className="ml-16 space-y-4">
            <p className="text-gray-700">
              Na página do Sandbox, procure a seção <strong>"When a message comes in"</strong>
            </p>
            
            <div className="bg-purple-50 border-2 border-purple-200 rounded-lg p-4">
              <p className="text-sm font-semibold text-purple-900 mb-2">
                URL do Webhook:
              </p>
              <div className="flex items-center gap-2">
                <code className="flex-1 bg-white px-4 py-3 rounded border border-purple-300 font-mono text-sm text-gray-800 break-all">
                  {webhookUrl}
                </code>
                <button
                  onClick={copyWebhookUrl}
                  className="px-4 py-3 bg-purple-600 text-white rounded hover:bg-purple-700 transition-colors whitespace-nowrap"
                >
                  Copiar
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-start gap-3">
                <ArrowRight className="w-5 h-5 text-purple-600 mt-1 flex-shrink-0" />
                <p className="text-gray-700">
                  Cole esta URL no campo <strong>"When a message comes in"</strong>
                </p>
              </div>
              <div className="flex items-start gap-3">
                <ArrowRight className="w-5 h-5 text-purple-600 mt-1 flex-shrink-0" />
                <p className="text-gray-700">
                  Certifique-se de que o método está configurado como <strong>HTTP POST</strong>
                </p>
              </div>
              <div className="flex items-start gap-3">
                <ArrowRight className="w-5 h-5 text-purple-600 mt-1 flex-shrink-0" />
                <p className="text-gray-700">
                  Clique em <strong>Save</strong> para salvar as configurações
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Step 4 */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
              4
            </div>
            <h2 className="text-2xl font-bold text-gray-900">
              Teste a Configuração
            </h2>
          </div>
          <div className="ml-16 space-y-4">
            <p className="text-gray-700">
              Envie uma mensagem de teste para o número do Twilio e verifique se:
            </p>
            <div className="space-y-2">
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                <p className="text-gray-700">
                  O webhook recebe a mensagem corretamente
                </p>
              </div>
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                <p className="text-gray-700">
                  Você recebe uma resposta automática
                </p>
              </div>
              <div className="flex items-start gap-3">
                <Check className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                <p className="text-gray-700">
                  Os agendamentos são confirmados quando você responde "confirmar"
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Troubleshooting */}
        <div className="bg-yellow-50 border-2 border-yellow-200 rounded-2xl p-8">
          <h3 className="text-xl font-bold text-gray-900 mb-4">
            ⚠️ Problemas Comuns
          </h3>
          <div className="space-y-3">
            <div>
              <p className="font-semibold text-gray-900">Mensagens não chegam:</p>
              <p className="text-gray-700">Verifique se copiou a URL completa e se está usando HTTP POST</p>
            </div>
            <div>
              <p className="font-semibold text-gray-900">Erro ao enviar mensagem:</p>
              <p className="text-gray-700">Confirme que suas credenciais Twilio (SID e Token) estão corretas em Settings → Secrets</p>
            </div>
            <div>
              <p className="font-semibold text-gray-900">Webhook não responde:</p>
              <p className="text-gray-700">Verifique os logs do Twilio para ver se há erros na requisição</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <a
            href="/admin"
            className="inline-flex items-center gap-2 text-purple-600 hover:text-purple-700 font-medium"
          >
            Voltar para Admin
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>
    </div>
  );
}
