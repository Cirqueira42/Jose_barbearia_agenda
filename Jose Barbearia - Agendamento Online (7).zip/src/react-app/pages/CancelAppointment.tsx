import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router';
import { Calendar, Clock, User, CheckCircle2, XCircle } from 'lucide-react';

export default function CancelAppointment() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [cancelled, setCancelled] = useState(false);
  const [error, setError] = useState('');
  const [appointment, setAppointment] = useState<any>(null);

  const token = searchParams.get('token');
  const date = searchParams.get('date');
  const time = searchParams.get('time');

  useEffect(() => {
    if (!token || !date || !time) {
      setError('Link inválido. Verifique o email e tente novamente.');
      return;
    }

    // Fetch appointment details
    fetchAppointment();
  }, [token, date, time]);

  async function fetchAppointment() {
    try {
      const response = await fetch(`/api/appointments?date=${date}`);
      const appointments = await response.json();
      
      const found = appointments.find((apt: any) => 
        apt.customer_email === decodeURIComponent(token!) && 
        apt.appointment_date === date && 
        apt.appointment_time === time &&
        apt.status !== 'cancelled'
      );

      if (found) {
        setAppointment(found);
      } else {
        setError('Agendamento não encontrado ou já foi cancelado.');
      }
    } catch (err) {
      setError('Erro ao carregar agendamento. Tente novamente mais tarde.');
    }
  }

  async function handleCancel() {
    if (!appointment) return;

    setLoading(true);
    setError('');

    try {
      const response = await fetch(`/api/appointments/${appointment.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'cancelled' })
      });

      if (!response.ok) {
        throw new Error('Erro ao cancelar agendamento');
      }

      setCancelled(true);
    } catch (err) {
      setError('Erro ao cancelar agendamento. Tente novamente ou entre em contato conosco.');
    } finally {
      setLoading(false);
    }
  }

  if (cancelled) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-10 h-10 text-green-400" />
          </div>
          
          <h1 className="text-2xl font-bold text-white mb-4">
            Agendamento Cancelado
          </h1>
          
          <p className="text-gray-300 mb-6">
            Seu agendamento foi cancelado com sucesso. Esperamos vê-lo em breve!
          </p>

          <div className="space-y-3 text-sm text-gray-400 bg-slate-800/50 p-4 rounded-lg mb-6">
            <p>📞 WhatsApp: (16) 99736-9740</p>
            <p>📱 Instagram: @josebarbeariaa</p>
          </div>
          
          <button
            onClick={() => navigate('/')}
            className="w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold py-3 px-6 rounded-lg transition"
          >
            Voltar ao Início
          </button>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 max-w-md w-full text-center">
          <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <XCircle className="w-10 h-10 text-red-400" />
          </div>
          
          <h1 className="text-2xl font-bold text-white mb-4">
            Erro
          </h1>
          
          <p className="text-gray-300 mb-6">
            {error}
          </p>

          <div className="space-y-3 text-sm text-gray-400 bg-slate-800/50 p-4 rounded-lg mb-6">
            <p>Entre em contato conosco:</p>
            <p>📞 WhatsApp: (16) 99736-9740</p>
            <p>📱 Instagram: @josebarbeariaa</p>
          </div>
          
          <button
            onClick={() => navigate('/')}
            className="w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold py-3 px-6 rounded-lg transition"
          >
            Voltar ao Início
          </button>
        </div>
      </div>
    );
  }

  if (!appointment) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900 flex items-center justify-center p-4">
        <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 max-w-md w-full text-center">
          <div className="animate-spin w-12 h-12 border-4 border-amber-600 border-t-transparent rounded-full mx-auto"></div>
          <p className="text-white mt-4">Carregando...</p>
        </div>
      </div>
    );
  }

  const formattedDate = new Date(appointment.appointment_date).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900 flex items-center justify-center p-4">
      <div className="bg-white/10 backdrop-blur-xl border border-white/20 rounded-2xl p-8 max-w-md w-full">
        <h1 className="text-2xl font-bold text-white mb-2 text-center">
          Cancelar Agendamento
        </h1>
        <p className="text-gray-400 text-center mb-6">
          Tem certeza que deseja cancelar?
        </p>

        <div className="bg-slate-800/50 rounded-xl p-6 mb-6 space-y-4">
          <div className="flex items-center gap-3 text-white">
            <User className="w-5 h-5 text-amber-500" />
            <div>
              <p className="text-sm text-gray-400">Cliente</p>
              <p className="font-semibold">{appointment.customer_name}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-white">
            <Calendar className="w-5 h-5 text-amber-500" />
            <div>
              <p className="text-sm text-gray-400">Serviço</p>
              <p className="font-semibold">{appointment.service_name}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-white">
            <Calendar className="w-5 h-5 text-amber-500" />
            <div>
              <p className="text-sm text-gray-400">Data</p>
              <p className="font-semibold">{formattedDate}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 text-white">
            <Clock className="w-5 h-5 text-amber-500" />
            <div>
              <p className="text-sm text-gray-400">Horário</p>
              <p className="font-semibold">{appointment.appointment_time}</p>
            </div>
          </div>
        </div>

        <div className="space-y-3 text-sm text-gray-400 bg-slate-800/50 p-4 rounded-lg mb-6">
          <p className="text-center text-white font-semibold mb-2">Precisa reagendar?</p>
          <p>📞 WhatsApp: (16) 99736-9740</p>
          <p>📱 Instagram: @josebarbeariaa</p>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => navigate('/')}
            className="flex-1 bg-slate-700 hover:bg-slate-600 text-white font-semibold py-3 px-6 rounded-lg transition"
          >
            Voltar
          </button>
          <button
            onClick={handleCancel}
            disabled={loading}
            className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-6 rounded-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Cancelando...' : 'Confirmar Cancelamento'}
          </button>
        </div>
      </div>
    </div>
  );
}
