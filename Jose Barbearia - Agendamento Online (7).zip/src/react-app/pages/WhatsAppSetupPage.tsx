import { useState } from 'react';
import { MessageSquare, CheckCircle, AlertCircle, ExternalLink, Copy, Check } from 'lucide-react';
import { Link } from 'react-router';

export function WhatsAppSetupPage() {
  const [copied, setCopied] = useState(false);
  const [testPhone, setTestPhone] = useState('');
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');
  const [testMessage, setTestMessage] = useState('');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTest = async () => {
    if (!testPhone) {
      setTestMessage('Digite um número de telefone');
      setTestStatus('error');
      return;
    }

    setTestStatus('testing');
    try {
      const response = await fetch('/api/test-whatsapp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: testPhone })
      });

      const data = await response.json();

      if (data.success) {
        setTestStatus('success');
        setTestMessage('✅ Mensagem enviada com sucesso! Verifique o WhatsApp.');
      } else {
        setTestStatus('error');
        setTestMessage(`❌ Erro: ${data.error || 'Falha ao enviar'}`);
      }
    } catch (error) {
      setTestStatus('error');
      setTestMessage('❌ Erro ao enviar teste');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700 bg-slate-900/50 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <MessageSquare className="h-6 w-6 text-green-400" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Configuração WhatsApp</h1>
                <p className="text-sm text-slate-400">Guia completo para ativar notificações</p>
              </div>
            </div>
            <Link
              to="/admin"
              className="px-4 py-2 rounded-lg bg-slate-700 text-white hover:bg-slate-600 transition-colors"
            >
              Voltar
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Status Card */}
        <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-2xl p-6 mb-8">
          <div className="flex items-start gap-4">
            <AlertCircle className="h-6 w-6 text-amber-400 flex-shrink-0 mt-1" />
            <div>
              <h3 className="text-lg font-bold text-white mb-2">
                ⚠️ Configuração Necessária
              </h3>
              <p className="text-slate-300 mb-4">
                O código está correto e funcionando! O problema é a configuração do Twilio Sandbox.
                Siga os passos abaixo para ativar o WhatsApp.
              </p>
            </div>
          </div>
        </div>

        {/* Step-by-step Guide */}
        <div className="space-y-6">
          {/* Step 1 */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white font-bold">
                1
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-3">
                  Acesse o Twilio Console
                </h3>
                <p className="text-slate-300 mb-4">
                  Abra o painel do Twilio WhatsApp Sandbox:
                </p>
                <a
                  href="https://console.twilio.com/us1/develop/sms/try-it-out/whatsapp-learn"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors"
                >
                  <ExternalLink className="h-4 w-4" />
                  Abrir Twilio Console
                </a>
              </div>
            </div>
          </div>

          {/* Step 2 */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white font-bold">
                2
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-3">
                  Copie o código "join"
                </h3>
                <p className="text-slate-300 mb-4">
                  Na página do Twilio, você verá algo como:
                </p>
                <div className="bg-slate-900 border border-slate-600 rounded-lg p-4 mb-4">
                  <code className="text-green-400">join abc-xyz</code>
                </div>
                <p className="text-slate-400 text-sm">
                  O código muda para cada conta. Copie o código exato que aparece na sua tela.
                </p>
              </div>
            </div>
          </div>

          {/* Step 3 */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white font-bold">
                3
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-3">
                  Envie a mensagem no WhatsApp
                </h3>
                <p className="text-slate-300 mb-4">
                  No seu WhatsApp, envie a mensagem "join abc-xyz" para o número que aparece na tela do Twilio
                  (geralmente <span className="text-green-400 font-mono">+1 (415) 523-8886</span>)
                </p>
                <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                  <p className="text-blue-300 text-sm">
                    💡 <strong>Dica:</strong> Use o link abaixo para abrir direto no WhatsApp:
                  </p>
                  <a
                    href="https://wa.me/14155238886"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 mt-2 px-4 py-2 rounded-lg bg-green-500 text-white hover:bg-green-600 transition-colors"
                  >
                    <MessageSquare className="h-4 w-4" />
                    Abrir WhatsApp
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Step 4 */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white font-bold">
                4
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-3">
                  Aguarde a confirmação
                </h3>
                <p className="text-slate-300 mb-4">
                  O Twilio responderá confirmando que você entrou no sandbox. Você verá uma mensagem como:
                </p>
                <div className="bg-slate-900 border border-green-500/20 rounded-lg p-4">
                  <p className="text-green-400 text-sm">
                    "✅ You are all set! The Sandbox is ready to use."
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Step 5 */}
          <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white font-bold">
                5
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-3">
                  Configure o número do Twilio
                </h3>
                <p className="text-slate-300 mb-4">
                  No Mocha, vá em <strong>Settings → Secrets</strong> e configure:
                </p>
                <div className="bg-slate-900 border border-slate-600 rounded-lg p-4 space-y-2">
                  <div className="flex items-center justify-between">
                    <code className="text-sm text-slate-300">TWILIO_WHATSAPP_NUMBER</code>
                    <button
                      onClick={() => copyToClipboard('+14155238886')}
                      className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600 transition-colors"
                    >
                      {copied ? <Check className="h-4 w-4 text-green-400" /> : <Copy className="h-4 w-4 text-slate-400" />}
                    </button>
                  </div>
                  <div className="text-green-400 font-mono">+14155238886</div>
                </div>
                <p className="text-slate-400 text-sm mt-2">
                  ⚠️ <strong>Importante:</strong> O número deve começar com + e ter o código do país (ex: +1...)
                </p>
              </div>
            </div>
          </div>

          {/* Test Section */}
          <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/20 rounded-2xl p-6">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-500 flex items-center justify-center text-white font-bold">
                6
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-white mb-3">
                  Teste o sistema
                </h3>
                <p className="text-slate-300 mb-4">
                  Digite seu número de WhatsApp para receber uma mensagem de teste:
                </p>
                <div className="space-y-4">
                  <div>
                    <input
                      type="tel"
                      placeholder="(16) 99999-9999"
                      value={testPhone}
                      onChange={(e) => setTestPhone(e.target.value)}
                      className="w-full px-4 py-3 rounded-lg bg-slate-900 border border-slate-600 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-green-500"
                    />
                  </div>
                  <button
                    onClick={handleTest}
                    disabled={testStatus === 'testing'}
                    className="w-full px-6 py-3 rounded-lg bg-green-500 text-white font-semibold hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {testStatus === 'testing' ? 'Enviando...' : 'Enviar Teste'}
                  </button>
                  {testMessage && (
                    <div className={`p-4 rounded-lg ${
                      testStatus === 'success' 
                        ? 'bg-green-500/10 border border-green-500/20' 
                        : 'bg-red-500/10 border border-red-500/20'
                    }`}>
                      <p className={testStatus === 'success' ? 'text-green-400' : 'text-red-400'}>
                        {testMessage}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Important Notes */}
        <div className="mt-8 bg-slate-800/50 border border-slate-700 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-amber-400" />
            Informações Importantes
          </h3>
          <ul className="space-y-3 text-slate-300">
            <li className="flex gap-3">
              <span className="text-green-400">•</span>
              <span>
                <strong>Sandbox é gratuito</strong> mas só funciona para números que enviaram "join"
              </span>
            </li>
            <li className="flex gap-3">
              <span className="text-green-400">•</span>
              <span>
                Cada pessoa que quiser receber mensagens precisa enviar "join" para o número do Twilio
              </span>
            </li>
            <li className="flex gap-3">
              <span className="text-green-400">•</span>
              <span>
                Para uso ilimitado (sem precisar de "join"), você precisa de um número WhatsApp Business 
                (pago, requer aprovação do WhatsApp)
              </span>
            </li>
            <li className="flex gap-3">
              <span className="text-green-400">•</span>
              <span>
                O sandbox expira após 3 dias de inatividade. O sistema envia pings automáticos a cada 2 dias 
                para manter ativo.
              </span>
            </li>
          </ul>
        </div>

        {/* What happens after setup */}
        <div className="mt-8 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border border-blue-500/20 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-blue-400" />
            O que acontece depois da configuração?
          </h3>
          <div className="space-y-3 text-slate-300">
            <div className="flex gap-3">
              <span className="text-blue-400">✓</span>
              <span>
                Quando um cliente faz um agendamento, ele <strong>automaticamente</strong> recebe uma confirmação no WhatsApp
              </span>
            </div>
            <div className="flex gap-3">
              <span className="text-blue-400">✓</span>
              <span>
                Você (barbeiro) recebe uma notificação com os dados do cliente e links rápidos para confirmar/cancelar
              </span>
            </div>
            <div className="flex gap-3">
              <span className="text-blue-400">✓</span>
              <span>
                Quando você marca um agendamento como "concluído", o cliente recebe uma mensagem de agradecimento
              </span>
            </div>
            <div className="flex gap-3">
              <span className="text-blue-400">✓</span>
              <span>
                Tudo automático! Você não precisa fazer nada além de configurar uma vez
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
