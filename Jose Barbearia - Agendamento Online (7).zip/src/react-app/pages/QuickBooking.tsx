import { useState, useEffect } from 'react';
import { Scissors, Sparkles, ShoppingBag, MapPin, MessageCircle, Loader2 } from 'lucide-react';
import { businessInfo } from '../../data/services';
import { barbershopPhotos } from '../../data/pomades';
import { ServiceCard } from '../components/ServiceCard';
import { BookingModal } from '../components/BookingModal';
import type { Service } from '../../data/services';

interface BusinessSettings {
  whatsapp: string;
  business_name: string;
}

interface PomadeType {
  id: string;
  name: string;
  icon: string;
  image?: string;
  display_order: number;
}

export function QuickBooking() {
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [businessSettings, setBusinessSettings] = useState<BusinessSettings | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [pomades, setPomades] = useState<PomadeType[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    setIsLoading(true);
    try {
      // Add timestamp to prevent caching
      const timestamp = new Date().getTime();
      
      // Load all data in parallel
      const [settingsRes, servicesRes, pomadesRes] = await Promise.all([
        fetch(`/api/settings?t=${timestamp}`, {
          headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate' }
        }),
        fetch(`/api/services-config?t=${timestamp}`, {
          headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate' }
        }),
        fetch(`/api/pomade-types?t=${timestamp}`, {
          headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate' }
        })
      ]);

      if (settingsRes.ok) {
        const settings = await settingsRes.json();
        setBusinessSettings(settings);
      }

      if (servicesRes.ok) {
        const servicesData = await servicesRes.json();
        // Transform API data to match Service interface
        const transformedServices = servicesData.map((s: any) => ({
          id: s.id,
          name: s.name,
          description: s.description || '',
          price: parseFloat(s.price) || 0,
          duration: parseInt(s.duration) || 30,
          icon: s.icon || 'Scissors',
          image: s.image || ''
        }));
        setServices(transformedServices);
      }

      if (pomadesRes.ok) {
        const pomadesData = await pomadesRes.json();
        setPomades(pomadesData);
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const whatsappMessage = businessSettings
    ? `Olá! Gostaria de agendar um horário na ${businessSettings.business_name}.\n\nLink do agendamento: ${window.location.origin}/agendar`
    : '';
  const whatsappUrl = businessSettings
    ? `https://wa.me/${businessSettings.whatsapp}?text=${encodeURIComponent(whatsappMessage)}`
    : '';

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-amber-500 mx-auto mb-4" />
          <p className="text-slate-400">Carregando informações atualizadas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* WhatsApp Floating Button */}
      {businessSettings && (
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="fixed bottom-6 left-6 z-40 flex items-center gap-2 rounded-full bg-gradient-to-r from-green-500 to-green-600 px-5 py-3 font-semibold text-white shadow-xl shadow-green-500/25 transition-all hover:shadow-2xl hover:shadow-green-500/40"
          title="Agendar pelo WhatsApp"
        >
          <MessageCircle className="h-5 w-5" />
          WhatsApp
        </a>
      )}

      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-amber-500/10 p-2">
                <Scissors className="h-5 w-5 text-amber-500" />
              </div>
              <div>
                <h1 className="font-bold text-white">{businessInfo.name}</h1>
                <p className="text-xs text-slate-400">Agendamento Rápido</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Booking Section */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        {/* Welcome Banner */}
        <div className="mb-10 rounded-3xl border border-amber-500/30 bg-gradient-to-br from-amber-500/10 via-amber-600/5 to-transparent p-8 backdrop-blur-sm">
          <div className="text-center">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-amber-500/20 px-6 py-2">
              <span className="text-2xl">🔥</span>
              <span className="font-bold text-amber-400">Agendamento Online</span>
            </div>
            <h2 className="mb-3 text-3xl font-bold text-white md:text-4xl">
              Agende seu horário na Jose Barbearia!
            </h2>
            <p className="mx-auto max-w-2xl text-lg text-slate-300">
              ✨ Escolha o melhor horário para você de forma rápida e prática
            </p>
          </div>
        </div>

        <div className="mb-12 text-center">
          <div className="mb-4 inline-flex rounded-2xl bg-amber-500/10 p-4 backdrop-blur-sm">
            <Sparkles className="h-8 w-8 text-amber-500" />
          </div>
          <h3 className="mb-3 text-2xl font-bold text-white">Nossos Serviços</h3>
          <p className="mx-auto max-w-2xl text-slate-400">
            Selecione o serviço desejado e reserve seu horário
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {services.map((service) => (
            <ServiceCard
              key={service.id}
              service={service}
              onSelect={setSelectedService}
            />
          ))}
        </div>

        {/* Barbershop Photos */}
        <div className="mt-12">
          <h3 className="mb-6 text-center text-2xl font-bold text-white">Conheça Nossa Barbearia</h3>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="group relative overflow-hidden rounded-2xl border border-slate-700 bg-slate-800/50">
              <div className="absolute left-4 top-4 z-10 flex items-center gap-2 rounded-full bg-black/50 px-3 py-1.5 backdrop-blur-sm">
                <MapPin className="h-4 w-4 text-amber-500" />
                <span className="text-sm font-medium text-white">Fachada</span>
              </div>
              <img
                src={barbershopPhotos.facade}
                alt="Fachada da José Barbearia"
                className="h-64 w-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
            </div>
            
            <div className="group relative overflow-hidden rounded-2xl border border-slate-700 bg-slate-800/50">
              <div className="absolute left-4 top-4 z-10 flex items-center gap-2 rounded-full bg-black/50 px-3 py-1.5 backdrop-blur-sm">
                <Scissors className="h-4 w-4 text-amber-500" />
                <span className="text-sm font-medium text-white">Interior</span>
              </div>
              <img
                src={barbershopPhotos.interior}
                alt="Interior da José Barbearia"
                className="h-64 w-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent" />
            </div>
          </div>
        </div>

        {/* Pomades Section */}
        <div className="mt-12 rounded-2xl border border-amber-500/20 bg-gradient-to-br from-amber-900/20 via-slate-900/50 to-slate-900/50 p-6 backdrop-blur-sm">
          <div className="mb-6 flex items-center gap-3">
            <div className="rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 p-3">
              <ShoppingBag className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">Pomadas Modeladoras</h3>
              <p className="text-sm text-slate-400">Produtos profissionais para seu cabelo</p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {pomades.map((pomade) => {
              const pomadeMessage = businessSettings
                ? `Olá! Gostaria de comprar a pomada *${pomade.name}* da ${businessSettings.business_name}.`
                : '';
              const pomadeWhatsAppUrl = businessSettings
                ? `https://wa.me/${businessSettings.whatsapp}?text=${encodeURIComponent(pomadeMessage)}`
                : '';

              return (
                <div
                  key={pomade.id}
                  className="group relative overflow-hidden rounded-xl border border-slate-700 bg-gradient-to-br from-slate-800/80 to-slate-800/40 transition-all hover:border-amber-500/50 hover:shadow-lg hover:shadow-amber-500/10"
                >
                  {pomade.image ? (
                    <div className="relative h-40 overflow-hidden">
                      <img
                        src={pomade.image}
                        alt={pomade.name}
                        className="h-full w-full object-cover transition-transform group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent" />
                    </div>
                  ) : (
                    <div className="flex h-40 items-center justify-center">
                      <div className="text-6xl opacity-20 transition-opacity group-hover:opacity-40">
                        {pomade.icon}
                      </div>
                    </div>
                  )}
                  <div className="p-4">
                    <p className="mb-1 text-xs font-medium text-amber-400">Disponível</p>
                    <p className="text-base font-semibold text-white">{pomade.name}</p>
                    {businessSettings && (
                      <a
                        href={pomadeWhatsAppUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="mt-3 flex items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-green-500 to-green-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-green-500/20 transition-all hover:shadow-xl hover:shadow-green-500/30"
                      >
                        <MessageCircle className="h-4 w-4" />
                        Comprar pelo WhatsApp
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Info Box */}
        <div className="mt-12 rounded-2xl border border-amber-500/20 bg-gradient-to-br from-amber-500/5 to-transparent p-6">
          <h3 className="mb-3 text-lg font-semibold text-white">Como funciona?</h3>
          <ol className="space-y-2 text-slate-300">
            <li className="flex items-start gap-3">
              <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-sm font-bold text-amber-500">
                1
              </span>
              <span>Escolha o serviço que deseja</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-sm font-bold text-amber-500">
                2
              </span>
              <span>Selecione a data e horário disponível</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-sm font-bold text-amber-500">
                3
              </span>
              <span>Preencha seus dados e confirme</span>
            </li>
            <li className="flex items-start gap-3">
              <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-amber-500/20 text-sm font-bold text-amber-500">
                4
              </span>
              <span>Receba a confirmação por e-mail</span>
            </li>
          </ol>
        </div>
      </div>

      {/* Booking Modal */}
      {selectedService && (
        <BookingModal
          service={selectedService}
          onClose={() => setSelectedService(null)}
        />
      )}
    </div>
  );
}
