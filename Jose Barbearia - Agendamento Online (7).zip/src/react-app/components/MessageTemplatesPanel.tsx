import { useState, useEffect } from 'react';
import { Send, Mail, Copy, Check, Phone } from 'lucide-react';
import { messageTemplates, MessageTemplate } from '../../data/messageTemplates';

interface MessageTemplatesPanelProps {
  appointments?: any[];
}

export function MessageTemplatesPanel({ appointments = [] }: MessageTemplatesPanelProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<MessageTemplate | null>(null);
  const [selectedRecipient, setSelectedRecipient] = useState<string>('');
  const [customVariables, setCustomVariables] = useState<Record<string, string>>({});
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = {
    welcome: 'Boas-vindas',
    reminder: 'Lembretes',
    confirmation: 'Confirmação',
    thankyou: 'Agradecimento',
    followup: 'Follow-up',
    promotional: 'Promocional',
  };

  const groupedTemplates = messageTemplates.reduce((acc, template) => {
    if (!acc[template.category]) {
      acc[template.category] = [];
    }
    acc[template.category].push(template);
    return acc;
  }, {} as Record<string, MessageTemplate[]>);

  // Auto-fill variables when a recipient is selected
  useEffect(() => {
    if (selectedRecipient) {
      const appointment = appointments.find(apt => 
        (apt.customer_email && apt.customer_email === selectedRecipient) ||
        (apt.customer_phone && apt.customer_phone === selectedRecipient)
      );
      if (appointment) {
        const date = new Date(appointment.appointment_date);
        const formattedDate = date.toLocaleDateString('pt-BR', {
          day: '2-digit',
          month: 'long',
          year: 'numeric',
        });

        const cancelUrl = `${window.location.origin}/action/cancel/${appointment.id}`;

        setCustomVariables({
          customer_name: appointment.customer_name,
          appointment_date: formattedDate,
          appointment_time: appointment.appointment_time,
          service_name: appointment.service_name,
          cancel_url: cancelUrl,
        });
      }
    } else {
      setCustomVariables({});
    }
  }, [selectedRecipient, appointments]);

  const handleCopyMessage = (template: MessageTemplate) => {
    let message = template.message;
    
    // Replace variables with values or placeholders
    template.variables.forEach(variable => {
      const value = customVariables[variable] || `[${variable}]`;
      message = message.replace(new RegExp(`{{${variable}}}`, 'g'), value);
    });

    navigator.clipboard.writeText(message);
    setCopiedId(template.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSendMessage = async (template: MessageTemplate) => {
    if (!selectedRecipient) {
      alert('Selecione um cliente para enviar a mensagem');
      return;
    }

    // This would integrate with your email service
    alert(`Mensagem "${template.name}" enviada para ${selectedRecipient}`);
  };

  const handleShareWhatsApp = (template: MessageTemplate) => {
    let message = template.message;
    
    // Replace variables with values or placeholders
    template.variables.forEach(variable => {
      const value = customVariables[variable] || `[${variable}]`;
      message = message.replace(new RegExp(`{{${variable}}}`, 'g'), value);
    });

    // Open WhatsApp with the message
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const previewMessage = (template: MessageTemplate) => {
    let message = template.message;
    
    template.variables.forEach(variable => {
      const value = customVariables[variable] || `{{${variable}}}`;
      message = message.replace(new RegExp(`{{${variable}}}`, 'g'), value);
    });

    return message;
  };

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-700/50 bg-gradient-to-br from-slate-900 to-slate-800 p-6">
        <div className="mb-6 flex items-center gap-3">
          <div className="rounded-xl bg-amber-500/10 p-3">
            <Mail className="h-6 w-6 text-amber-500" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-white">Mensagens Automáticas</h2>
            <p className="text-sm text-slate-400">
              Modelos prontos para diferentes situações
            </p>
          </div>
        </div>

        {/* Recipient Selection */}
        <div className="mb-6">
          <label className="mb-2 block text-sm font-medium text-slate-300">
            Enviar para (opcional):
          </label>
          <select
            value={selectedRecipient}
            onChange={(e) => setSelectedRecipient(e.target.value)}
            className="w-full rounded-xl bg-slate-800/50 px-4 py-3 text-white outline-none ring-2 ring-slate-700 transition-all focus:ring-amber-500"
          >
            <option value="">Selecione um cliente...</option>
            {appointments.map((apt) => {
              const identifier = apt.customer_email || apt.customer_phone || String(apt.id);
              const displayInfo = apt.customer_email 
                ? `(${apt.customer_email})` 
                : apt.customer_phone 
                ? `(${apt.customer_phone})`
                : `(ID: ${apt.id})`;
              
              return (
                <option key={apt.id} value={identifier}>
                  {apt.customer_name} {displayInfo}
                </option>
              );
            })}
          </select>
        </div>

        {/* Template Categories */}
        <div className="space-y-6">
          {Object.entries(groupedTemplates).map(([category, templates]) => (
            <div key={category}>
              <h3 className="mb-3 text-sm font-semibold uppercase tracking-wider text-slate-400">
                {categories[category as keyof typeof categories]}
              </h3>
              <div className="space-y-3">
                {templates.map((template) => (
                  <div
                    key={template.id}
                    className="group rounded-xl border border-slate-700/50 bg-slate-800/30 p-4 transition-all hover:border-amber-500/30"
                  >
                    <div className="mb-2 flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-white">{template.name}</h4>
                        <p className="text-sm text-amber-500">{template.subject}</p>
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleShareWhatsApp(template)}
                          className="rounded-lg bg-green-600 p-2 text-white transition-all hover:bg-green-700"
                          title="Compartilhar no WhatsApp"
                        >
                          <Phone className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleCopyMessage(template)}
                          className="rounded-lg bg-slate-700/50 p-2 text-slate-300 transition-all hover:bg-slate-700 hover:text-white"
                          title="Copiar mensagem"
                        >
                          {copiedId === template.id ? (
                            <Check className="h-4 w-4 text-green-500" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </button>
                        <button
                          onClick={() => setSelectedTemplate(
                            selectedTemplate?.id === template.id ? null : template
                          )}
                          className="rounded-lg bg-amber-500/10 px-3 py-2 text-sm font-medium text-amber-500 transition-all hover:bg-amber-500/20"
                        >
                          {selectedTemplate?.id === template.id ? 'Fechar' : 'Ver'}
                        </button>
                      </div>
                    </div>

                    {/* Preview */}
                    {selectedTemplate?.id === template.id && (
                      <div className="mt-4 space-y-4 border-t border-slate-700/50 pt-4">
                        {/* Variables */}
                        {template.variables.length > 0 && (
                          <div className="space-y-2">
                            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                              Variáveis:
                            </p>
                            <div className="grid gap-2 sm:grid-cols-2">
                              {template.variables.map((variable) => (
                                <input
                                  key={variable}
                                  type="text"
                                  placeholder={variable}
                                  value={customVariables[variable] || ''}
                                  onChange={(e) =>
                                    setCustomVariables({
                                      ...customVariables,
                                      [variable]: e.target.value,
                                    })
                                  }
                                  className="rounded-lg bg-slate-800/50 px-3 py-2 text-sm text-white placeholder-slate-500 outline-none ring-1 ring-slate-700 transition-all focus:ring-amber-500"
                                />
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Message Preview */}
                        <div>
                          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
                            Preview:
                          </p>
                          <div className="whitespace-pre-wrap rounded-lg bg-slate-900/50 p-4 text-sm text-slate-300">
                            {previewMessage(template)}
                          </div>
                        </div>

                        {/* Send Button */}
                        <button
                          onClick={() => handleSendMessage(template)}
                          disabled={!selectedRecipient}
                          className="flex w-full items-center justify-center gap-2 rounded-lg bg-amber-500 px-4 py-2 font-semibold text-white transition-all hover:bg-amber-600 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          <Send className="h-4 w-4" />
                          Enviar Mensagem
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Info Box */}
      <div className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-4">
        <p className="text-sm text-blue-300">
          💡 <strong>Dica:</strong> Você pode copiar qualquer mensagem e enviá-la manualmente via
          WhatsApp, ou selecionar um cliente e enviar por e-mail diretamente pelo sistema.
        </p>
      </div>
    </div>
  );
}
