import { WifiOff, RefreshCw, Bell, BellOff } from 'lucide-react';
import { useOfflineSync } from '../hooks/useOfflineSync';
import { usePushNotifications } from '../hooks/usePushNotifications';

export function OfflineStatus() {
  const { isOnline, pendingCount, isSyncing, triggerSync } = useOfflineSync();
  const { permission, isSupported, isSubscribed, subscribe, unsubscribe } = usePushNotifications();

  const handleEnableNotifications = async () => {
    if (isSubscribed) {
      await unsubscribe();
    } else {
      await subscribe();
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-40 flex flex-col gap-2">
      {/* Offline/Online Status */}
      {!isOnline && (
        <div className="animate-in slide-in-from-bottom rounded-xl bg-gradient-to-r from-orange-500 to-red-500 px-4 py-3 shadow-2xl shadow-red-500/20">
          <div className="flex items-center gap-3">
            <WifiOff className="h-5 w-5 text-white" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">Modo Offline</p>
              <p className="text-xs text-orange-50">
                {pendingCount > 0 
                  ? `${pendingCount} agendamento(s) aguardando sincronização`
                  : 'Você pode continuar agendando'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Syncing Status */}
      {isOnline && pendingCount > 0 && (
        <div className="animate-in slide-in-from-bottom rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 px-4 py-3 shadow-2xl shadow-blue-500/20">
          <div className="flex items-center gap-3">
            <RefreshCw className={`h-5 w-5 text-white ${isSyncing ? 'animate-spin' : ''}`} />
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">
                {isSyncing ? 'Sincronizando...' : 'Pronto para sincronizar'}
              </p>
              <p className="text-xs text-blue-50">
                {pendingCount} agendamento(s) pendente(s)
              </p>
            </div>
            {!isSyncing && (
              <button
                onClick={triggerSync}
                className="rounded-lg bg-white/20 px-3 py-1 text-xs font-semibold text-white transition-colors hover:bg-white/30"
              >
                Sincronizar
              </button>
            )}
          </div>
        </div>
      )}

      {/* Push Notifications Toggle */}
      {isSupported && (
        <div className="rounded-xl bg-gradient-to-r from-slate-800 to-slate-900 px-4 py-3 shadow-2xl shadow-slate-900/20 border border-slate-700">
          <div className="flex items-center gap-3">
            {isSubscribed ? (
              <Bell className="h-5 w-5 text-green-400" />
            ) : (
              <BellOff className="h-5 w-5 text-slate-400" />
            )}
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">
                Notificações Push
              </p>
              <p className="text-xs text-slate-400">
                {permission === 'granted' 
                  ? (isSubscribed ? 'Ativadas' : 'Disponíveis')
                  : permission === 'denied'
                  ? 'Bloqueadas pelo navegador'
                  : 'Não ativadas'}
              </p>
            </div>
            {permission !== 'denied' && (
              <button
                onClick={handleEnableNotifications}
                className={`rounded-lg px-3 py-1 text-xs font-semibold transition-colors ${
                  isSubscribed
                    ? 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    : 'bg-green-500 text-white hover:bg-green-600'
                }`}
              >
                {isSubscribed ? 'Desativar' : 'Ativar'}
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
