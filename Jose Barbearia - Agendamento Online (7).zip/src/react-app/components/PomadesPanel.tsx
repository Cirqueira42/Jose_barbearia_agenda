import { useState, useEffect } from 'react';
import { ShoppingBag, Plus, TrendingUp, DollarSign, Sparkles, MessageCircle } from 'lucide-react';

interface Sale {
  id: number;
  customer_name: string;
  customer_phone: string;
  pomade_type: string;
  quantity: number;
  total_price: number;
  payment_method: string;
  sale_date: string;
  created_at: string;
}

interface SalesStats {
  total_sales: number;
  total_revenue: number;
  units_sold: number;
  today_sales: number;
}

interface PomadeType {
  id: string;
  name: string;
  icon: string;
  image?: string;
}

interface BusinessInfo {
  whatsapp: string;
}

export function PomadesPanel() {
  const [showForm, setShowForm] = useState(false);
  const [pomadeTypes, setPomadeTypes] = useState<PomadeType[]>([]);
  const [pomadePrice, setPomadePrice] = useState(17.99);
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo | null>(null);
  const [stats, setStats] = useState<SalesStats>({
    total_sales: 0,
    total_revenue: 0,
    units_sold: 0,
    today_sales: 0,
  });
  const [recentSales, setRecentSales] = useState<Sale[]>([]);
  const [formData, setFormData] = useState({
    customer_name: '',
    customer_phone: '',
    pomade_type: 'cera_extra_forte',
    quantity: 1,
    payment_method: 'dinheiro',
  });

  useEffect(() => {
    loadData();
    loadStats();
    loadRecentSales();
  }, []);

  const loadData = async () => {
    try {
      const [pomadeTypesRes, settingsRes] = await Promise.all([
        fetch('/api/pomade-types'),
        fetch('/api/settings'),
      ]);

      if (pomadeTypesRes.ok) {
        const data = await pomadeTypesRes.json();
        setPomadeTypes(data);
      }

      if (settingsRes.ok) {
        const data = await settingsRes.json();
        if (data.pomade_price) {
          setPomadePrice(parseFloat(data.pomade_price));
        }
        setBusinessInfo(data);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    }
  };

  const loadStats = async () => {
    try {
      const response = await fetch('/api/pomades/stats');
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error);
    }
  };

  const loadRecentSales = async () => {
    try {
      const response = await fetch('/api/pomades/sales?limit=5');
      if (response.ok) {
        const data = await response.json();
        setRecentSales(data.sales || []);
      }
    } catch (error) {
      console.error('Erro ao carregar vendas:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const saleData = {
      ...formData,
      total_price: formData.quantity * pomadePrice,
      sale_date: new Date().toISOString().split('T')[0],
    };

    try {
      const response = await fetch('/api/pomades/sales', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(saleData),
      });

      if (response.ok) {
        setFormData({
          customer_name: '',
          customer_phone: '',
          pomade_type: 'cera_extra_forte',
          quantity: 1,
          payment_method: 'dinheiro',
        });
        setShowForm(false);
        loadStats();
        loadRecentSales();
      }
    } catch (error) {
      console.error('Erro ao registrar venda:', error);
    }
  };

  const getPomadeTypeName = (typeId: string) => {
    return pomadeTypes.find(t => t.id === typeId)?.name || typeId;
  };

  const getPomadeTypeIcon = (typeId: string) => {
    return pomadeTypes.find(t => t.id === typeId)?.icon || '💈';
  };

  return (
    <div className="rounded-2xl border border-amber-500/20 bg-gradient-to-br from-amber-900/20 via-slate-900/50 to-slate-900/50 p-6 backdrop-blur-sm">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 p-3">
            <ShoppingBag className="h-6 w-6 text-white" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Pomadas Modeladoras</h3>
            <p className="text-sm text-slate-400">R$ {pomadePrice.toFixed(2)} por unidade</p>
          </div>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center justify-center gap-2 rounded-lg bg-amber-500 px-4 py-2 font-semibold text-white transition-all hover:bg-amber-600"
        >
          <Plus className="h-4 w-4" />
          Nova Venda
        </button>
      </div>

      {/* Pomade Types Grid */}
      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {pomadeTypes.map((type) => {
          const whatsappMessage = `Olá! Gostaria de comprar *${type.name}* - R$ ${pomadePrice.toFixed(2)}`;
          const whatsappUrl = businessInfo 
            ? `https://wa.me/${businessInfo.whatsapp}?text=${encodeURIComponent(whatsappMessage)}`
            : '#';

          return (
            <div
              key={type.id}
              className="group relative overflow-hidden rounded-xl border border-slate-700 bg-gradient-to-br from-slate-800/80 to-slate-800/40 transition-all hover:border-amber-500/50 hover:shadow-lg hover:shadow-amber-500/10"
            >
              {type.image ? (
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={type.image}
                    alt={type.name}
                    className="h-full w-full object-contain p-4 transition-transform group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/30 to-transparent" />
                </div>
              ) : (
                <div className="flex h-48 items-center justify-center">
                  <div className="text-6xl opacity-20 transition-opacity group-hover:opacity-40">
                    {type.icon}
                  </div>
                </div>
              )}
              <div className="p-5">
                <p className="mb-1 text-xs font-medium uppercase tracking-wide text-amber-400">
                  Disponível
                </p>
                <p className="mb-2 text-base font-semibold text-white">{type.name}</p>
                <p className="mb-4 text-2xl font-bold text-amber-500">
                  R$ {pomadePrice.toFixed(2)}
                </p>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-green-500 to-green-600 px-4 py-2.5 font-semibold text-white shadow-lg shadow-green-500/20 transition-all hover:scale-105 hover:shadow-xl hover:shadow-green-500/30"
                >
                  <MessageCircle className="h-4 w-4" />
                  Comprar via WhatsApp
                </a>
              </div>
            </div>
          );
        })}
      </div>

      {/* Stats Grid */}
      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
          <div className="mb-2 flex items-center gap-2 text-amber-500">
            <DollarSign className="h-4 w-4" />
            <span className="text-xs font-medium">Faturamento Total</span>
          </div>
          <p className="text-2xl font-bold text-white">
            R$ {stats.total_revenue.toFixed(2)}
          </p>
        </div>

        <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
          <div className="mb-2 flex items-center gap-2 text-blue-500">
            <ShoppingBag className="h-4 w-4" />
            <span className="text-xs font-medium">Unidades Vendidas</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats.units_sold}</p>
        </div>

        <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
          <div className="mb-2 flex items-center gap-2 text-green-500">
            <TrendingUp className="h-4 w-4" />
            <span className="text-xs font-medium">Total de Vendas</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats.total_sales}</p>
        </div>

        <div className="rounded-xl border border-slate-700 bg-slate-800/50 p-4">
          <div className="mb-2 flex items-center gap-2 text-purple-500">
            <Sparkles className="h-4 w-4" />
            <span className="text-xs font-medium">Vendas Hoje</span>
          </div>
          <p className="text-2xl font-bold text-white">{stats.today_sales}</p>
        </div>
      </div>

      {/* Sales Form */}
      {showForm && (
        <form onSubmit={handleSubmit} className="mb-6 rounded-xl border border-slate-700 bg-slate-800/50 p-6">
          <h4 className="mb-4 text-lg font-semibold text-white">Registrar Nova Venda</h4>
          
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">
                Nome do Cliente
              </label>
              <input
                type="text"
                required
                value={formData.customer_name}
                onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white placeholder-slate-400 focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                placeholder="Nome completo"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">
                Telefone (opcional)
              </label>
              <input
                type="tel"
                value={formData.customer_phone}
                onChange={(e) => setFormData({ ...formData, customer_phone: e.target.value })}
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white placeholder-slate-400 focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                placeholder="(00) 00000-0000"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">
                Tipo de Pomada
              </label>
              <select
                value={formData.pomade_type}
                onChange={(e) => setFormData({ ...formData, pomade_type: e.target.value })}
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
              >
                {pomadeTypes.map((type) => (
                  <option key={type.id} value={type.id}>
                    {type.icon} {type.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">
                Quantidade
              </label>
              <input
                type="number"
                min="1"
                required
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 1 })}
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
              />
            </div>

            <div className="md:col-span-2">
              <label className="mb-2 block text-sm font-medium text-slate-300">
                Forma de Pagamento
              </label>
              <select
                value={formData.payment_method}
                onChange={(e) => setFormData({ ...formData, payment_method: e.target.value })}
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white focus:border-amber-500 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
              >
                <option value="dinheiro">Dinheiro</option>
                <option value="pix">PIX</option>
                <option value="cartao_debito">Cartão de Débito</option>
                <option value="cartao_credito">Cartão de Crédito</option>
              </select>
            </div>
          </div>

          <div className="mt-4 rounded-lg bg-gradient-to-br from-amber-500/20 to-amber-600/10 p-4 backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-300">
                  {formData.quantity}x {getPomadeTypeName(formData.pomade_type)}
                </p>
                <p className="text-xs text-slate-400">
                  R$ {pomadePrice.toFixed(2)} cada
                </p>
              </div>
              <p className="text-2xl font-bold text-amber-400">
                R$ {(formData.quantity * pomadePrice).toFixed(2)}
              </p>
            </div>
          </div>

          <div className="mt-6 flex gap-3">
            <button
              type="submit"
              className="flex-1 rounded-lg bg-amber-500 px-6 py-2 font-semibold text-white transition-all hover:bg-amber-600"
            >
              Registrar Venda
            </button>
            <button
              type="button"
              onClick={() => setShowForm(false)}
              className="rounded-lg border border-slate-600 bg-slate-700 px-6 py-2 font-semibold text-white transition-all hover:bg-slate-600"
            >
              Cancelar
            </button>
          </div>
        </form>
      )}

      {/* Recent Sales */}
      {recentSales.length > 0 && (
        <div>
          <h4 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">
            Vendas Recentes
          </h4>
          <div className="space-y-3">
            {recentSales.map((sale) => (
              <div
                key={sale.id}
                className="flex items-center justify-between rounded-lg border border-slate-700 bg-slate-800/30 p-4"
              >
                <div className="flex items-start gap-3">
                  <div className="text-2xl">{getPomadeTypeIcon(sale.pomade_type)}</div>
                  <div>
                    <p className="font-medium text-white">{sale.customer_name}</p>
                    <p className="text-sm text-slate-400">
                      {sale.quantity}x {getPomadeTypeName(sale.pomade_type)}
                    </p>
                    <p className="text-xs text-slate-500">
                      {sale.payment_method.replace('_', ' ')}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-amber-400">
                    R$ {sale.total_price.toFixed(2)}
                  </p>
                  <p className="text-xs text-slate-500">
                    {new Date(sale.sale_date).toLocaleDateString('pt-BR')}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
