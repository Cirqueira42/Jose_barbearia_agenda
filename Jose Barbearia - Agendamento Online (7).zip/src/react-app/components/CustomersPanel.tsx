import { useMemo, useState } from 'react';
import { User, Phone, Mail, Calendar, TrendingUp, Search } from 'lucide-react';
import type { Appointment } from '../../shared/types';

interface CustomersPanelProps {
  appointments: Appointment[];
}

interface CustomerStats {
  name: string;
  phone: string;
  email: string;
  totalAppointments: number;
  thisMonthAppointments: number;
  lastAppointmentDate: string;
  firstAppointmentDate: string;
}

export function CustomersPanel({ appointments }: CustomersPanelProps) {
  const [searchTerm, setSearchTerm] = useState('');

  const customerStats = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    // Group appointments by customer phone
    const customerMap = new Map<string, CustomerStats>();

    appointments.forEach((appointment) => {
      const phone = appointment.customer_phone;
      const appointmentDate = new Date(appointment.appointment_date + 'T00:00:00');

      if (!customerMap.has(phone)) {
        customerMap.set(phone, {
          name: appointment.customer_name,
          phone: appointment.customer_phone,
          email: appointment.customer_email || '',
          totalAppointments: 0,
          thisMonthAppointments: 0,
          lastAppointmentDate: appointment.appointment_date,
          firstAppointmentDate: appointment.appointment_date,
        });
      }

      const customer = customerMap.get(phone)!;
      customer.totalAppointments++;

      // Count appointments in current month
      if (
        appointmentDate.getMonth() === currentMonth &&
        appointmentDate.getFullYear() === currentYear
      ) {
        customer.thisMonthAppointments++;
      }

      // Update last appointment date
      if (appointment.appointment_date > customer.lastAppointmentDate) {
        customer.lastAppointmentDate = appointment.appointment_date;
      }

      // Update first appointment date
      if (appointment.appointment_date < customer.firstAppointmentDate) {
        customer.firstAppointmentDate = appointment.appointment_date;
      }

      // Always use the most recent customer info (name, email)
      customer.name = appointment.customer_name;
      if (appointment.customer_email) {
        customer.email = appointment.customer_email;
      }
    });

    // Convert to array and sort by total appointments (descending)
    return Array.from(customerMap.values()).sort(
      (a, b) => b.totalAppointments - a.totalAppointments
    );
  }, [appointments]);

  const filteredCustomers = useMemo(() => {
    if (!searchTerm) return customerStats;

    const search = searchTerm.toLowerCase();
    return customerStats.filter(
      (customer) =>
        customer.name.toLowerCase().includes(search) ||
        customer.phone.includes(search) ||
        customer.email.toLowerCase().includes(search)
    );
  }, [customerStats, searchTerm]);

  const stats = {
    totalCustomers: customerStats.length,
    activeThisMonth: customerStats.filter((c) => c.thisMonthAppointments > 0).length,
    averageAppointmentsPerCustomer:
      customerStats.length > 0
        ? (customerStats.reduce((sum, c) => sum + c.totalAppointments, 0) / customerStats.length).toFixed(1)
        : 0,
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr + 'T00:00:00');
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-400">Total de Clientes</p>
              <p className="mt-1 text-3xl font-bold text-white">{stats.totalCustomers}</p>
            </div>
            <div className="rounded-xl bg-amber-500/10 p-3">
              <User className="h-6 w-6 text-amber-500" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-green-500/20 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-green-400">Ativos Este Mês</p>
              <p className="mt-1 text-3xl font-bold text-white">{stats.activeThisMonth}</p>
            </div>
            <div className="rounded-xl bg-green-500/10 p-3">
              <TrendingUp className="h-6 w-6 text-green-500" />
            </div>
          </div>
        </div>

        <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-blue-500/20 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-400">Média de Visitas</p>
              <p className="mt-1 text-3xl font-bold text-white">{stats.averageAppointmentsPerCustomer}</p>
            </div>
            <div className="rounded-xl bg-blue-500/10 p-3">
              <Calendar className="h-6 w-6 text-blue-500" />
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 p-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar por nome, telefone ou email..."
            className="w-full rounded-xl bg-slate-800/50 py-3 pl-12 pr-4 text-white outline-none ring-2 ring-slate-700 transition-all placeholder:text-slate-500 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* Customers List */}
      <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700/50 overflow-hidden">
        <div className="p-6 border-b border-slate-700/50">
          <h2 className="text-lg font-semibold text-white">
            Todos os Clientes ({filteredCustomers.length})
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-700/50 bg-slate-800/30">
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">
                  Cliente
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">
                  Contato
                </th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-300">
                  Total
                </th>
                <th className="px-6 py-4 text-center text-sm font-semibold text-slate-300">
                  Este Mês
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">
                  Última Visita
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">
                  Cliente Desde
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/30">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-400">
                    {searchTerm ? 'Nenhum cliente encontrado' : 'Nenhum cliente cadastrado ainda'}
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((customer) => (
                  <tr
                    key={customer.phone}
                    className="transition-colors hover:bg-slate-800/30"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-500/10 text-amber-500">
                          <User className="h-5 w-5" />
                        </div>
                        <div>
                          <p className="font-medium text-white">{customer.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 text-sm text-slate-300">
                          <Phone className="h-4 w-4 text-slate-500" />
                          {customer.phone}
                        </div>
                        {customer.email && (
                          <div className="flex items-center gap-2 text-sm text-slate-400">
                            <Mail className="h-4 w-4 text-slate-500" />
                            {customer.email}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className="inline-flex items-center justify-center rounded-full bg-slate-700/50 px-3 py-1 text-sm font-semibold text-white">
                        {customer.totalAppointments}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span
                        className={`inline-flex items-center justify-center rounded-full px-3 py-1 text-sm font-semibold ${
                          customer.thisMonthAppointments > 0
                            ? 'bg-green-500/10 text-green-400'
                            : 'bg-slate-700/50 text-slate-400'
                        }`}
                      >
                        {customer.thisMonthAppointments}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-slate-300">{formatDate(customer.lastAppointmentDate)}</p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-sm text-slate-400">{formatDate(customer.firstAppointmentDate)}</p>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
