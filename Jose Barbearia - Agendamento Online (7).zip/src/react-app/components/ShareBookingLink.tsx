import { useState } from 'react';
import { Copy, Check, Share2, MessageCircle } from 'lucide-react';

export function ShareBookingLink() {
  const [copied, setCopied] = useState(false);
  const bookingUrl = `${window.location.origin}/agendar`;

  const handleCopy = () => {
    navigator.clipboard.writeText(bookingUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleWhatsAppShare = () => {
    const message = `🔥 Agende seu horário na Jose Barbearia!\n\n✨ Acesse o link e escolha o melhor horário para você:\n${bookingUrl}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-6 backdrop-blur-sm">
      <div className="mb-4 flex items-center gap-3">
        <div className="rounded-xl bg-amber-500/10 p-3">
          <Share2 className="h-5 w-5 text-amber-500" />
        </div>
        <div>
          <h3 className="font-semibold text-white">Link de Agendamento Rápido</h3>
          <p className="text-sm text-slate-400">Compartilhe com seus clientes</p>
        </div>
      </div>

      <div className="mb-4 flex items-center gap-2 rounded-xl bg-slate-800/50 p-3">
        <input
          type="text"
          value={bookingUrl}
          readOnly
          className="flex-1 bg-transparent text-sm text-slate-300 outline-none"
        />
        <button
          onClick={handleCopy}
          className="rounded-lg bg-slate-700 p-2 transition-colors hover:bg-slate-600"
          title="Copiar link"
        >
          {copied ? (
            <Check className="h-4 w-4 text-green-500" />
          ) : (
            <Copy className="h-4 w-4 text-slate-300" />
          )}
        </button>
      </div>

      <div className="flex gap-3">
        <button
          onClick={handleCopy}
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-slate-800 px-4 py-3 font-medium text-white transition-all hover:bg-slate-700"
        >
          <Copy className="h-4 w-4" />
          Copiar Link
        </button>
        <button
          onClick={handleWhatsAppShare}
          className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-green-600 px-4 py-3 font-medium text-white transition-all hover:bg-green-700"
        >
          <MessageCircle className="h-4 w-4" />
          Compartilhar
        </button>
      </div>

      <div className="mt-4 rounded-lg bg-blue-500/5 border border-blue-500/20 p-3">
        <p className="text-xs text-blue-300">
          💡 <strong>Dica:</strong> Adicione este link na bio do Instagram, no status do WhatsApp
          ou envie diretamente para seus clientes
        </p>
      </div>
    </div>
  );
}
