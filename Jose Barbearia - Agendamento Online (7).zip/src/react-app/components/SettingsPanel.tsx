import { useState, useEffect } from 'react';
import { Settings, Clock, DollarSign, Package, Save, Loader2, CheckCircle, XCircle, Image, Trash2, Plus } from 'lucide-react';

interface SettingsData {
  business_name: string;
  barber_name: string;
  business_address: string;
  instagram: string;
  instagram_url: string;
  whatsapp: string;
  pomade_price: string;
  [key: string]: string;
}

interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: number;
  icon: string;
  image: string;
}

interface PomadeType {
  id: string;
  name: string;
  icon: string;
  image?: string;
}

interface GalleryPhoto {
  id: number;
  url: string;
  alt: string;
}

const DAYS = [
  { key: 'monday', label: 'Segunda-feira' },
  { key: 'tuesday', label: 'Terça-feira' },
  { key: 'wednesday', label: 'Quarta-feira' },
  { key: 'thursday', label: 'Quinta-feira' },
  { key: 'friday', label: 'Sexta-feira' },
  { key: 'saturday', label: 'Sábado' },
  { key: 'sunday', label: 'Domingo' },
];

export function SettingsPanel() {
  const [activeTab, setActiveTab] = useState<'business' | 'hours' | 'services' | 'pomades' | 'photos'>('business');
  const [settings, setSettings] = useState<SettingsData | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [pomadeTypes, setPomadeTypes] = useState<PomadeType[]>([]);
  const [galleryPhotos, setGalleryPhotos] = useState<GalleryPhoto[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [editingPomade, setEditingPomade] = useState<PomadeType | null>(null);
  const [editingPhoto, setEditingPhoto] = useState<GalleryPhoto | null>(null);
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [newPhotoAlt, setNewPhotoAlt] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [settingsRes, servicesRes, pomadesRes, photosRes] = await Promise.all([
        fetch('/api/settings'),
        fetch('/api/services-config'),
        fetch('/api/pomade-types'),
        fetch('/api/gallery-photos'),
      ]);

      if (settingsRes.ok) {
        const data = await settingsRes.json();
        setSettings(data);
      }

      if (servicesRes.ok) {
        const data = await servicesRes.json();
        setServices(data);
      }

      if (pomadesRes.ok) {
        const data = await pomadesRes.json();
        setPomadeTypes(data);
      }

      if (photosRes.ok) {
        const data = await photosRes.json();
        setGalleryPhotos(data);
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveSettings = async () => {
    if (!settings) return;

    try {
      setIsSaving(true);
      setSaveStatus('idle');

      const response = await fetch('/api/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(settings),
      });

      if (response.ok) {
        setSaveStatus('success');
        setTimeout(() => setSaveStatus('idle'), 3000);
      } else {
        const errorData = await response.json().catch(() => ({}));
        console.error('Erro ao salvar configurações:', response.status, errorData);
        alert(`Erro ao salvar: ${errorData.error || 'Erro desconhecido'}`);
        setSaveStatus('error');
      }
    } catch (error) {
      console.error('Erro ao salvar:', error);
      alert('Erro de conexão. Verifique se você está logado.');
      setSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateService = async (service: Service) => {
    try {
      const response = await fetch(`/api/services-config/${service.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(service),
      });

      if (response.ok) {
        await loadData();
        setEditingService(null);
      } else {
        alert('Erro ao atualizar serviço');
      }
    } catch (error) {
      console.error('Erro ao atualizar serviço:', error);
      alert('Erro de conexão');
    }
  };

  const handleUpdatePomade = async (pomade: PomadeType) => {
    try {
      const response = await fetch(`/api/pomade-types/${pomade.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(pomade),
      });

      if (response.ok) {
        await loadData();
        setEditingPomade(null);
      } else {
        alert('Erro ao atualizar pomada');
      }
    } catch (error) {
      console.error('Erro ao atualizar pomada:', error);
      alert('Erro de conexão');
    }
  };

  const handleAddPhoto = async () => {
    if (!newPhotoUrl.trim()) return;

    try {
      const response = await fetch('/api/gallery-photos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          url: newPhotoUrl,
          alt: newPhotoAlt || 'Foto da barbearia',
          display_order: galleryPhotos.length + 1,
        }),
      });

      if (response.ok) {
        await loadData();
        setNewPhotoUrl('');
        setNewPhotoAlt('');
      }
    } catch (error) {
      console.error('Erro ao adicionar foto:', error);
    }
  };

  const handleUpdatePhoto = async (photo: GalleryPhoto) => {
    try {
      const response = await fetch(`/api/gallery-photos/${photo.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(photo),
      });

      if (response.ok) {
        await loadData();
        setEditingPhoto(null);
      }
    } catch (error) {
      console.error('Erro ao atualizar foto:', error);
    }
  };

  const handleDeletePhoto = async (id: number) => {
    if (!confirm('Tem certeza que deseja remover esta foto?')) return;

    try {
      const response = await fetch(`/api/gallery-photos/${id}`, {
        method: 'DELETE',
        credentials: 'include',
      });

      if (response.ok) {
        await loadData();
      }
    } catch (error) {
      console.error('Erro ao deletar foto:', error);
    }
  };

  if (isLoading || !settings) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 p-3">
            <Settings className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Configurações</h2>
            <p className="text-sm text-slate-400">Personalize seu app</p>
          </div>
        </div>

        {saveStatus !== 'idle' && (
          <div className={`flex items-center gap-2 rounded-lg px-4 py-2 ${
            saveStatus === 'success' 
              ? 'bg-green-500/20 text-green-400' 
              : 'bg-red-500/20 text-red-400'
          }`}>
            {saveStatus === 'success' ? (
              <>
                <CheckCircle className="h-4 w-4" />
                <span className="text-sm font-medium">Salvo com sucesso!</span>
              </>
            ) : (
              <>
                <XCircle className="h-4 w-4" />
                <span className="text-sm font-medium">Erro ao salvar</span>
              </>
            )}
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto border-b border-slate-700 pb-px">
        <button
          onClick={() => setActiveTab('business')}
          className={`flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-3 font-medium transition-colors ${
            activeTab === 'business'
              ? 'border-amber-500 text-white'
              : 'border-transparent text-slate-400 hover:text-slate-300'
          }`}
        >
          <Settings className="h-4 w-4" />
          Informações do Negócio
        </button>
        <button
          onClick={() => setActiveTab('hours')}
          className={`flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-3 font-medium transition-colors ${
            activeTab === 'hours'
              ? 'border-amber-500 text-white'
              : 'border-transparent text-slate-400 hover:text-slate-300'
          }`}
        >
          <Clock className="h-4 w-4" />
          Horários
        </button>
        <button
          onClick={() => setActiveTab('services')}
          className={`flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-3 font-medium transition-colors ${
            activeTab === 'services'
              ? 'border-amber-500 text-white'
              : 'border-transparent text-slate-400 hover:text-slate-300'
          }`}
        >
          <Package className="h-4 w-4" />
          Serviços
        </button>
        <button
          onClick={() => setActiveTab('pomades')}
          className={`flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-3 font-medium transition-colors ${
            activeTab === 'pomades'
              ? 'border-amber-500 text-white'
              : 'border-transparent text-slate-400 hover:text-slate-300'
          }`}
        >
          <DollarSign className="h-4 w-4" />
          Pomadas
        </button>
        <button
          onClick={() => setActiveTab('photos')}
          className={`flex items-center gap-2 whitespace-nowrap border-b-2 px-4 py-3 font-medium transition-colors ${
            activeTab === 'photos'
              ? 'border-amber-500 text-white'
              : 'border-transparent text-slate-400 hover:text-slate-300'
          }`}
        >
          <Image className="h-4 w-4" />
          Fotos
        </button>
      </div>

      {/* Business Info Tab */}
      {activeTab === 'business' && (
        <div className="rounded-2xl border border-slate-700 bg-slate-800/50 p-6">
          <h3 className="mb-4 text-lg font-semibold text-white">Informações do Negócio</h3>
          
          <div className="space-y-4">
            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">Nome da Barbearia</label>
              <input
                type="text"
                value={settings.business_name}
                onChange={(e) => setSettings({ ...settings, business_name: e.target.value })}
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">Nome do Barbeiro</label>
              <input
                type="text"
                value={settings.barber_name}
                onChange={(e) => setSettings({ ...settings, barber_name: e.target.value })}
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">Endereço</label>
              <input
                type="text"
                value={settings.business_address}
                onChange={(e) => setSettings({ ...settings, business_address: e.target.value })}
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white"
              />
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">Instagram</label>
                <input
                  type="text"
                  value={settings.instagram}
                  onChange={(e) => setSettings({ ...settings, instagram: e.target.value })}
                  className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white"
                  placeholder="@usuario"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-slate-300">WhatsApp</label>
                <input
                  type="text"
                  value={settings.whatsapp}
                  onChange={(e) => setSettings({ ...settings, whatsapp: e.target.value })}
                  className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white"
                  placeholder="16999999999"
                />
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-slate-300">Email do Barbeiro (para receber notificações)</label>
              <input
                type="email"
                value={settings.barber_email || ''}
                onChange={(e) => setSettings({ ...settings, barber_email: e.target.value })}
                className="w-full rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-white"
                placeholder="seu@email.com"
              />
              <p className="mt-1 text-xs text-slate-400">
                Você receberá cópias de todos os emails de confirmação e lembretes enviados aos clientes
              </p>
            </div>

            <button
              onClick={handleSaveSettings}
              disabled={isSaving}
              className="flex items-center gap-2 rounded-lg bg-amber-500 px-6 py-2 font-semibold text-white transition-all hover:bg-amber-600 disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  Salvar Alterações
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Hours Tab */}
      {activeTab === 'hours' && (
        <div className="rounded-2xl border border-slate-700 bg-slate-800/50 p-6">
          <h3 className="mb-4 text-lg font-semibold text-white">Horários de Funcionamento</h3>
          
          <div className="space-y-4">
            {DAYS.map((day) => {
              const closedKey = `hours_${day.key}_closed`;
              const isClosed = settings[closedKey] === 'true';

              return (
                <div key={day.key} className="rounded-lg border border-slate-700 bg-slate-800/30 p-4">
                  <div className="mb-3 flex items-center justify-between">
                    <h4 className="font-medium text-white">{day.label}</h4>
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={isClosed}
                        onChange={(e) => setSettings({
                          ...settings,
                          [closedKey]: e.target.checked ? 'true' : 'false'
                        })}
                        className="h-4 w-4 rounded border-slate-600 bg-slate-700 text-amber-500"
                      />
                      <span className="text-sm text-slate-400">Fechado</span>
                    </label>
                  </div>

                  {!isClosed && (
                    <div className="grid gap-4 md:grid-cols-2">
                      <div>
                        <label className="mb-1 block text-xs text-slate-400">Manhã</label>
                        <div className="flex gap-2">
                          <input
                            type="time"
                            value={settings[`hours_${day.key}_morning_start`] || '09:00'}
                            onChange={(e) => setSettings({
                              ...settings,
                              [`hours_${day.key}_morning_start`]: e.target.value
                            })}
                            className="flex-1 rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-white"
                          />
                          <span className="flex items-center text-slate-500">até</span>
                          <input
                            type="time"
                            value={settings[`hours_${day.key}_morning_end`] || '12:00'}
                            onChange={(e) => setSettings({
                              ...settings,
                              [`hours_${day.key}_morning_end`]: e.target.value
                            })}
                            className="flex-1 rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-white"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="mb-1 block text-xs text-slate-400">Tarde</label>
                        <div className="flex gap-2">
                          <input
                            type="time"
                            value={settings[`hours_${day.key}_afternoon_start`] || '13:00'}
                            onChange={(e) => setSettings({
                              ...settings,
                              [`hours_${day.key}_afternoon_start`]: e.target.value
                            })}
                            className="flex-1 rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-white"
                          />
                          <span className="flex items-center text-slate-500">até</span>
                          <input
                            type="time"
                            value={settings[`hours_${day.key}_afternoon_end`] || '19:00'}
                            onChange={(e) => setSettings({
                              ...settings,
                              [`hours_${day.key}_afternoon_end`]: e.target.value
                            })}
                            className="flex-1 rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-white"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            <button
              onClick={handleSaveSettings}
              disabled={isSaving}
              className="flex items-center gap-2 rounded-lg bg-amber-500 px-6 py-2 font-semibold text-white transition-all hover:bg-amber-600 disabled:opacity-50"
            >
              {isSaving ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4" />
                  Salvar Horários
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Services Tab */}
      {activeTab === 'services' && (
        <div className="rounded-2xl border border-slate-700 bg-slate-800/50 p-6">
          <h3 className="mb-4 text-lg font-semibold text-white">Serviços Oferecidos</h3>
          
          <div className="space-y-3">
            {services.map((service) => (
              <div key={service.id} className="rounded-lg border border-slate-700 bg-slate-800/30 p-4">
                {editingService?.id === service.id ? (
                  <div className="space-y-3">
                    <input
                      type="text"
                      value={editingService.name}
                      onChange={(e) => setEditingService({ ...editingService, name: e.target.value })}
                      className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
                      placeholder="Nome do serviço"
                    />
                    <input
                      type="text"
                      value={editingService.description}
                      onChange={(e) => setEditingService({ ...editingService, description: e.target.value })}
                      className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
                      placeholder="Descrição"
                    />
                    <div className="grid gap-3 md:grid-cols-2">
                      <div>
                        <label className="mb-1 block text-xs text-slate-400">Preço (R$)</label>
                        <input
                          type="number"
                          step="0.01"
                          value={editingService.price}
                          onChange={(e) => setEditingService({ ...editingService, price: parseFloat(e.target.value) })}
                          className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs text-slate-400">Duração (min)</label>
                        <input
                          type="number"
                          value={editingService.duration}
                          onChange={(e) => setEditingService({ ...editingService, duration: parseInt(e.target.value) })}
                          className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
                        />
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleUpdateService(editingService)}
                        className="rounded-lg bg-amber-500 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-600"
                      >
                        Salvar
                      </button>
                      <button
                        onClick={() => setEditingService(null)}
                        className="rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-600"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-white">{service.name}</h4>
                      <p className="text-sm text-slate-400">{service.description}</p>
                      <p className="mt-1 text-sm text-amber-400">
                        R$ {service.price.toFixed(2)} • {service.duration} minutos
                      </p>
                    </div>
                    <button
                      onClick={() => setEditingService(service)}
                      className="rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-600"
                    >
                      Editar
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Pomades Tab */}
      {activeTab === 'pomades' && (
        <div className="rounded-2xl border border-slate-700 bg-slate-800/50 p-6">
          <h3 className="mb-4 text-lg font-semibold text-white">Tipos de Pomada</h3>
          
          <div className="mb-4">
            <label className="mb-2 block text-sm font-medium text-slate-300">Preço por Unidade</label>
            <div className="flex items-center gap-2">
              <span className="text-slate-400">R$</span>
              <input
                type="number"
                step="0.01"
                value={settings.pomade_price}
                onChange={(e) => setSettings({ ...settings, pomade_price: e.target.value })}
                className="w-32 rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
              />
              <button
                onClick={handleSaveSettings}
                disabled={isSaving}
                className="rounded-lg bg-amber-500 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-600"
              >
                {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Salvar'}
              </button>
            </div>
          </div>

          <div className="space-y-3">
            {pomadeTypes.map((pomade) => (
              <div key={pomade.id} className="rounded-lg border border-slate-700 bg-slate-800/30 p-4">
                {editingPomade?.id === pomade.id ? (
                  <div className="space-y-3">
                    {editingPomade.image && (
                      <img
                        src={editingPomade.image}
                        alt={editingPomade.name}
                        className="h-24 w-24 rounded-lg object-cover"
                      />
                    )}
                    <input
                      type="text"
                      value={editingPomade.name}
                      onChange={(e) => setEditingPomade({ ...editingPomade, name: e.target.value })}
                      className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
                      placeholder="Nome da pomada"
                    />
                    <input
                      type="text"
                      value={editingPomade.icon}
                      onChange={(e) => setEditingPomade({ ...editingPomade, icon: e.target.value })}
                      className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
                      placeholder="Emoji (ex: 💪)"
                    />
                    <div>
                      <label className="mb-1 block text-xs text-slate-400">URL da Imagem (opcional)</label>
                      <input
                        type="url"
                        value={editingPomade.image || ''}
                        onChange={(e) => setEditingPomade({ ...editingPomade, image: e.target.value })}
                        className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
                        placeholder="https://exemplo.com/imagem.jpg"
                      />
                      <p className="mt-1 text-xs text-slate-500">
                        Faça upload em Settings → Assets e cole a URL aqui
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleUpdatePomade(editingPomade)}
                        className="rounded-lg bg-amber-500 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-600"
                      >
                        Salvar
                      </button>
                      <button
                        onClick={() => setEditingPomade(null)}
                        className="rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-600"
                      >
                        Cancelar
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {pomade.image ? (
                        <img
                          src={pomade.image}
                          alt={pomade.name}
                          className="h-16 w-16 rounded-lg object-cover"
                        />
                      ) : (
                        <span className="text-2xl">{pomade.icon}</span>
                      )}
                      <div>
                        <h4 className="font-medium text-white">{pomade.name}</h4>
                        <p className="text-sm text-amber-400">R$ {parseFloat(settings.pomade_price).toFixed(2)}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setEditingPomade(pomade)}
                      className="rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-600"
                    >
                      Editar
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Photos Tab */}
      {activeTab === 'photos' && (
        <div className="space-y-6">
          {/* Service Photos */}
          <div className="rounded-2xl border border-slate-700 bg-slate-800/50 p-6">
            <h3 className="mb-4 text-lg font-semibold text-white">Fotos dos Serviços</h3>
            <p className="mb-4 text-sm text-slate-400">
              Essas são as fotos que aparecem nos cards de cada serviço
            </p>
            
            <div className="space-y-3">
              {services.map((service) => (
                <div key={service.id} className="flex items-center gap-4 rounded-lg border border-slate-700 bg-slate-800/30 p-4">
                  <img
                    src={service.image}
                    alt={service.name}
                    className="h-20 w-20 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <h4 className="font-medium text-white">{service.name}</h4>
                    <p className="text-xs text-slate-500">{service.image}</p>
                  </div>
                  <button
                    onClick={() => setEditingService(service)}
                    className="rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-600"
                  >
                    Editar URL
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Gallery Photos */}
          <div className="rounded-2xl border border-slate-700 bg-slate-800/50 p-6">
            <h3 className="mb-4 text-lg font-semibold text-white">Galeria de Fotos</h3>
            <p className="mb-4 text-sm text-slate-400">
              Essas fotos aparecem na seção "Nossa Barbearia" da página inicial
            </p>

            {/* Add New Photo */}
            <div className="mb-6 rounded-lg border border-slate-700 bg-slate-800/30 p-4">
              <h4 className="mb-3 text-sm font-semibold text-white">Adicionar Nova Foto</h4>
              <div className="space-y-3">
                <div>
                  <label className="mb-1 block text-xs text-slate-400">URL da Foto</label>
                  <input
                    type="url"
                    value={newPhotoUrl}
                    onChange={(e) => setNewPhotoUrl(e.target.value)}
                    className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
                    placeholder="https://exemplo.com/foto.jpg"
                  />
                  <p className="mt-1 text-xs text-slate-500">
                    Dica: Faça upload em Settings → Assets e copie a URL
                  </p>
                </div>
                <div>
                  <label className="mb-1 block text-xs text-slate-400">Descrição (opcional)</label>
                  <input
                    type="text"
                    value={newPhotoAlt}
                    onChange={(e) => setNewPhotoAlt(e.target.value)}
                    className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-white"
                    placeholder="Ex: Interior da barbearia"
                  />
                </div>
                <button
                  onClick={handleAddPhoto}
                  disabled={!newPhotoUrl.trim()}
                  className="flex items-center gap-2 rounded-lg bg-amber-500 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-600 disabled:opacity-50"
                >
                  <Plus className="h-4 w-4" />
                  Adicionar Foto
                </button>
              </div>
            </div>

            {/* Existing Photos */}
            <div className="grid gap-4 sm:grid-cols-2">
              {galleryPhotos.map((photo) => (
                <div key={photo.id} className="rounded-lg border border-slate-700 bg-slate-800/30 p-4">
                  {editingPhoto?.id === photo.id ? (
                    <div className="space-y-3">
                      <img
                        src={editingPhoto.url}
                        alt={editingPhoto.alt}
                        className="aspect-video w-full rounded-lg object-cover"
                      />
                      <input
                        type="url"
                        value={editingPhoto.url}
                        onChange={(e) => setEditingPhoto({ ...editingPhoto, url: e.target.value })}
                        className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-white"
                        placeholder="URL da foto"
                      />
                      <input
                        type="text"
                        value={editingPhoto.alt}
                        onChange={(e) => setEditingPhoto({ ...editingPhoto, alt: e.target.value })}
                        className="w-full rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-sm text-white"
                        placeholder="Descrição"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleUpdatePhoto(editingPhoto)}
                          className="flex-1 rounded-lg bg-amber-500 px-4 py-2 text-sm font-semibold text-white hover:bg-amber-600"
                        >
                          Salvar
                        </button>
                        <button
                          onClick={() => setEditingPhoto(null)}
                          className="rounded-lg border border-slate-600 bg-slate-700 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-600"
                        >
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <img
                        src={photo.url}
                        alt={photo.alt}
                        className="mb-3 aspect-video w-full rounded-lg object-cover"
                      />
                      <p className="mb-3 text-sm text-slate-400">{photo.alt}</p>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setEditingPhoto(photo)}
                          className="flex-1 rounded-lg border border-slate-600 bg-slate-700 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-600"
                        >
                          Editar
                        </button>
                        <button
                          onClick={() => handleDeletePhoto(photo.id)}
                          className="rounded-lg border border-red-600/50 bg-red-900/20 px-3 py-2 text-xs font-semibold text-red-400 hover:bg-red-900/40"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
