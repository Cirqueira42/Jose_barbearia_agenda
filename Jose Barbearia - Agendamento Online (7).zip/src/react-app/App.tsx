import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import { Home } from "@/react-app/pages/Home";
import { Admin } from "@/react-app/pages/Admin";
import { AdminLogin } from "@/react-app/pages/AdminLogin";
import { QuickBooking } from "@/react-app/pages/QuickBooking";
import { AuthCallback } from "@/react-app/pages/AuthCallback";
import CancelAppointment from "@/react-app/pages/CancelAppointment";
import TestWhatsApp from "@/react-app/pages/TestWhatsApp";
import TwilioSetupPage from "@/react-app/pages/TwilioSetupPage";
import QuickActionPage from "@/react-app/pages/QuickActionPage";
import { WhatsAppSetupPage } from "@/react-app/pages/WhatsAppSetupPage";
import { ProtectedRoute } from "@/react-app/components/ProtectedRoute";
import { InstallPrompt } from "@/react-app/components/InstallPrompt";
import { OfflineStatus } from "@/react-app/components/OfflineStatus";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <InstallPrompt />
        <OfflineStatus />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/agendar" element={<QuickBooking />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin" element={
            <ProtectedRoute>
              <Admin />
            </ProtectedRoute>
          } />
          <Route path="/admin/test-whatsapp" element={
            <ProtectedRoute>
              <TestWhatsApp />
            </ProtectedRoute>
          } />
          <Route path="/admin/twilio-setup" element={
            <ProtectedRoute>
              <TwilioSetupPage />
            </ProtectedRoute>
          } />
          <Route path="/admin/whatsapp-setup" element={
            <ProtectedRoute>
              <WhatsAppSetupPage />
            </ProtectedRoute>
          } />
          <Route path="/auth/callback" element={<AuthCallback />} />
          <Route path="/cancel-appointment" element={<CancelAppointment />} />
          <Route path="/action/:action/:id" element={<QuickActionPage />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
