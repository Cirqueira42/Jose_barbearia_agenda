import { useState, useEffect } from 'react';
import type { Appointment } from '../../shared/types';

export function useAppointments(filters?: { status?: string; date?: string }) {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAppointments = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const params = new URLSearchParams();
      if (filters?.status) params.append('status', filters.status);
      if (filters?.date) params.append('date', filters.date);
      
      // Add timestamp to prevent caching
      params.append('t', Date.now().toString());
      
      const url = `/api/appointments?${params.toString()}`;
      const response = await fetch(url, {
        credentials: 'include',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
        },
      });
      
      if (!response.ok) {
        throw new Error('Erro ao carregar agendamentos');
      }
      
      const data = await response.json();
      setAppointments(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, [filters?.status, filters?.date]);

  const updateStatus = async (id: number, status: string) => {
    try {
      const response = await fetch(`/api/appointments/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ status }),
      });

      if (!response.ok) {
        throw new Error('Erro ao atualizar status');
      }

      await fetchAppointments();
    } catch (err) {
      throw err;
    }
  };

  return {
    appointments,
    isLoading,
    error,
    refetch: fetchAppointments,
    updateStatus,
  };
}
